/******************************************************************************\
 *
 * Copyright (c) 2001-2006 EMC Corporation
 * All Rights Reserved
 *
 * QueryCluster.c
 *
 * QueryCluster Source File Build Version @version.full@
 *
 * This sourcefile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/

/*
 * Example - Using The Centera Access API To Query The C-Clips Stored In Centera.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>

/*
 * The standard header file for the Centera access API.
 * This includes all function prototypes and type
 * definitions needed to use the access API.
 */
#include <FPAPI.h>

#define BUFSIZE (128 + 1)

char **parseAttributes(char **, FPQueryExpressionRef*);
int processQueryResult(const FPPoolQueryRef, const FPInt, char *[]);
void printClipInfo(const FPQueryResultRef, char *[]);
FPLong convertTimeToNumber(const char *timeStamp);
char *convertNumberToTime(FPLong timeVar);

char **inputData(const char *, const int, const char *[], const char *[], const char *[]);
FPInt checkAndPrintError(const char *);

int main(int argc, char *argv[])
{
    FPPoolRef poolRef;
    FPPoolQueryRef query;
    FPInt retCode = 0;
    int bufSize=BUFSIZE;
    int actualBufSize;
    int sizeMatch;
    int index;
    const char *appVersion="3.1";
    char buf[256];
    const char *appName = "Query Cluster";
    const int numParameters = 5;
    const char *prompts[] = { "Enter the IP address or DNS name of the cluster(s)",
                              "Enter the type of clips to retrieve",
                              "Enter the local start time for the query range (YYYY:MM:DD HH:MM:SS)",
                              "Enter the local end time for the query range (YYYY:MM:DD HH:MM:SS)",
                              "Enter a comma separated list of attributes to retrieve " };
    const char *choices[] = { "", "Existing|Deleted|Both", "", "", ""};
    const char *defaults[] = { "us1cas1.centera.org,us1cas2.centera.org", "Existing", "Unbounded", "Unbounded", "creation.date,modification.date" };

    /* Verify the input options */
    char **values = inputData(appName, numParameters, prompts, choices, defaults);
    const char *poolAddress = values[0];
    const char *clipTypeString = values[1];
    const char *fromTime = values[2];
    const char *toTime = values[3];
    char **attributes = 0;

    FPLong starttime = 0;
    FPLong endtime = 0;
    FPInt clipType = 0;
    FPInt timeout = 120000;

    switch(clipTypeString[0])
    {
    case 'E':   clipType = FP_QUERY_TYPE_EXISTING;
        break;
    case 'D':   clipType = FP_QUERY_TYPE_DELETED;
        break;
    default:    clipType = FP_QUERY_TYPE_EXISTING | FP_QUERY_TYPE_DELETED;
        break;
    }

    starttime = convertTimeToNumber(fromTime);
    endtime = convertTimeToNumber(toTime);

    /* End range uses -1 as unbounded */
    if (endtime == 0)
        endtime = -1;

    /*Stores your application's name and version for registration on Centera
    This call should be made one time, before the FPPoolOpen() call,
    for each application that interfaces with centera
    *
    Applications can also be registered via the environment variables 
    FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
    will override what is set through environment variable.
    */
    FPPool_RegisterApplication(appName,appVersion);
    retCode = checkAndPrintError("Application Registration Error: ");

    /*
     * Open up a Pool
     * @param poolAddress The IP address of the access node of the Pool
     * @return A reference to the opened Pool
     */

    /* New in 2.3 - use LazyOpen option for opening pools as it is more efficient */
    FPPool_SetGlobalOption(FP_OPTION_OPENSTRATEGY, FP_LAZY_OPEN);

    poolRef = FPPool_Open(poolAddress);
    retCode = checkAndPrintError("Pool Open Error: ");

    bufSize = BUFSIZE;
    FPPool_GetCapability(poolRef,FP_CLIPENUMERATION, FP_ALLOWED, buf, &bufSize);
    actualBufSize = (int) strlen(buf)+1;
    sizeMatch= (actualBufSize==bufSize);
    retCode = checkAndPrintError("Get Min FIXED Retention Value Error: ");
    if (!(retCode)&&(sizeMatch))
    {    
        fprintf(stdout, "Query Enabled:\t\t\t%s\n", buf);
        if (0==strcmp(FP_TRUE,buf))
        {
            /*
            * Open a query stream
            * @param poolRef A reference to the Pool
            * @starttime From what time the C-Clip(s) have to be written to the Pool
            * @endtime Until what time the C-Clip(s) were written to the Pool
            * @NULL Reserved
            * @return A reference to the created query stream
            */
            FPQueryExpressionRef queryRef = FPQueryExpression_Create();
            FPQueryExpression_SetType(queryRef, clipType);
            FPQueryExpression_SetStartTime(queryRef, starttime);
            FPQueryExpression_SetEndTime(queryRef, endtime);

            attributes = parseAttributes(values, &queryRef);

            query = FPPoolQuery_Open(poolRef, queryRef);
            retCode = checkAndPrintError("Query Open Error: ");

            if (!retCode)
            {
                /* Free up the FPQueryExpressionRef resources*/
                FPQueryExpression_Close(queryRef);

                /* Fetch the C-Clip ID from the result of the query */
                retCode = processQueryResult(query, timeout, attributes);
                /*
                * Close the query stream
                * @param query The reference to the query steam
                */
                FPPoolQuery_Close(query);
                retCode = checkAndPrintError("Query Close Error: ");
            }

            /*
            * Close the pool
            * @param poolRef A reference to the pool
            */
            FPPool_Close(poolRef);
            retCode = checkAndPrintError("Pool Close Error: ");
        }
    }

    for (index=0;index<numParameters; index++)
    {
         free(values[index]);
    }
    free(values);
    free(attributes);
    return retCode;
}


char **parseAttributes(char** values, FPQueryExpressionRef *queryRef)
{
    char **attributes = 0;
    /* Parse the supplied attribute string and set up as an array for later use */
    if (*values[4]== '\0')
    {
        attributes = (char**) malloc(sizeof(char **));
        attributes[0] = NULL;
    }
    else /* We have at least one attribute supplied */
    {
        int numAttrs = 2; /* Include space for a terminating NULL attribute */
        char *tempPtr = (char *) values[4];

        while ((tempPtr = strchr(tempPtr, ',')))
        {
            numAttrs++;
            tempPtr++;
        }

        attributes = (char **) malloc(numAttrs * sizeof (char **));
        attributes[0] = (char *) values[4];
        attributes[numAttrs - 1] = NULL;

        tempPtr = (char *) attributes[0];
        numAttrs = 0;

        while (attributes[numAttrs] && tempPtr)
        {
            /*  Find the end of the option in the comma separated string */
            if (tempPtr)
            {
                tempPtr =  strchr(attributes[numAttrs], ',');
            }

            if (tempPtr && *tempPtr == ',')
            {
                *tempPtr = '\0';
                FPQueryExpression_SelectField(*queryRef, attributes[numAttrs]);
                attributes[++numAttrs] = ++tempPtr;
            }
            else
                FPQueryExpression_SelectField(*queryRef, attributes[numAttrs]);
        }
    }
    return attributes;
}
/*
 * Convert a time string to a FPLong number
 * @param timeStamp The string for the start time of the query
 * @param time The number for the start time of the query
 */
FPLong convertTimeToNumber(const char *timeStamp)
{
    FPLong timeVar = 0;

    if (strcmp(timeStamp, "0") != 0 &&
        strcmp(timeStamp, "-1") != 0 &&
        strcmp(timeStamp, "Unbounded") != 0)
    {
        /* We are not using the default so convert it */
        if (timeStamp)
        {
            struct tm timeRec;
            memset(&timeRec, 0, sizeof(struct tm));
            if (sscanf (timeStamp, "%d:%d:%d %d:%d:%d",
                    &timeRec.tm_year, &timeRec.tm_mon, &timeRec.tm_mday,
                    &timeRec.tm_hour, &timeRec.tm_min, &timeRec.tm_sec) != 6)
            {
                fprintf(stderr, "Invalid date / time - using default value.\n");
            }

            timeRec.tm_isdst = -1 ;
            timeRec.tm_year  -= 1900 ;
            timeRec.tm_mon   -= 1 ;
            timeVar = mktime (&timeRec) ;

            /* Convert from seconds to milliseconds */
            timeVar *= 1000 ;
        }
    }
    return timeVar;
}

char *convertNumberToTime(FPLong timeVar)
{
    /* Convert from milliseconds to seconds */
    timeVar /= 1000;

    return  ctime((time_t *) & timeVar);
}

/*
 * Fetch the C-Clips individually - in time ascending order and prints out the results
 * of the query to the screen
 * @param query The reference to the query stream that used to perform the query
 * @param timeout The time that the query will wait for the next result
 * @return 0 if no error occured, otherwise return the error code
 */
int processQueryResult(const FPPoolQueryRef query, const FPInt timeout, char *attributes[])
{
    FPInt queryStatus = 0;
    FPQueryResultRef resultRef = 0;
    FPInt errorCode = 0;
    int queryTerminated = false;

    while (!queryTerminated && !errorCode)
    {
        resultRef = FPPoolQuery_FetchResult (query,  timeout);
        errorCode = checkAndPrintError("PoolQuery_FetchResult Error: ");

        if (!errorCode)
        {

            queryStatus = FPQueryResult_GetResultCode(resultRef);
            errorCode = checkAndPrintError("QueryResult_GetResultCode Error: ");

            if (!errorCode)
            {

                switch (queryStatus)
                {
                    /*
                    * The C-Clip and the C-Clip ID that query fetched are valid and can be
                    * processed by the application
                    */
                case FP_QUERY_RESULT_CODE_OK:
                    printClipInfo(resultRef, attributes);
                    break;

                    /*
                    * The following results of the query may be incomplete because two or more
                    * storage nodes were not online during the query
                    */
                case FP_QUERY_RESULT_CODE_INCOMPLETE:
                    fprintf(stdout, "Incomplete state occurred. \n");
                    break;

                    /*
                    * This will be encountered following a previous FP_QUERY_RESULT_CODE_INCOMPLETE status.
                    * The subsequent query result rows are guaranteed to be complete. However, the result may
                    * not be valid. We recommend restarting the query from the last valid timeStamp
                    * before FP_QUERY_RESULT_CODE_INCOMPLETE was returned
                    */
                case FP_QUERY_RESULT_CODE_COMPLETE:
                    fprintf(stdout, "Complete after the previous incomplete state. \n");
                    break;

                    /* The query is finished, no more query results are expected */
                case FP_QUERY_RESULT_CODE_END:
                    fprintf(stdout, "Query is complete. No more results are available. \n");
                    queryTerminated = true;
                    break;

                    /*
                    * The query has been aborted due to a problem on the server side or because
                    * the start time of the query is later than the current server time
                    */
                case FP_QUERY_RESULT_CODE_ABORT:
                    fprintf(stdout, "Query is aborted. \n");
                    queryTerminated = true;
                    break;

                    /* The query is in progress. No result is available at this point */
                case FP_QUERY_RESULT_CODE_PROGRESS:
                    fprintf(stdout, "The Query is in progress... \n");
                    break;

                    /*
                    * A client error has been detected during the execution of this call. Check the
                    * error code
                    */
                case FP_QUERY_RESULT_CODE_ERROR:
                    queryStatus = checkAndPrintError("Query Error: ");
                    queryTerminated = true;
                    break;
                }

            }

            FPQueryResult_Close (resultRef);
            errorCode = checkAndPrintError("QueryResult Close Error: ");
        }
    }

  
    return queryStatus | errorCode;
}

/*
 * Print the C-Clip ID and the creation time to screen.
 * @param clipID The content address of the C-Clip
 */
void printClipInfo(const FPQueryResultRef resultRef, char *attributes[])
{
    FPClipID clipID;
    FPLong clipTime;
    FPInt clipType;
    FPInt l;
    char vBuffer[1024];
    int i;

    FPQueryResult_GetClipID (resultRef, clipID);
    clipTime = FPQueryResult_GetTimestamp (resultRef);
    clipType = FPQueryResult_GetType (resultRef);

    if (clipType == FP_QUERY_TYPE_DELETED)
        fprintf(stdout, "Deleted ");
    else
        fprintf(stdout, "Current ");

    fprintf(stdout, "Clip Id: %s Timestamp (Local Time) %s", clipID, convertNumberToTime(clipTime));

    l=sizeof(vBuffer);

    for (i = 0; attributes[i] != NULL; i++)
    {
        FPQueryResult_GetField(resultRef, attributes[i], vBuffer, &l);
        fprintf(stdout, "\t\tAttribute %s (%s)\n", attributes[i], vBuffer);
    }
}


char **inputData(const char *header,
                 const int numParameters,
                 const char *prompts[],
                 const char *validOptions[],
                 const char *defaults[])
{
    int i;
    char buffer[BUFSIZE];
    char **values = (char **) malloc(numParameters * sizeof(char *));

    fprintf(stderr, "Enter values or leave blank to use defaults:\n\n");

    i = 0;
    while (i < numParameters)
    {
        FPBool valid = false;

        if (*prompts[i] !=  '\0')
            fprintf(stderr, "%s: ", prompts[i]);

        if (*validOptions[i] != '\0')
            fprintf(stderr, " Valid options [%s] ", validOptions[i]);

        if (*defaults[i] != '\0')
            fprintf(stderr, " <%s> ", defaults[i]);

        fgets(buffer, sizeof(buffer), stdin);
        buffer[strlen(buffer) - 1] = '\0';  /* Remove the terminating \n */

        if (buffer[0] == '\0')
        {
            if (*defaults[i] != '\0') /* Accept the default */
            {
                values[i] = (char *) malloc((strlen(defaults[i])+1) * sizeof(char));
                strcpy(values[i], defaults[i]);
                valid = true;
            }
            else
            {
                fprintf(stdout, "There is no default value - please enter data\n");
            }
        }
        else
        {
            /* Test that data is valid */
            if (*validOptions[i] == '\0') /* No choices to validate so accept what user entered */
            {
                values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                strcpy(values[i], buffer);
                valid = true;
            }
            else
            {
                const char *substr = (const char *) strstr((char *) validOptions[i], buffer);

                if (substr) /* Input is within the validOptions string - check the if it is the whole value */
                {
                    const char *optionEnd =  strchr(substr, '|');

                    if (optionEnd)
                    {
                        int length = (int) (optionEnd - substr);

                        if (length == (int) strlen(buffer))
                            valid = true;
                    }
                    else
                        valid = true;
                }


                if (!valid)
                    fprintf(stderr, "%s is not in valid choices: [%s]\n", buffer, validOptions[i]);
                else
                {
                    values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
                    strcpy(values[i], buffer);
                }
            }
        }
        if (valid)
            ++i;
    }

    return values;
}

FPInt checkAndPrintError(const char *errorMessage)
{
    /* Get the error code of the last SDK API function call */
    FPInt errorCode = FPPool_GetLastError();
    if (errorCode != ENOERR)
    {
        FPErrorInfo errInfo;
        fprintf(stderr, errorMessage);
        /* Get the error message of the last SDK API function call */
        FPPool_GetLastErrorInfo(&errInfo);
        if (!errInfo.message) /* the human readable error message */
            fprintf(stderr, "%s\n", errInfo.errorString);
        else if (!errInfo.errorString) /* the error string corresponds to an error code */
            fprintf(stderr, "%s\n", errInfo.message);
        else
            fprintf(stderr, "%s%s%s\n",errInfo.errorString," - ",errInfo.message);
    }

    return errorCode;
}
