import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.StringTokenizer;

import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;
import com.filepool.fplibrary.FPPoolQuery;
import com.filepool.fplibrary.FPQueryExpression;
import com.filepool.fplibrary.FPQueryResult;

/*****************************************************************************
* 
* Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
* 
* QueryCluster.java
* 
* Using the Centera Java API to query a cluster.
* 
* This sourcefile contains the intellectual property of EMC Corporation or
* is licensed to EMC Corporation from third parties. Use of this sourcefile
* and the intellectual property contained therein is expressly limited to
* the terms and conditions of the License Agreement.
*  
****************************************************************************/

/**
 * <p>
 * Title: QueryCluster
 * </p>
 * <p>
 * Description: Using the Centera Java API to query a cluster.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class QueryCluster {

	/**
	 * 
	 * @param args  - Command Line arguments
	 */
	public static void main(String[] args) {
		int exitCode = 0;
		long count = 0;
		String appName="Query Cluster Sample";
	    String appVersion="3.1";
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);
		TimeZone TZ = TimeZone.getTimeZone("GMT");
		FPQueryResult queryResult = null;
		int queryStatus = 0;
		Calendar timeConverter = Calendar.getInstance(TZ);

		try {

		 /*Stores your application's name and version for registration on Centera
	       This call should be made one time, before the FPPoolOpen() call,
	       for each application that interfaces with centera
	       *
	       Applications can also be registered via the environment variables 
	       FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	       will override what is set through environment variable.
		   */
		    FPPool.RegisterApplication(appName,appVersion);
			    
			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();

			if (!answer.equals(""))
				poolAddress = answer;

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			// open cluster connection
			FPPool thePool = new FPPool(poolAddress);

			// Check that query is supported on this connection; query can be 
			// disabled by the Centera administrator
			if (thePool.getCapability(
					FPLibraryConstants.FP_CLIPENUMERATION,
					FPLibraryConstants.FP_ALLOWED) == "False") {
				throw new IllegalArgumentException("Query is not supported for this pool connection.");
			}

			System.out.println(
				"Query capability is enabled for this pool connection.");

			DateFormat dFormat =
				DateFormat.getDateTimeInstance(
					DateFormat.SHORT,
					DateFormat.LONG);

			// set timezone to GMT to match what centera uses
			dFormat.setTimeZone(TZ);
			Calendar clusterTime = Calendar.getInstance(TZ);
			clusterTime.setTime(new Date(thePool.getClusterTime()));

			System.out.println(
				"Cluster Time: " + dFormat.format(clusterTime.getTime()));

			Calendar epoch = Calendar.getInstance(TZ);
			epoch.setTime(new Date(0));
			String start = ConvertDateTimeToString(epoch);

			// Prompt user for start time of query, default is java epoch
			System.out.print(
				"Query start time in GMT(YYYY.MM.DD.hh.mm.ss)["	+ start	+ "]: ");
			answer = stdin.readLine();

			if (!answer.equals(""))
				start = answer;

			Calendar startTime = ConvertDisplayToCalendar(start);
			String end = ConvertDateTimeToString(clusterTime);

			// Prompt user for end time of query, default is current cluster time.
			System.out.print(
				"Query end time in GMT(YYYY.MM.DD.hh.mm.ss)[" + end + "]: ");
			answer = stdin.readLine();

			if (!answer.equals(""))
				end = answer;

			Calendar endTime = ConvertDisplayToCalendar(end);

			// Query is resource intensive operation on Centera backend
			// There is currently a hard limit of 10 concurrent queries on the Centera.
			// The most efficient query strategy is to run a single query rather than multiple queries
			System.out.println(
				"\nStarting Query:  Starting "
					+ dFormat.format(startTime.getTime())
					+ ", Ending "
					+ dFormat.format(endTime.getTime()));

			// Define query expression, start and end times in GMT.
			FPQueryExpression queryExp = new FPQueryExpression();
			queryExp.setStartTime(startTime.getTime().getTime());
			queryExp.setEndTime(endTime.getTime().getTime());

			// New for 2.3 two types to query for EXISTING or DELETED.
			queryExp.setType(FPLibraryConstants.FP_QUERY_TYPE_EXISTING);

			// We want to retrieve two fields during our query, select them beforehand.
			queryExp.selectField("creation.date");
			queryExp.selectField("modification.date");

			FPPoolQuery theQuery = new FPPoolQuery(thePool, queryExp);

			// Retrieve and display the time again before we start our query
			clusterTime.setTime(new Date(thePool.getClusterTime()));

			System.out.println(
				"Current Cluster Time is "
					+ dFormat.format(clusterTime.getTime()));

			//	Retrieve Query results one at a time, checking for incomplete gaps. 
			//  Gaps can occur when data is temporarily unavailable on the Centera backend
			while (true) {

				queryResult = theQuery.FetchResult();
				queryStatus = queryResult.getResultCode();

				if (queryStatus
					== FPLibraryConstants.FP_QUERY_RESULT_CODE_OK) {
					//Print clip
					timeConverter.setTime(new Date(queryResult.getTimestamp()));
					System.out.println(
						"Clip ID: "
							+ queryResult.getClipID()
							+ " Query timestamp: "
							+ dFormat.format(timeConverter.getTime())
							+ " creation date: "
							+ queryResult.getField("creation.date")
							+ " modification time on clip : "
							+ queryResult.getField("modification.date"));
					count++;

				} else if (
					queryStatus
						== FPLibraryConstants.FP_QUERY_RESULT_CODE_INCOMPLETE) {
					// Error occured one or more nodes on centera could not be queried.
					System.out.println(
						"Received FP_QUERY_RESULT_CODE_INCOMPLETE error, invalid C-Clip, trying again.");

				} else if (
					queryStatus
						== FPLibraryConstants.FP_QUERY_RESULT_CODE_COMPLETE) {
					// Indicate error should have been received after incomplete error
					System.out.println(
						"Received FP_QUERY_RESULT_CODE_COMPLETE, there should have been a previous "
							+ "FP_QUERY_RESULT_CODE_INCOMPLETE error reported.");

				} else if (
					queryStatus
						== FPLibraryConstants.FP_QUERY_RESULT_CODE_END) {
					// all results have been received finish query.
					System.out.println("End of query reached, exiting.");
					break;

				} else if (
					queryStatus
						== FPLibraryConstants.FP_QUERY_RESULT_CODE_ABORT) {
					// query aborted due to server side issue or start time
					// is later than server time.
					System.out.println(
						"received FP_QUERY_RESULT_CODE_ABORT error, exiting.");
					break;

				} else if (
					queryStatus
						== FPLibraryConstants.FP_QUERY_RESULT_CODE_ERROR) {
					//Server error
					System.out.println(
						"received FP_QUERY_RESULT_CODE_ERROR error, retrying again");

				} else if (
					queryStatus
						== FPLibraryConstants.FP_QUERY_RESULT_CODE_PROGRESS) {
					System.out.println(
						"received FP_QUERY_RESULT_CODE_PROGRESS, continuing.");

				} else {
					// Unknown error, stop running query
					System.out.println("received error: " + queryStatus);
					break;

				}

				queryResult.Close();
			} //while

			queryResult.Close();
			System.out.println("\nTotal number of clips \t" + count);
			theQuery.Close();
			
			stdin.close();

			// Always close the Pool connection when finished.  Not a
			// good practice to open and close for each transaction.
			thePool.Close();
			System.out.println(
				"\nClosed connection to Centera cluster (" + poolAddress + ")");

		} catch (FPLibraryException e) {
			exitCode = e.getErrorCode();
			System.err.println(
				"Centera SDK Error: " + e.getMessage() + "(" + exitCode + ")");
		} catch (IllegalArgumentException e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		} catch (IOException e) {
			System.err.println("IO Error: " + e.getMessage());
			exitCode = -1;
		}

		System.exit(exitCode);
	}

	/**
	 * ConvertDisplayToCalendar -- helper method to convert string containing date
	 * into calendar.
	 * 
	 * @param pDateTime
	 * @return
	 */
	private static Calendar ConvertDisplayToCalendar(String pDateTime)
		throws IllegalArgumentException {

		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		StringTokenizer st = new StringTokenizer(pDateTime, ".");

		if (st.countTokens() != 6)
			throw new IllegalArgumentException("Invalid argument.");

		cal.set(
			Integer.parseInt(st.nextToken()),
			Integer.parseInt(st.nextToken()) - 1,
			Integer.parseInt(st.nextToken()),
			Integer.parseInt(st.nextToken()),
			Integer.parseInt(st.nextToken()),
			Integer.parseInt(st.nextToken()));

		return cal;
	}

	/**
	 * ConvertDateTimeToString -- helper method for converting to a format 
	 * suitable for displaying.
	 * 
	 * @param pCal
	 * @return
	 */
	private static String ConvertDateTimeToString(Calendar pCal) {
		return (
			String.valueOf(pCal.get(Calendar.YEAR))
				+ "."
				+ String.valueOf(pCal.get(Calendar.MONTH) + 1)
				+ "."
				+ String.valueOf(pCal.get(Calendar.DAY_OF_MONTH))
				+ "."
				+ String.valueOf(pCal.get(Calendar.HOUR_OF_DAY))
				+ "."
				+ String.valueOf(pCal.get(Calendar.MINUTE))
				+ "."
				+ String.valueOf(pCal.get(Calendar.SECOND)));

	}
}
