import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.filepool.fplibrary.FPClip;
import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;

/*******************************************************************************
 * 
 * Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
 * 
 * DeleteContent.java
 * 
 * Using the Centera Java API to delete a C-Clip from Centera
 * 
 * This sourcefile contains the intellectual property of EMC Corporation or is
 * licensed to EMC Corporation from third parties. Use of this sourcefile and
 * the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *  
 ******************************************************************************/

/**
 * 
 * <p>
 * Title: DeleteContent
 * </p>
 * <p>
 * Description: Using the Centera Java API to delete a C-Clip from Centera.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class DeleteContent {

	/**
	 * main
	 * 
	 * @throws FPLibraryException
	 */

	public static void main(String[] args) {

		String appName="Delete Content Sample";
	    String appVersion="3.1";
		int exitCode = 0;
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		long deleteOption = FPLibraryConstants.FP_OPTION_DEFAULT_OPTIONS;
		String PRIV_DELETE_DEFAULT = "n";
		String AUDITED_DELETE_DEFAULT = "n";
		String auditString = "DeleteContent sample audited delete";
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);

		try {

		 /*Stores your application's name and version for registration on Centera
	       This call should be made one time, before the FPPoolOpen() call,
	       for each application that interfaces with centera
	       *
	       Applications can also be registered via the environment variables 
	       FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	       will override what is set through environment variable.
		   */
		    FPPool.RegisterApplication(appName,appVersion);
			    
			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();

			if (!answer.equals(""))
				poolAddress = answer;

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			// open cluster connection
			FPPool thePool = new FPPool(poolAddress);

			// Prompt user for clip ID we want to delete
			System.out.print(
				"Enter the Content Address of the object to be deleted: ");
			String clipID = stdin.readLine();

			if (clipID.equals(""))
				throw new IllegalArgumentException("Invalid answer.");

			// Check whether clip exists
			if (!FPClip.Exists(thePool, clipID)) {
				throw new IllegalArgumentException(
					"ClipID \""
						+ clipID
						+ "\" does not exist on this Centera cluster.");
			}

			// Open clip and check for number of blobs
			FPClip clip =
				new FPClip(thePool, clipID, FPLibraryConstants.FP_OPEN_FLAT);

			int numBlobs = clip.getNumBlobs();

			System.out.println(
				"Clip contains "
					+ numBlobs
					+ (1 == numBlobs ? " blob." : " blobs."));

			clip.Close();

			System.out.println(
				"Deleting C-Clip with ID \"" + clipID + "\"... ");

			// Prompt user whether we want to use audited delete capability or not
			System.out.print(
				"Use audited delete (required for privilged delete option)? ["
					+ AUDITED_DELETE_DEFAULT
					+ "]");
			answer = stdin.readLine();
			
			if (answer.equals("") || answer.toLowerCase().startsWith("n"))
			{
				// Regular delete
				FPClip.Delete(thePool, clipID);		
			}
			else if (!answer.toLowerCase().startsWith("y")) {
				throw new IllegalArgumentException("Invalid response.");
			}				
			else
			{
				// Prompt user whether we want to use privileged delete capability or not
				System.out.print(
					"Use privileged delete capability? ["
						+ PRIV_DELETE_DEFAULT
						+ "]");
				answer = stdin.readLine();
	
				if (answer.equals("")) {
					deleteOption = FPLibraryConstants.FP_OPTION_DEFAULT_OPTIONS;
	
				} else if (answer.toLowerCase().startsWith("y")) {
					deleteOption = FPLibraryConstants.FP_OPTION_DELETE_PRIVILEGED;
	
				} else if (!answer.toLowerCase().startsWith("n")) {
					throw new IllegalArgumentException("Invalid response.");
				}

				// Prompt for audit string
				System.out.print(
					"Enter a reason for Audited delete [" + auditString + "]");
				answer = stdin.readLine();
	
				if (!answer.equals(""))
					auditString = answer;
	
				FPClip.AuditedDelete(thePool, clipID, auditString, deleteOption);
			}

			System.out.println("\nClip deleted.");

			// Verify that clip no longer exists
			if (!FPClip.Exists(thePool, clipID)) {
				System.out.println("Delete call was successful,");
				System.out.println(
					"verified the C - Clip \""
						+ clipID
						+ "\" no longer exists on the Centera cluster.");
			} else {
				System.err.println(
					"\nC-Clip: "
						+ clipID
						+ " still exists on the Centera cluster after deletion.  Is replication enabled?");
			}

			// Always close the Pool connection when finished.
			thePool.Close();
			System.out.println(
				"\nClosed connection to Centera cluster (" + poolAddress + ")");

			inputReader.close();
			stdin.close();

		} catch (FPLibraryException e) {
			exitCode = e.getErrorCode();
			System.err.println(
				"Centera SDK Error: " + e.getMessage() + "(" + exitCode + ")");
		} catch (IOException e) {
			System.err.println("IO Error occured: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		}

		System.exit(exitCode);
	}
}
