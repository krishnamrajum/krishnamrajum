import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;
import com.filepool.fplibrary.FPPoolInfo;
import com.filepool.fplibrary.FPRetentionClass;
import com.filepool.fplibrary.FPRetentionClassContext;

/*****************************************************************************
 * 
 * Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
 * 
 * ClusterInfo.java
 * 
 * Using the Centera Java API to retrieve Cluster-related
 * configuration information.
 * 
 * This sourcefile contains the intellectual property of EMC Corporation or
 * is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to
 * the terms and conditions of the License Agreement.
 *  
 ****************************************************************************/

/**
 * <p>
 * Title: GetClusterInfo
 * </p>
 * <p>
 * Description: Using the Centera Java API to retrieve Cluster-related
 * configuration information.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class GetClusterInfo {

	// Centera connection, passed in via constructor
	FPPool mThePool = null;

	/**
	 * Constructor 
	 * 
	 * @param thePool -
	 *            Pool object, should already be connected to Centera
	 * 
	 */
	public GetClusterInfo(FPPool thePool) {
		mThePool = thePool;
	}

	/**
	 * showPoolInfo - retrieve and print Centera pool settings
	 * 
	 * @param thePool
	 * @throws FPLibraryException
	 */
	public void showPoolInfo() throws FPLibraryException {
		// retrieve information about the pool
		FPPoolInfo poolInfo = mThePool.getPoolInfo();

		// Output pool information
		System.out.println("\nPool Information:\n");
		System.out.println(
			"\tCluster ID:                            "
				+ poolInfo.getClusterID());

		System.out.println(
			"\tCluster Name:                          "
				+ poolInfo.getClusterName());

		System.out.println(
			"\tCentraStar software version:           "
				+ poolInfo.getVersion());

		System.out.println(
			"\tCluster Capacity (Bytes):              "
				+ poolInfo.getCapacity());

		System.out.println(
			"\tCluster Free Space (Bytes):            "
				+ poolInfo.getFreeSpace());

		System.out.println(
			"\tCluster Replica Address:               "
				+ poolInfo.getReplicaAddress());
	}

	/**
	 * showFPLibraryVersion - display library versions.
	 * 
	 * @throws Exception
	 */
	public void showFPLibraryVersion() throws Exception {

		System.out.println("\nLibrary Versions:\n");

		System.out.println(
			"\tNative SDK library version:            "
				+ FPPool.getComponentVersion(
					FPLibraryConstants.FP_VERSION_FPLIBRARY_DLL));
		System.out.println(
			"\tJava SDK version:                      "
				+ FPPool.getComponentVersion(
					FPLibraryConstants.FP_VERSION_FPLIBRARY_JAR));
	}

	/**
	 * showClusterTime - display cluster time.
	 * 
	 * @throws FPLibraryException
	 */
	public void showClusterTime() throws FPLibraryException {

		Date clusterTime = new Date(mThePool.getClusterTime());
		DateFormat dFormat =
			DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.LONG);

		// set timezone to GMT to match what centera uses
		dFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

		System.out.println(
			"\tCluster Time:                          "
				+ dFormat.format(clusterTime));
	}

	/**
	 * showRetentionClasses - show retention classes available to the application.
	 * 
	 * @throws FPLibraryException
	 */
	public void showRetentionClasses() throws FPLibraryException {

		System.out.println("\nCluster Retention Classes:\n");

		FPRetentionClassContext retentionClassList =
			mThePool.getRetentionClassContext();

		int numClasses = retentionClassList.getNumClasses();

		System.out.println(
			"\t"
				+ numClasses
				+ " retention class"
				+ (numClasses > 1 ? "es are" : " is")
				+ " defined on the cluster.");

		if (numClasses > 0) {

			FPRetentionClass retentionClass = retentionClassList.getFirst();

			while (retentionClass != null) {

				System.out.println(
					"\t\tRetention class: "
						+ retentionClass.getName()
						+ "\t has an interval of "
						+ retentionClass.getPeriod());

				retentionClass.close();

				retentionClass = retentionClassList.getNext();

			}
		} else if (numClasses == 0) {

			System.out.println("Zero retention classes are defined.");
		}
	}

	/**
	 * showPoolCapabilities - retrieve and print supported operations for
	 * this cluster connection.
	 * 
	 * @throws FPLibraryException
	 */
	public void showPoolCapabilities() throws FPLibraryException {

		// Show Pool Capabilities
		System.out.println("\nPool Capabilities:\n");
		System.out.println(
			"\tRead   Operation Allowed:              "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_READ,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tWrite  Operation Allowed:              "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_WRITE,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tDelete Operation Allowed:              "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_DELETE,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tPurge  Operation Allowed:              "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_PURGE,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tPrivileged Delete Operation Allowed:   "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_PRIVILEGEDDELETE,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tExistence Checking Operation Allowed:  "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_EXIST,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tMonitor Operation Allowed:             "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_MONITOR,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tQuery   Operation Allowed:             "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_CLIPENUMERATION,
					FPLibraryConstants.FP_ALLOWED));

		System.out.println(
			"\tDefault Retention Period:              "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_RETENTION,
					FPLibraryConstants.FP_DEFAULT));

		System.out.println(
			"\tEvent Based Retention supported:       "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_COMPLIANCE,
					FPLibraryConstants.FP_EVENT_BASED_RETENTION));
		
		System.out.println(
			"\tRetention Hold supported:              "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_COMPLIANCE,
						FPLibraryConstants.FP_RETENTION_HOLD));
			
		System.out.println(
			"\tDefault Blob Naming Scheme:            "
				+ mThePool.getCapability(
					FPLibraryConstants.FP_BLOBNAMING,
					FPLibraryConstants.FP_SUPPORTED_SCHEMES));

		System.out.println(
			"\tDeletion logging enabled:              "
				+ mThePool.getCapability(FPLibraryConstants.FP_DELETIONLOGGING,
						FPLibraryConstants.FP_SUPPORTED));
		
		System.out.println(
			"\tMin/Max Enabled:                       "
				+ mThePool.getCapability(FPLibraryConstants.FP_COMPLIANCE,
						FPLibraryConstants.FP_RETENTION_MIN_MAX));
		
		System.out.println(
			"\ttRetention Variable Min:               "
				+ mThePool.getCapability(FPLibraryConstants.FP_RETENTION,
						FPLibraryConstants.FP_VARIABLE_RETENTION_MIN));
		
		System.out.println(
			"\tRetention Variable Max:                "
				+ mThePool.getCapability(FPLibraryConstants.FP_RETENTION,
						FPLibraryConstants.FP_VARIABLE_RETENTION_MAX));
		
		System.out.println(
			"\tRetetion Fixed Min:                    "
				+ mThePool.getCapability(FPLibraryConstants.FP_RETENTION,
						FPLibraryConstants.FP_FIXED_RETENTION_MIN));
		
		System.out.println(
			"\tRetention Fixed Max :                  "
				+ mThePool.getCapability(FPLibraryConstants.FP_RETENTION,
						FPLibraryConstants.FP_FIXED_RETENTION_MAX));
		
		System.out.println(
			"\tRetention Default:                     "
				+ mThePool.getCapability(FPLibraryConstants.FP_RETENTION,
						FPLibraryConstants.FP_RETENTION_DEFAULT));
	
	}

	/**
	 * showGlobalOptions - display options that affect all pool connections.
	 *
	 * @throws FPLibraryException
	 */
	public void showGlobalOptions() throws FPLibraryException {

		// Display options that apply to all pool connections.
		System.out.println("\nGlobal Pool Options:\n");

		System.out.println(
			"\tMax pool connections:                  "
				+ FPPool.getGlobalOption(
					FPLibraryConstants.FP_OPTION_MAXCONNECTIONS));

		System.out.println(
			"\tRetry count:                           "
				+ FPPool.getGlobalOption(
					FPLibraryConstants.FP_OPTION_RETRYCOUNT));

		System.out.println(
			"\tSleep duration between retries:        "
				+ FPPool.getGlobalOption(
					FPLibraryConstants.FP_OPTION_RETRYSLEEP));

		System.out.println(
			"\tCluster unavailable time:              "
				+ FPPool.getGlobalOption(
					FPLibraryConstants.FP_OPTION_CLUSTER_NON_AVAIL_TIME));

		System.out.println(
			"\tEmbedded blob threshold(bytes):        "
				+ FPPool.getGlobalOption(
					FPLibraryConstants.FP_OPTION_EMBEDDED_DATA_THRESHOLD));

		System.out.println(
			"\tPool open strategy:                    "
				+ (FPPool
					.getGlobalOption(FPLibraryConstants.FP_OPTION_OPENSTRATEGY)
					== 0 ? "FP_NORMAL_OPEN" : "FP_LAZY_OPEN"));

	}

	/**
	 * showOptions - display options that affect all pool connections.
	 *
	 * @throws FPLibraryException
	 */
	public void showOptions() throws FPLibraryException {

		// Display options that are specific to this pool connection.
		System.out.println("\nPool Options:\n");

		System.out.println(
			"\tBuffersize:                            "
				+ mThePool.getOption(FPLibraryConstants.FP_OPTION_BUFFERSIZE));

		System.out.println(
			"\tPool connection timeout:               "
				+ mThePool.getOption(FPLibraryConstants.FP_OPTION_TIMEOUT));

		int clusterFailover =
			mThePool.getOption(
				FPLibraryConstants.FP_OPTION_ENABLE_MULTICLUSTER_FAILOVER);

		System.out.println(
			"\tMulticluster failover enabled:         "
				+ (clusterFailover == 1 ? "True" : "False"));

		if (clusterFailover == 1) {
			System.out.println(
				"\t\tRead failover strategy:        "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_READ_STRATEGY));

			System.out.println(
				"\t\tRead cluster strategy:         "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_READ_CLUSTERS));

			System.out.println(
				"\t\tWrite failover strategy:       "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_WRITE_STRATEGY));

			System.out.println(
				"\t\tWrite cluster strategy:        "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_WRITE_CLUSTERS));

			System.out.println(
				"\t\tDelete failover strategy:      "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_DELETE_STRATEGY));

			System.out.println(
				"\t\tDelete cluster strategy:       "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_DELETE_CLUSTERS));

			System.out.println(
				"\t\tExists failover strategy:      "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_EXISTS_STRATEGY));

			System.out.println(
				"\t\tExists cluster strategy:       "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_EXISTS_CLUSTERS));

			System.out.println(
				"\t\tQuery failover strategy:       "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_QUERY_STRATEGY));

			System.out.println(
				"\t\tQuery cluster strategy:        "
					+ FPPool.getGlobalOption(
						FPLibraryConstants
							.FP_OPTION_MULTICLUSTER_QUERY_CLUSTERS));
		}

		System.out.println(
			"\tCollision avoidance enabled:           "
				+ (mThePool.getOption(
						FPLibraryConstants.FP_OPTION_DEFAULT_COLLISION_AVOIDANCE)
					== 1 ? "True" : "False"));

		System.out.println(
			"\tPrefetch buffer size:                  "
				+ mThePool.getOption(FPLibraryConstants.FP_OPTION_PREFETCH_SIZE));

	}

	/**
	 * main
	 * 
	 * @throws FPLibraryException
	 * @throws Exception
	 */
	public static void main(String[] args) {

		int exitCode = 0;
		String appName="Get Cluster Info Sample";
	    String appVersion="3.1";
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		FPPool thePool = null;
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);

		try {

		  /*Stores your application's name and version for registration on Centera
	        This call should be made one time, before the FPPoolOpen() call,
	        for each application that interfaces with centera
	        *
	        Applications can also be registered via the environment variables 
	        FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	        will override what is set through environment variable.
		    */
		    FPPool.RegisterApplication(appName,appVersion);
			
			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();

			if (!answer.equals(""))
				poolAddress = answer;

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			thePool = new FPPool(poolAddress);

			// Create the example
			GetClusterInfo clusterInfo = new GetClusterInfo(thePool);

			// display both native and java library versions.
			clusterInfo.showFPLibraryVersion();

			// Display cluster time in GMT.
			clusterInfo.showClusterTime();

			// display information specific to this pool connection.
			clusterInfo.showPoolInfo();

			// display capabilities and corresponding values specific to
			// this cluster.
			clusterInfo.showPoolCapabilities();

			// display pool options set across all connections.
			clusterInfo.showGlobalOptions();

			// display pool options specific to this pool connection.
			clusterInfo.showOptions();

			// display retention classes defined on the cluster.					
			clusterInfo.showRetentionClasses();

			// Always close the Pool connection when finished.
			thePool.Close();
			System.out.println("\nClosed connection to Centera cluster");

			inputReader.close();
			stdin.close();

		} catch (FPLibraryException e) {
			exitCode = e.getErrorCode();
			System.out.println(
				"Error opening connection to Centera pool: "
					+ e.getErrorString()
					+ "(" + exitCode + ")");
		} catch (IOException e) {
			System.err.println("IO Error occured: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		} catch (Exception e) {
			System.out.println("Error occured: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		}

		System.exit(exitCode);
	}
}
