import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.filepool.fplibrary.FPClip;
import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;
import com.filepool.fplibrary.FPRetentionClassContext;
import com.filepool.fplibrary.FPRetentionClass;

/*****************************************************************************
 * 
 * Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
 * 
 * ManageRetention.java
 * 
 * Using the Centera Java API to manage the retention period of a
 * C-Clip
 * 
 * This sourcefile contains the intellectual property of EMC Corporation or
 * is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to
 * the terms and conditions of the License Agreement.
 *  
 ****************************************************************************/

/**
 * <p>
 * Title: ManageRetention
 * </p>
 * <p>
 * Description: Using the Centera Java API to manage the retention period of a
 * C-Clip
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class ManageRetention {

	/***********************************************************************
	 *
	 * main
	 * 
	 * @param args - command-line arguments
	 * 
	 ***********************************************************************/
	public static void main(String[] args) {
		int exitCode = 0;
		String appName="Manage Retention Sample";
	    String appVersion="3.1";
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);
		boolean assignRetentionClass = false;

		try {

		 /*Stores your application's name and version for registration on Centera
	       This call should be made one time, before the FPPoolOpen() call,
	       for each application that interfaces with centera
	       *
	       Applications can also be registered via the environment variables 
	       FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	       will override what is set through environment variable.
		   */
		    FPPool.RegisterApplication(appName,appVersion);
			    
			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();

			if (!answer.equals(""))
				poolAddress = answer;

			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// open cluster connection
			FPPool thePool = new FPPool(poolAddress);

			// Prompt user for clip ID we want to manipulate
			System.out.print("clip ID to modify: ");
			String clipID = stdin.readLine();

			if (clipID.equals(""))
				throw new IllegalArgumentException("Invalid answer.");

			// load C-Clip in tree (editable) mode
			System.out.print(
				"Attempting to load C-Clip for clip ID " + clipID + " ... ");

			FPClip theClip =
				new FPClip(thePool, clipID, FPLibraryConstants.FP_OPEN_ASTREE);

			System.out.println("Ok.");

			// Determine age of clip in seconds.
			long clipAge = (thePool.getClusterTime() - theClip.getCreationDate())/1000;

			// Get retention time of clip, for retention classes this still returns the period.
			long retentionTime = theClip.getRetentionPeriod();

			boolean canDelete = (clipAge >= retentionTime);
			
			if (canDelete)
			{
				System.out.println("Fixed retention on the clip has expired");

				if (theClip.isEBREnabled())
				{
					System.out.print("Clip has EBR enabled");
					
					if (theClip.getEBREventTime()> 0)
					{
						System.out.println(" and Event has not occurred ");
						canDelete = false;
					}
					else if (thePool.getClusterTime() < (theClip.getEBREventTime()+ theClip.getEBRPeriod()))
					{
						System.out.println(" and EBR period has not expired");
						canDelete = false;
					}
					
					if (!canDelete)
					{
						System.out.println("Old clip will not be able to be deleted");
					}
					else
					{
						System.out.println(" but the period has expired.");
					}
				}
				
				if (canDelete)
				{
					System.out.println("Old clip will be deleted after new clip created");
				}
			}

			// List out all retention classes available on cluster
			FPRetentionClassContext retentionClassList =
				thePool.getRetentionClassContext();

			int numClasses = retentionClassList.getNumClasses();

			System.out.println(
				"\t"
					+ numClasses
					+ " retention class"
					+ (numClasses > 1 ? "es are" : " is")
					+ " defined on the cluster.");

			if (numClasses > 0) {

				FPRetentionClass retentionClass = retentionClassList.getFirst();

				while (retentionClass != null) {
					System.out.println(
						"\t\tRetention class: \""
							+ retentionClass.getName()
							+ "\"\t has an interval of "
							+ retentionClass.getPeriod());

					retentionClass.close();
					retentionClass = retentionClassList.getNext();

				}

				// Prompt user if we want to use retention classes instead of setting a period.
				System.out.print(
					"Assign a retention class instead of a period?(Y or N)[Y]");
				String useRetentionClass = stdin.readLine();

				if (useRetentionClass.equals("")
					|| useRetentionClass.toLowerCase().startsWith("y")) {
					assignRetentionClass = true;
				} else if (!useRetentionClass.toLowerCase().startsWith("n")) {
					throw new IllegalArgumentException(
						"Invalid response: " + useRetentionClass);
				} else {
					assignRetentionClass = false;
				}

			} else if (numClasses == 0) {
				System.out.println("Zero retention classes are defined.");

			}

			if (assignRetentionClass) {
				// Prompt user for retention class to use.
				System.out.print("Enter name of retention class to assign: ");
				String retentionClassName = stdin.readLine();

				if (retentionClassName.equals(""))
					throw new IllegalArgumentException("Invalid response.");

				// Print out some info about the class before we assign it to the clip 
				FPRetentionClass retentionClass =
					retentionClassList.getNamedClass(retentionClassName);
				System.out.println(
					"Using retention class: " + retentionClass.getName());
				System.out.println(
					"\twhich has a period of: "
						+ retentionClass.getPeriod()
						+ " seconds");

				theClip.setRetentionClass(retentionClass);
				retentionClass.close();

			} else {
				// Prompt user for retention period to use, then assign
				System.out.print("Enter retention period to assign: ");
				String retentionPeriodString = stdin.readLine();

				if (retentionPeriodString.equals(""))
					throw new IllegalArgumentException("Invalid response.");

				theClip.setRetentionPeriod(
					Integer.parseInt(retentionPeriodString));

			}

			// A new ID is generated since the clip was modified.
			String newClipID = theClip.Write();

			System.out.println("New clip ID: " + newClipID);

			theClip.Close();
			retentionClassList.close();

			// After writing the updated clip, the old CDF still exists on
			// the Centera, with the original clip ID. If the fixed and any EBR
			// period of this CDF has expired, we can delete it; if not,
			// deletion will fail with an exception.
			// Note that deleting a CDF does not delete any associated blobs;
			// blobs with no clip references are deleted automatically by
			// Centera's garbage collection process.
			if (canDelete) {
				System.out.print(
					"Attempting to delete original C-Clip " + clipID + " ... ");

				FPClip.AuditedDelete(
					thePool,
					clipID,
					"ManageRetention java example",
					FPLibraryConstants.FP_OPTION_DEFAULT_OPTIONS);

				System.out.println("Deleted.");

			}

			// Always close the Pool connection when finished.  Not a
			// good practice to open and close for each transaction.
			thePool.Close();
			System.out.println(
				"\nClosed connection to Centera cluster (" + poolAddress + ")");

			inputReader.close();
			stdin.close();

		} catch (FPLibraryException e) {
			exitCode = e.getErrorCode();
			System.err.println(
				"Centera Error: " + e.getMessage() + "(" + exitCode + ")");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("I/O Error occured: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		}
		System.exit(exitCode);
	}
}