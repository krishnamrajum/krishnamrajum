import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import com.filepool.fplibrary.FPClip;
import com.filepool.fplibrary.FPFileInputStream;
import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;
import com.filepool.fplibrary.FPTag;

/*****************************************************************************
 * 
 * Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
 * 
 * StoreContent.java
 * 
 * Using the Centera Java API to store content onto Centera.
 * 
 * This sourcefile contains the intellectual property of EMC Corporation or
 * is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to
 * the terms and conditions of the License Agreement.
 *  
 ****************************************************************************/

/**
 * <p>
 * Title: StoreContent
 * </p>
 * <p>
 * Description: Using the Centera Java API to store content onto Centera.
 *  
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class StoreContent {

	private static FPPool thePool = null;
    private static String appVersion="3.1";
    private static String appName = "StoreContentSample";

	/**
	 * saveIDToFile - writes the content address to the file
	 * "Filename.clipID"
	 * 
	 * @param clipID
	 * @param filename
	 * @throws IllegalArgumentException
	 */
	private static void saveIDToFile(String clipID, String filename)
		throws IllegalArgumentException {
		String clipIDFilename = filename;
		clipIDFilename += ".clipID";

		try {
			FileWriter clipIDWriter = new FileWriter(clipIDFilename);
			clipIDWriter.write(clipID.toString());
			clipIDWriter.close();
			System.out.println(
				"Clip ID of C-Clip written to file \""
					+ clipIDFilename
					+ "\".");
		} catch (IOException e) {
			throw new IllegalArgumentException(
				"Problem saving clip ID to file \""
					+ clipIDFilename
					+ "\"\nObject successfully stored as clip ID \""
					+ clipID);
		}
	}

	/**
	 * storeFile - Creates a new clip and writes the filename out to a blob.
	 *
	 * @param filename
	 * @return clipID
	 * @throws FPLibraryException
	 */
	private static String storeFile(String filename)
		throws FPLibraryException {

		long retentionPeriod = 0;
		String clipID = "";
		String CLIP_NAME = "Store-Content-File";
		String VENDOR_NAME = "EMC";
		String TAG_NAME = "StoreContentObject";

		try {

			// create a new named C-Clip
			FPClip theClip = new FPClip(thePool, CLIP_NAME);

			// It's a good practice to write out vendor, application and version info
			theClip.setDescriptionAttribute("app-vendor", VENDOR_NAME);
			theClip.setDescriptionAttribute("app-name", appName);
			theClip.setDescriptionAttribute("app-version", appVersion);

			// It's a good idea to explicitly set retention period.  For more info
			// on retention periods and classes see ManageRetention example.
			theClip.setRetentionPeriod(retentionPeriod);

			FPFileInputStream inputStream = new FPFileInputStream(new File(filename));

			FPTag topTag = theClip.getTopTag();

			FPTag newTag = new FPTag(topTag, TAG_NAME);

			topTag.Close();

			// Blob size is written to clip, so  lets just write out filename.
			newTag.setAttribute("filename", filename);

			// write the binary data for this tag to the Centera
			newTag.BlobWrite(inputStream);

			clipID = theClip.Write();
			System.out.println(
				"Clip stored. The returned clip ID is " + clipID + ".");

			inputStream.close();
			newTag.Close();
			theClip.Close();

		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException(
				"Could not open file \"" + filename + "\" for reading");
		} catch (IOException e) {
			System.err.println("Error reading from file \"" + filename);
			e.printStackTrace();
		}

		return (clipID);
	}

	/**
	 * main
	 * 
	 */
	public static void main(String[] args) {

		String appName="Store Content Sample";
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		int exitCode = 0;
		
		// Threshold for when to embed blobs in CDF, in bytes
		int embeddedBlobsize = 50000;
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);

		try {

		 /*Stores your application's name and version for registration on Centera
	       This call should be made one time, before the FPPoolOpen() call,
	       for each application that interfaces with centera
	       *
	       Applications can also be registered via the environment variables 
	       FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	       will override what is set through environment variable.
		   */
		    FPPool.RegisterApplication(appName,appVersion);
		    
			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();

			if (!answer.equals(""))
				poolAddress = answer;

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// open cluster connection
			thePool = new FPPool(poolAddress);

			// Prompt user for embedded blob size
			System.out.print(
				"Maximum blob size to embed data in CDF["
					+ embeddedBlobsize
					+ "]: ");
			answer = stdin.readLine();

			if (!answer.equals(""))
				embeddedBlobsize = Integer.parseInt(answer);

			// New feature for 2.3 embedded blobs
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_EMBEDDED_DATA_THRESHOLD,
				embeddedBlobsize);

			System.out.print("Filename to store: ");

			String filename = stdin.readLine();
			if (filename.equals(""))
				throw new IllegalArgumentException("Invalid answer.");

			long fileSize = new File(filename).length();

			if (fileSize > embeddedBlobsize) {
				System.out.println(
					"File is larger than embedded blob threshold - will be stored outside the CDF.");

			} else {
				System.out.println(
					"File size is less than embedded blob threshold - will be stored embedded in the CDF.");
			}

			// Store our file on centera
			String clipID = storeFile(filename);

			// save ClipID in file for later retrieval
			saveIDToFile(clipID, filename);

			// Always close the Pool connection when finished.
			thePool.Close();
			System.out.println(
				"\nClosed connection to Centera cluster (" + poolAddress + ")");

			inputReader.close();
			stdin.close();

		} catch (FPLibraryException e) {
			exitCode = e.getErrorCode();
			System.err.println(
				"Centera SDK Error: " + e.getMessage() + "(" + exitCode + ")");
		} catch (IOException e) {
			System.out.println("I/O Error occured: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		}

		System.exit(exitCode);

	}

}
