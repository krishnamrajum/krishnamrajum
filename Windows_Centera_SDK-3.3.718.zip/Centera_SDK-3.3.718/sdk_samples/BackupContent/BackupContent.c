/******************************************************************************\
*
* Copyright (c) 2001-2006 EMC Corporation
* All Rights Reserved
*
* BackupContent.c
*
* BackupContent Source File Build Version @version.full@
*
* This sourcefile contains the intellectual property of EMC Corporation
* or is licensed to EMC Corporation from third parties. Use of this sourcefile
* and the intellectual property contained therein is expressly limited to the
* terms and conditions of the License Agreement.
*
\******************************************************************************/

/*
* Example - Using The Centera Access API To Backup a C-Clip.
*
* This example shows how to serialize the CDF to a local flat file.
* The IP address(es) of the access node(s) to the cluster, the content address of the
* C-Clip and the embedded blob threshold are entered via the command line.
*
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

/*
* The standard header file for the Centera access API.
* This includes all function prototypes and type
* definitions needed to use the access API.
*/
#include <FPAPI.h>

#define BUFSIZE (128 + 1)
#define MAX_NAME_SIZE BUFSIZE

int readCDFToScreen(const FPClipRef);
int readCDFToFile(const FPClipRef, const FPClipID);
char **inputData(const char *, const int, const char *[], const char *[], const char *[]);
FPInt checkAndPrintError(const char *);


int main(int argc, char *argv[])
{
	FPClipID clipID;
	FPInt retCode;
	int index;
	FPPoolRef poolRef;

	const char *appVersion="3.1";
	const char *appName = "Backup Content";
	const int numParameters = 2;
	const char *prompts[] = { "Enter the IP address or DNS name of the cluster(s)",
		"Enter the Content Address of the object to be read"};
	const char *choices[] = { "" , "" };
	const char *defaults[] = { "us1cas1.centera.org,us1cas2.centera.org", "" };

	char **values = inputData(appName, numParameters, prompts, choices, defaults);
	const char *poolAddress = values[0];
	strcpy(clipID, values[1]);

	/*Stores your application's name and version for registration on Centera
	This call should be made one time, before the FPPoolOpen() call,
	for each application that interfaces with centera
	*
	Applications can also be registered via the environment variables 
	FP_OPTION_APP_NAME and FP_OPTION_APP_VER but any value set using the API call
	will override them.
	*/
	FPPool_RegisterApplication(appName,appVersion);
	retCode = checkAndPrintError("Application Registration Error: ");

	/* Use LazyOption for opening pools as it is more efficient */
	FPPool_SetGlobalOption(FP_OPTION_OPENSTRATEGY, FP_LAZY_OPEN);

	/*
	* Open up the Pool
	*/

	poolRef = FPPool_Open(poolAddress);
	retCode = checkAndPrintError("Pool Open Error: ");
	if (!retCode)
	{
		/*
		* Open the C-Clip and read the C-Clip to the memory
		* FLAT mode is more efficient, so use it if you do not need it the hierarchical
		* structure offered by using ASTREE.
		*/
		FPClipRef clipRef = FPClip_Open(poolRef, clipID, FP_OPEN_FLAT);
		retCode = checkAndPrintError("C-Clip Open Error: ");
		if (!retCode)
		{
			/* Retrieve the CDF of the C-Clip and display it to the screen */
			FPStreamRef stream = FPStream_CreateToStdio();
			retCode = checkAndPrintError("Stream Create Error: ");
			if (!retCode)
			{
				/*
				* Read the content of the C-Clip to the stream
				* Due to the server limitation, the stream should not take longer than 1 minute
				* per iteration to store the data received from the server
				*/
				FPClip_RawRead(clipRef, stream);
				retCode = checkAndPrintError("C-Clip Raw Read Error When Reading The Meta Data To The Screen: ");
				/*
				* Close the stream
				*/
				FPStream_Close(stream);
				retCode = checkAndPrintError("Stream Close Error: ");


				if (!retCode)
				{
					/* Retrieve and save the C-Clip to files. The CDF is named clipID.xml, the tags clipID.TagX.
					* For example:
					*	C-Clip ID: 3O3UF578EUP01e701TM29V44Q6G
					*	CDF output file: 3O3UF578EUP01e701TM29V44Q6G.xml
					*	Blob on Tag1: 3O3UF578EUP01e701TM29V44Q6G.Tag1
					*/
					FPStreamRef fpStreamRef;
					char cdfFile[MAX_NAME_SIZE];
					char tagFileName[MAX_NAME_SIZE];
					FPTagRef myTag;
					FPBool finished = false;
					int tagNumber = 0;

					sprintf(cdfFile, "%s.xml", clipID);

					/*
					* Create a file stream to write the data to
					*/
					fpStreamRef = FPStream_CreateFileForOutput(cdfFile, "wb");
					retCode = checkAndPrintError("Stream Create Error: ");
					if (!retCode)
					{
						FPClip_RawRead(clipRef, fpStreamRef);
						retCode = checkAndPrintError("C-Clip Raw Read Error When Reading The Meta Data To The File: ");

						if (!retCode)
							fprintf(stdout, "\nXML content data saved to file %s\n", cdfFile);

						FPStream_Close(fpStreamRef);
						retCode = checkAndPrintError("Stream Close Error: ");
					}

					/*
					* Now iterate across the tags and write out any blobs that are present
					*/

					do
					{
						myTag = FPClip_FetchNext(clipRef);
						retCode = checkAndPrintError("Fetch Next Tag Error: ");

						if (myTag == 0)
						{
							finished = true;
						}
						else
						{

							if (FPTag_BlobExists(myTag) != -1)
							{
								sprintf(tagFileName, "%s.Tag%d", clipID, tagNumber);
								fpStreamRef = FPStream_CreateFileForOutput(tagFileName, "wb");
								retCode = checkAndPrintError("Tag Stream Create Error: ");

								if (!retCode)
								{
									FPTag_BlobRead(myTag, fpStreamRef, FP_OPTION_DEFAULT_OPTIONS);
									retCode = checkAndPrintError("Blob Read Error on Tag: ");

									if (!retCode)
										fprintf(stdout, "\nTag %d saved to file %s\n", tagNumber, tagFileName);

									FPStream_Close(fpStreamRef);
									retCode = checkAndPrintError("Stream Close Error: ");
								}

								FPTag_Close(myTag);
								retCode = checkAndPrintError("Stream Close Error: ");
							}
						}

						tagNumber++;

					} while (!finished);
				}

			}
			/*
			* Close the C-Clip
			*/
			FPClip_Close(clipRef);
			retCode = checkAndPrintError("C-Clip Close Error: ");
		}
		/*
		* Close the pool
		*/
		FPPool_Close(poolRef);
		retCode = checkAndPrintError("Pool Close Error: ");
	}

	for (index=0;index<numParameters; index++)
	{
		free(values[index]);
	}
	free(values);
	return retCode;
}


char **inputData(const char *header,
				 const int  numParameters,
				 const char *prompts[],
				 const char *validOptions[],
				 const char *defaults[])
{
	int i;
	char buffer[BUFSIZE];
	char **values = (char **) malloc(numParameters * sizeof(char *));

	fprintf(stderr, "Enter values or leave blank to use defaults:\n\n");

	i = 0;
	while (i < numParameters)
	{
		FPBool valid = false;

		if (*prompts[i] !=  '\0')
			fprintf(stderr, "%s: ", prompts[i]);

		if (*validOptions[i] != '\0')
			fprintf(stderr, " Valid options [%s] ", validOptions[i]);

		if (*defaults[i] != '\0')
			fprintf(stderr, " <%s> ", defaults[i]);

		fgets(buffer, sizeof(buffer), stdin);
		buffer[strlen(buffer) - 1] = '\0';  /* Remove the terminating \n */

		if (buffer[0] == '\0')
		{
			if (*defaults[i] != '\0') /* Accept the default */
			{
				values[i] = (char *) malloc((strlen(defaults[i])+1) * sizeof(char));
				strcpy(values[i], defaults[i]);
				valid = true;
			}
			else
			{
				fprintf(stdout, "There is no default value - please enter data\n");
			}
		}
		else
		{
			/* Test that data is valid */
			if (*validOptions[i] == '\0') /* No choices to validate so accept what user entered */
			{
				values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
				strcpy(values[i], buffer);
				valid = true;
			}
			else
			{
				const char *substr = (const char *) strstr((char *) validOptions[i], buffer);

				if (substr) /* Input is within the validOptions string - check the if it is the whole value */
				{
					const char *optionEnd =  strchr(substr, '|');

					if (optionEnd)
					{
						int length = (int) (optionEnd - substr);

						if (length == (int) strlen(buffer))
							valid = true;
					}
					else
						valid = true;
				}


				if (!valid)
					fprintf(stderr, "%s is not in valid choices: [%s]\n", buffer, validOptions[i]);
				else
				{
					values[i] = (char *) malloc((strlen(buffer)+1) * sizeof(char));
					strcpy(values[i], buffer);
				}
			}
		}
		if (valid)
			++i;
	}

	return values;
}

FPInt checkAndPrintError(const char *errorMessage)
{
	/* Get the error code of the last SDK API function call */
	FPInt errorCode = FPPool_GetLastError();
	if (errorCode != ENOERR)
	{
		FPErrorInfo errInfo;
		fprintf(stderr, errorMessage);
		/* Get the error message of the last SDK API function call */
		FPPool_GetLastErrorInfo(&errInfo);
		if (!errInfo.message) /* the human readable error message */
			fprintf(stderr, "%s\n", errInfo.errorString);
		else if (!errInfo.errorString) /* the error string corresponds to an error code */
			fprintf(stderr, "%s\n", errInfo.message);
		else
			fprintf(stderr, "%s%s%s\n",errInfo.errorString," - ",errInfo.message);
	}

	return errorCode;
}






