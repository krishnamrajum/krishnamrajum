import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileOutputStream;
import java.io.IOException;

import com.filepool.fplibrary.FPClip;
import com.filepool.fplibrary.FPLibraryConstants;
import com.filepool.fplibrary.FPLibraryException;
import com.filepool.fplibrary.FPPool;
import com.filepool.fplibrary.FPTag;

/*****************************************************************************
 * 
 * Copyright (c) 2001-2006 EMC Corporation All Rights Reserved
 * 
 * RetrieveContent.java
 * 
 * Using the Centera Java API to retreive content from Centera.
 * 
 * This sourcefile contains the intellectual property of EMC Corporation or
 * is licensed to EMC Corporation from third parties. Use of this sourcefile
 * and the intellectual property contained therein is expressly limited to
 * the terms and conditions of the License Agreement.
 *  
 ****************************************************************************/

/**
 * <p>
 * Title: RetrieveContent
 * </p>
 * <p>
 * Description: Using the Centera Java API to retreive content from Centera.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company: EMC Corp.
 * </p>
 */
public class RetrieveContent {

	/**
	 * main
	 * 
	 */
	public static void main(String[] args) {

		int exitCode = 0;
		String appName="Retrieve Content Sample";
	    String appVersion="3.1";
		String poolAddress = "us1cas1.centera.org,us1cas2.centera.org";
		String TAG_NAME = "StoreContentObject";
		InputStreamReader inputReader = new InputStreamReader(System.in);
		BufferedReader stdin = new BufferedReader(inputReader);

		try {

		 /*Stores your application's name and version for registration on Centera
	       This call should be made one time, before the FPPoolOpen() call,
	       for each application that interfaces with centera
	       *
	       Applications can also be registered via the environment variables 
	       FP_OPTION_APP_NAME and FP_OPTION_APP_VER The values set through API
	       will override what is set through environment variable.
		   */
		    FPPool.RegisterApplication(appName,appVersion);
			    
			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			// Prompt user for cluster to connect to
			System.out.print("Address of cluster[" + poolAddress + "]: ");
			String answer = stdin.readLine();

			if (!answer.equals(""))
				poolAddress = answer;

			System.out.println(
				"Connecting to Centera cluster(" + poolAddress + ")");

			// New feature for 2.3 lazy pool open
			FPPool.setGlobalOption(
				FPLibraryConstants.FP_OPTION_OPENSTRATEGY,
				FPLibraryConstants.FP_LAZY_OPEN);

			// open cluster connection
			FPPool thePool = new FPPool(poolAddress);

			System.out.print("clip ID to retrieve: ");
			String clipID = stdin.readLine();

			if (clipID.equals(""))
				throw new IllegalArgumentException("Invalid answer.");

			// Contact cluster to load C-Clip
			System.out.print(
				"Attempting to load C-Clip with clip ID " + clipID + " ... ");

			FPClip theClip =
				new FPClip(thePool, clipID, FPLibraryConstants.FP_OPEN_FLAT);

			System.out.println("Ok.");

			FPTag topTag = theClip.getTopTag();

			// check clip metadata to see if this is 'our' data format			
			if (!topTag.getTagName().equals(TAG_NAME)) {
				throw new IllegalArgumentException("This clip was not written by the 'Store Content' sample.");
			}

			// Get filename from tag attributes
			String origFilename = topTag.getStringAttribute("filename");
			String saveFilename = origFilename + ".out";

			// Save blob data to file 'OrigFilename.out'
			FileOutputStream outFile = new FileOutputStream(saveFilename);
			System.out.print("Retrieving file data... ");
			topTag.BlobRead(outFile);
			System.out.println("Ok.");

			outFile.close();
			topTag.Close();
			theClip.Close();

			// Always close the Pool connection when finished.
			thePool.Close();
			System.out.println(
				"\nClosed connection to Centera cluster (" + poolAddress + ")");

			inputReader.close();
			stdin.close();

		} catch (FPLibraryException e) {
			exitCode = e.getErrorCode();
			System.err.println(
				"Centera SDK Error: " + e.getMessage() + "(" + exitCode + ")");
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		} catch (IOException e) {
			System.err.println("IO Error occured: " + e.getMessage());
			e.printStackTrace();
			exitCode = -1;
		}

		System.exit(exitCode);
	}
}
