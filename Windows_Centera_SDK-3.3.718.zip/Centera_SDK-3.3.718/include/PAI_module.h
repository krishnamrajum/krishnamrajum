/******************************************************************************\
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * All Rights Reserved
 *
 * PAI_module.h
 *
 * PAI module Header File Build Version 3.3.100
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/
/******************************************************************************\
 *
 * The reference implementation of a Pool Access Information (PAI) module
 *
 * This file defines the class used for C++ API interface
 *
 * DO NOT alter this file when implementing a PAI module!!!
 * 
\******************************************************************************/
#ifndef __PAI_MODULE_H_
#define __PAI_MODULE_H_

#include "PAI_profile.h"

extern const char *versionString;

////////////////////////////////////////////////////////////////////////////////
/**
 * Main PAI class
 */
class PAI_MODULE_API PAI_module
{
 protected:
	PAIRef lastID;
	long n_profiles;
	PAI_profile **profile;

	long getProfileIndex (PAIRef inRef);
	long newProfile (const char *inPoolName, PAIRef &outRef);

 public:
	/**************************************************************************\
	 * Credential Store "get" methods
	\**************************************************************************/
	long loadProfile (const char *inPoolName, PAIRef &outRef);
    int  getProfileClusters (const char* inConnectionString, char*** outConnectionStrings, int* outNumberOfConnectionStrings);
    void freeProfileClusterStrings(char*** outConnectionStrings, int inSize);
    long getVersion (const PAIRef inRef, char *outVersion, PAI_UNSIGNED_SHORT *ioVersionLen);
    long getAddress (const PAIRef inRef, char *outAddress, PAI_UNSIGNED_SHORT *ioAddressLen);
	long getUserName (const PAIRef inRef,
	                  char *inKeyType, char *inKeyID, 
	                  char *outName, PAI_UNSIGNED_SHORT *ioNameLen);
	long getCredential (const PAIRef inRef,
	                    char *inKeyType, char *inKeyID,
						char *inCredentialID, 
	                    char *outCredential, PAI_UNSIGNED_SHORT *ioCredentialLen);

	/**************************************************************************\
	 * Credential Store "set" methods
	\**************************************************************************/
	long addUserName (const PAIRef inRef,
	                  const char *inKeyType, const char *inKey, 
					  const char *inUserName);
	long addCredential (const PAIRef inRef,
	                    const char *inKeyType, const char *inKey, 
						const char *inCredentialID,
	                    const char *inCredential, PAI_UNSIGNED_SHORT inCredentialLen);

	// delete a section within the credential store
	long deleteAccessInfo (const PAIRef inRef, 
	                       const char *inKeyType, const char *inKey);

	/**************************************************************************\
	 * Credential Store Management methods
	\**************************************************************************/
	long deleteProfile (const PAIRef inRef);
	long updateProfile (const PAIRef inRef);
	long closeProfile (const PAIRef inRef);
	long createProfile (const char *inPoolName, PAIRef &outRef);

	/**************************************************************************\
	 * Constructors
	\**************************************************************************/
	PAI_module (void);

	/**************************************************************************\
	 * Destructors
	\**************************************************************************/
	~PAI_module();
};

////////////////////////////////////////////////////////////////////////////////
/**
 * Main PAI instance
 */
extern PAI_module module;

#endif // __PAI_MODULE_H_
