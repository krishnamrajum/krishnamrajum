#ifndef __FPAPI_LOG__
#define __FPAPI_LOG__
/*****************************************************************************
 *
 * Copyright (c) 2001-2006 EMC Corporation
 * Unpublished - All Rights Reserved
 *
 * FPLog.h
 *
 * FPLibrary Header File Build Version 3.3.718
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
 * EMC2  , EMC, Symmetrix, Celerra, CLARiiON, CLARalert, DG, E-Infostructure,
 * HighRoad, Navisphere, PowerPath, ResourcePak, SnapView/IP, SRDF, VisualSAN,
 * where information lives, and The EMC Effect are registered trademarks and EMC
 * Automated Networked Storage, EMC ControlCenter, EMC Developers Program, EMC
 * Enterprise Storage, EMC Enterprise Storage Network, EMC OnCourse, EMC Proven,
 * EMC Snap, Access Logix, AutoAdvice, Automated Resource Manager, AutoSwap,
 * AVALONidm, C-Clip, CacheStorm, Celerra Replicator, Centera, CentraStar,
 * CLARevent, Connectrix, CopyCross, CopyPoint, CrosStor, Direct Matrix, Direct
 * Matrix Architecture, EDM, E-Lab, Enginuity, FarPoint, FLARE, GeoSpan, InfoMover,
 * MirrorView, NetWin, OnAlert, OpenScale, Powerlink, PowerVolume, RepliCare,
 * SafeLine, SAN Architect, SAN Copy, SAN Manager, SDMS, SnapSure, SnapView,
 * StorageScope, SupportMate, SymmAPI, SymmEnabler, Symmetrix DMX, TimeFinder,
 * Universal Data Tone, and VisualSRM are trademarks of EMC Corporation. All other
 * trademarks used herein are the property of their respective owners.
 *
 * ---------------------------------------------------------------------------
 * Copyright ) 1991-2, RSA Data Security, Inc. Created 1991.
 * All rights reserved.
 * License to copy and use this software is granted provided
 * that it is identified as the "RSA Data Security, Inc. MD5
 * Message-Digest Algorithm" in all material mentioning or
 * referencing this software or this function.
 * RSA Data Security, Inc. makes no representations concerning
 * either the merchantability of this software or the
 * suitability of this software for any particular purpose. It
 * is provided "as is" without express or implied warranty of any kind.
 *
 * These notices must be retained in any
 * copies of any part of this documentation and/or software.
 *
 * ---------------------------------------------------------------------------
 * Copyright and Licensing Information for ACE(TM)
 * http://www.cs.wustl.edu/~schmidt/ACE-copying.html
 *
 *****************************************************************************/
 
/**
  @file FPLog.h
   FPLibrary Logging header file.
   This file contains all the definitions necessary to utilize the logging functionality
   of FPLibrary.
*/
 
#include <FPTypes.h>
#if !defined(__SASC__)
#include <wchar.h>
#endif
 
/** @defgroup Logging Logging functions
    @{
 
    The logging functions are a set of function calls that provide
    full control over the SDK logger.
*/
 
#ifdef __MWERKS__
#pragma mark Logging functions
#endif
 
/** @name FP_LOGGING Options
    @{  */
#define FP_LOGGING_COMPONENT_POOL       0x00000001
#define FP_LOGGING_COMPONENT_RETRY      0x00000002
#define FP_LOGGING_COMPONENT_XML        0x00000004
#define FP_LOGGING_COMPONENT_API        0x00000008
#define FP_LOGGING_COMPONENT_NET        0x00000010
#define FP_LOGGING_COMPONENT_TRANS      0x00000020
#define FP_LOGGING_COMPONENT_PACKET     0x00000040
#define FP_LOGGING_COMPONENT_EXCEPT     0x00000080
#define FP_LOGGING_COMPONENT_REFS       0x00000100
#define FP_LOGGING_COMPONENT_MOPI       0x00000200
#define FP_LOGGING_COMPONENT_STREAM     0x00000400
#define FP_LOGGING_COMPONENT_CSOD       0x00000800
#define FP_LOGGING_COMPONENT_CSO        0x00001000
#define FP_LOGGING_COMPONENT_MD5        0x00002000
#define FP_LOGGING_COMPONENT_APP        0x00004000  /* Application level logging (FPLogging_Log) */
#define FP_LOGGING_COMPONENT_SHA        0x00040000
#define FP_LOGGING_COMPONENT_LIB        0x00080000  /* Library loading */
#define FP_LOGGING_COMPONENT_ALL        0xFFFFFFFF & ~FP_LOGGING_COMPONENT_REFS
 
#define FP_LOGKEEP_OVERWRITE    0x00000100  /* Replace any existing file (default) */
#define FP_LOGKEEP_APPEND       0x00000200  /* Append to any existing file */
#define FP_LOGKEEP_CREATE       0x00000400  /* Create a new log file name by appending timestamp to name */
 
#define FP_LOG_NO_POLLING               -1
#define FP_LOG_SIZE_UNBOUNDED           -1
 
typedef enum {
    FP_LOGLEVEL_ERROR  = 1,      /* log only error messages */
    FP_LOGLEVEL_WARN   = 2,      /* log errors and warnings */
    FP_LOGLEVEL_LOG    = 3,      /* log errors, warnings and log msgs */
    FP_LOGLEVEL_DEBUG  = 4       /* debug level  log EVERYTHING! (default) */
} FPLogLevel;
 
typedef enum {
    FP_LOGFORMAT_XML  = 0x00000001,  /* XML format */
    FP_LOGFORMAT_TAB  = 0x00000002   /* TAB delimited format (default) */
} FPLogFormat;
 
typedef FPLong FPLogStateRef;
 
/* Logging Callback function declaration
 * (Returns 0 on success, non-zero on callback failure)
 *
 * Register a callback function with the logging mechanism
 * using the FPLogging_RegisterCallback() method.
 */
typedef FPInt (*FPLogProc) (char* inString) ;
 
/** @} */
 
 
#ifdef __cplusplus
extern "C" {
#endif
 
  /**
    Enables the logging mechanism (utilizing the given log configuration).
 
    If logging has already been configured via environment variables, this
    method will restart the logging mechanism using the new settings (potentially
    closing the old log file and opening a new one).
 
    @param inLogState   A reference to an FPLogState object containing log configuration details.
                        Pass FPREF_NULL to use all default state settings.
 
    @since 3.2
   */
  EXPORT void DECL FPLogging_Start(FPLogStateRef inLogState);
 
  /**
    Disables the logging mechanism.
 
    Any open log files are flushed/closed as a result of this call.
    Any log state file polling is also disabled.
 
    @since 3.2
   */
  EXPORT void DECL FPLogging_Stop();
 
  /**
    Write a message to the Centera API log.
 
    @param inLogLevel The level at which to log the message.
                      The following log levels are available:
                      <dl>
                      <dt>     FP_LOGLEVEL_ERROR  <dd> - Log error messages </dd></dt>
                      <dt>     FP_LOGLEVEL_WARN   <dd> - Log warnings and error messages. </dd></dt>
                      <dt>     FP_LOGLEVEL_LOG    <dd> - Log API calls, warnings, and errors. </dd></dt>
                      <dt>     FP_LOGLEVEL_DEBUG  <dd> - Debug log level. </dd></dt>
                      </dl>
 
    @param inMessage  A null-terminated string to write to the log
    @since 3.2
   */
  EXPORT void DECL FPLogging_Log(const FPLogLevel inLogLevel, const char *inMessage);
 
  /**
     uses UTF-8 encoding
     @see FPLogState_Log()
     @since 3.2
   */
  EXPORT void DECL FPLogging_Log8(const FPLogLevel inLogLevel, const char *inMessage);
 
  /**
     uses UTF-16 encoding
     @see FPLogState_Log()
     @since 3.2
   */
  EXPORT void DECL FPLogging_Log16(const FPLogLevel inLogLevel, const FPChar16 *inMessage);
 
  /**
     uses UTF-32 encoding
     @see FPLogState_Log()
     @since 3.2
   */
  EXPORT void DECL FPLogging_Log32(const FPLogLevel inLogLevel, const FPChar32 *inMessage);
 
  /**
     uses wide characters
     @see FPLogState_Log()
     @since 3.2
   */
  EXPORT void DECL FPLogging_LogW(const FPLogLevel inLogLevel, const wchar_t *inMessage);
 
  /**
    Registers an application callback method with the logging mechanism.
 
    If this callback is specified, the logging mechanism will use the method
    pointed to by inCallback to log an event instead of directing the output to a file.
 
    If the logging mechanism was already enabled before calling this method, all
    log output will be redirected to the callback and will not appear in the log file.
    If the callback is disabled, subsequent log output will continue to appear in the
    log file.
 
    The callback may be disabled by passing NULL to this method, or by utilizing
    the "disable_callback" field in an active FPLogState object (see FPLogState_SetDisableCallback).
    @since 3.2
   */
  EXPORT void DECL FPLogging_RegisterCallback(FPLogProc inCallback);
 
  /**
    Creates an FPLogState object (containing all default field values).
    The resources allocated by this method should be released using
    FPLogState_Delete when the reference is no longer needed.
 
    @note All logging environment variables are checked when building
          a new FPLogState object. If any of the env vars are set,
          those values will be used to initialize the corresponding
          field in the log state object. If no logging env vars are set,
          the object will contain all default field values.
 
    @returns A reference to the log state object, or FPREF_NULL on error.
    @since 3.2
   */
  EXPORT FPLogStateRef DECL FPLogging_CreateLogState();
 
  /**
    De-serializes (loads) an FPLogState properties file into an FPLogState object.
    Resources should be released using FPLogState_Delete when the reference
    is no longer needed.
 
    Note that if this method is used to open an FPLogState file from disk,
    the log state file will be polled (every 5 min by default). This poll
    interval may be specified (or disabled) using the FPLogState_SetPollInterval API call.
 
    @param   inPathName         Full path to a serialized FPLogState properties file
    @returns A reference to an allocated FPLogState object.
    @since 3.2
   */
  EXPORT FPLogStateRef DECL FPLogging_OpenLogState(char* inPathName);
 
  /**
     uses UTF-8 encoding
     @see FPLogState_OpenLogState()
     @since 3.2
   */
  EXPORT FPLogStateRef DECL FPLogging_OpenLogState8(char *inPathName);
 
  /**
     uses UTF-16 encoding
     @see FPLogState_OpenLogState()
     @since 3.2
   */
  EXPORT FPLogStateRef DECL FPLogging_OpenLogState16(FPChar16 *inPathName);
 
  /**
     uses UTF-32 encoding
     @see FPLogState_OpenLogState()
     @since 3.2
   */
  EXPORT FPLogStateRef DECL FPLogging_OpenLogState32(FPChar32 *inPathName);
 
  /**
     uses wide characters
     @see FPLogState_OpenLogState()
     @since 3.2
   */
  EXPORT FPLogStateRef DECL FPLogging_OpenLogStateW(wchar_t *inPathName);
 
  /**
    Releases all resources associated with an FPLogState object.
    This method should be used in combination with FPLogging_CreateLogState()
    and FPLogging_OpenLogState() to delete an allocated FPLogState object.
 
    @param inLogState  A reference to an FPLogState object.
    @since 3.2
   */
  EXPORT void DECL FPLogState_Delete(FPLogStateRef inLogState);
 
  /**
    Updates the "LogPath" field of the FPLogState object.
    This field directs the logging mechanism to write to the file specified in
    inPathName.
 
    The default value of this field may be initialized by setting the
    "FP_LOGPATH" environment variable.
 
    @param ioLogState  A reference to an FPLogState object.
    @param inPathName  String containing a full log file path.
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogPath(FPLogStateRef ioLogState, char *inPathName);
 
  /**
     uses UTF-8 encoding
     @see FPLogState_SetLogPath()
     @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogPath8(FPLogStateRef ioLogState, char *inPathName);
 
  /**
     uses UTF-16 encoding
     @see FPLogState_SetLogPath()
     @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogPath16(FPLogStateRef ioLogState, FPChar16 *inPathName);
 
  /**
     uses UTF-32 encoding
     @see FPLogState_SetLogPath()
     @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogPath32(FPLogStateRef ioLogState, FPChar32 *inPathName);
 
  /**
     uses wide characters
     @see FPLogState_SetLogPath()
     @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogPathW(FPLogStateRef ioLogState, wchar_t *inPathName);
 
  /**
    Updates the "AppendMode" field of the FPLogState object.
    This field directs the logging mechanism whether or not to append to any existing
    file found at the given LogPath.
 
    The default value of this field may be initialized by setting the
    "FP_LOGKEEP" environment variable.
 
    @param ioLogState    A reference to an FPLogState object.
    @param inAppendMode  Set true if append is allowed, or false (default) for overwrite.
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetAppendMode(FPLogStateRef ioLogState, FPBool inAppendMode);
 
  /**
    Updates the "LogLevel" field of the FPLogState object.
    This field controls the log level used when the logger writes output.
 
    The default value of this field may be initialized by setting the
    "FP_LOGLEVEL" environment variable.
 
    @param ioLogState    A reference to an FPLogState object.
    @param inLogLevel    The level at which to log. May be any of the following:
 
                     <dl>
                     <dt>     FP_LOGLEVEL_ERROR  <dd> - Log error messages </dd></dt>
                     <dt>     FP_LOGLEVEL_WARN   <dd> - Log warnings and error messages. </dd></dt>
                     <dt>     FP_LOGLEVEL_LOG    <dd> - Log API calls, warnings, and errors. </dd></dt>
                     <dt>     FP_LOGLEVEL_DEBUG  <dd> - Debug log level. </dd></dt>
                     </dl>
 
     @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogLevel(FPLogStateRef ioLogState, FPLogLevel inLogLevel);
 
  /**
    Updates the "LogFilter" field of the FPLogState object.
    This field defines which components should be logged by the logging mechanism.
 
    The default value of this field may be initialized by setting the
    "FP_LOGFILTER" environment variable.
 
    @param ioLogState        A reference to an FPLogState object.
    @param inLogComponents   A bitmask defining the active components
 
                      <dl>
                      <dt>   Use the FP_LOGGING_COMPONENT_ALL mask to enable full logging. </dt>
                      <dt>   Use the FP_LOGGING_COMPONENT_API mask to log only API level calls. </dt>
                      </dl>
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogFilter(FPLogStateRef ioLogState, FPInt inLogComponents);
 
  /**
    Updates the "LogFormat" field of the FPLogState object.
    This field determines which formatter will be used by the logging mechanism.
 
    The default value of this field may be initialized by setting the
    "FP_LOGFORMAT" environment variable.
 
    @param ioLogState        A reference to an FPLogState object.
    @param inLogFormat       FP_LOGGING_LOGFORMAT_XML || FP_LOGGING_LOGFORMAT_TAB (default)
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetLogFormat(FPLogStateRef ioLogState, FPLogFormat inLogFormat);
 
  /**
    Updates the "MaxLogSize" field of the FPLogState object.
    This field determines the maximum size that the log file may grow (in KB) before "rolling over"
    to an overflow file. Defaults to 1048576 (1 GB).
 
    Specify "FP_LOG_SIZE_UNBOUNDED" to allow the log file to grow without bounds.
 
    The default value of this field may be initialized by setting the
    "FP_LOG_MAX_SIZE" environment variable.
 
    @param ioLogState         A reference to an FPLogState object.
    @param inSizeInKilobytes  The maximium size in KB that a log file may grow.
                              Specify FP_LOG_SIZE_UNBOUNDED for no limit.
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetMaxLogSize (FPLogStateRef ioLogState, FPLong inSizeInKilobytes);
 
  /**
    Updates the "MaxOverflows" field of the FPLogState object.
    This field determines the maximum number of backup log files generated (with a .# extention)
    if the log file size exceeds the MaxLogSize value. The default value is 1.
 
    The default value of this field may be initialized by setting the
    "FP_LOG_MAX_OVERFLOWS" environment variable.
 
    @param ioLogState         A reference to an FPLogState object.
    @param inCount            The maximum number of rollover files to be generated.
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetMaxOverflows (FPLogStateRef ioLogState, FPInt inCount);
 
  /**
    Updates the "disable callback" field of the FPLogState object.
    This field disables (or allows) the use of any application callback registered with the
    FPLogging_RegisterCallback API method.
 
    The default value of this field may be initialized by setting the
    "FP_LOG_DISABLE_CALLBACK" environment variable.
 
    @param ioLogState         A reference to an FPLogState object.
    @param inDisableCallback  Use "true" to disable any registered callback and "false" (default) to allow.
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetDisableCallback(FPLogStateRef ioLogState, FPBool inDisableCallback);
 
  /**
    Updates the "log state polling interval" field of the FPLogState object.
    This field defines the number of minutes between FPLogState config file poll events if
    a log state config file was opened. If a state file exists, it will be re-read and
    the log configuration will be modified accordingly at each interval.
 
    The log state configuration file is only polled if a log state file has been specified
    by either env var ("FP_LOG_STATE_PATH") or API call (FPLogging_OpenLogState()).
 
    The default value of this field may be initialized by setting the
    "FP_LOG_STATE_POLL_INTERVAL" environment variable.
 
    To disable all log state file polling, specify FP_LOG_NO_POLLING (-1) for the inPollIntervalInMin.
    To poll the log state file before every log event, specify an inPollIntervalInMin of "0".
 
    @param ioLogState           A reference to an FPLogState object.
    @param inPollIntervalInMin  The number of minutes between config file reads (default is 5, must be >= -1).
 
    @since 3.2
   */
  EXPORT void DECL FPLogState_SetPollInterval(FPLogStateRef ioLogState, FPInt inPollIntervalInMin);
 
  /**
     Gets the current value of the log state object's log path field
     @see FPLogState_SetLogPath()
     @since 3.2
   */
  EXPORT const char* DECL FPLogState_GetLogPath(FPLogStateRef inLogState);
 
  /**
     Gets the current value of the log state object's append mode field
     @see FPLogState_SetAppendMode()
     @since 3.2
   */
  EXPORT FPBool DECL FPLogState_GetAppendMode(FPLogStateRef inLogState);
 
  /**
     Gets the current value of the log state object's log level field
     @see FPLogState_SetLogLevel()
     @since 3.2
   */
  EXPORT FPLogLevel DECL FPLogState_GetLogLevel(FPLogStateRef inLogState);
 
  /**
     Gets the current value of the log state object's filter field
     @see FPLogState_SetLogFilter()
     @since 3.2
   */
  EXPORT FPInt DECL FPLogState_GetLogFilter(FPLogStateRef inLogState);
 
  /**
     Gets the current value of the log state object's formatter field
     @see FPLogState_SetLogFormat()
     @since 3.2
   */
  EXPORT FPLogFormat DECL FPLogState_GetLogFormat(FPLogStateRef inLogState);
 
  /**
     Gets the current value of the log state object's max log size field
     @see FPLogState_SetMaxLogSize()
     @since 3.2
   */
  EXPORT FPLong DECL FPLogState_GetMaxLogSize(FPLogStateRef inLogState);
 
  /**
     Gets the current value of the log state object's max overflows field
     @see FPLogState_SetMaxOverflows()
     @since 3.2
   */
  EXPORT FPInt DECL FPLogState_GetMaxOverflows(FPLogStateRef inLogState);
 
  /**
     Gets the current value of the log state object's disable callback field
     @see FPLogState_SetDisableCallback()
     @since 3.2
   */
  EXPORT FPBool DECL FPLogState_GetDisableCallback(FPLogStateRef ioLogState);
 
  /**
     Gets the current value of the log state object's poll interval field
     @see FPLogState_SetPollInterval()
     @since 3.2
   */
  EXPORT FPInt DECL FPLogState_GetPollInterval(FPLogStateRef ioLogState);
 
  /**
    Serializes (saves) an FPLogState object to an FPLogState properties file.
 
    @param inLogState           A reference to an FPLogState object.
    @param inPathName           Full path of the file to be created.
    @since 3.2
   */
  EXPORT void DECL FPLogState_Save(FPLogStateRef inLogState, char *inPathName);
 
  /**
     uses UTF-8 encoding
     @see FPLogState_Save()
     @since 3.2
   */
  EXPORT void DECL FPLogState_Save8(FPLogStateRef inLogState, char *inPathName);
 
  /**
     uses UTF-16 encoding
     @see FPLogState_Save()
     @since 3.2
   */
  EXPORT void DECL FPLogState_Save16(FPLogStateRef inLogState, FPChar16 *inPathName);
 
  /**
     uses UTF-32 encoding
     @see FPLogState_Save()
     @since 3.2
   */
  EXPORT void DECL FPLogState_Save32(FPLogStateRef inLogState, FPChar32 *inPathName);
 
  /**
     uses wide characters
     @see FPLogState_Save()
     @since 3.2
   */
  EXPORT void DECL FPLogState_SaveW(FPLogStateRef inLogState, wchar_t *inPathName);
 
 
#ifdef __cplusplus
}
#endif
 
/** @} */ /* logging functions */
 
#endif /* __FPAPI_LOG__ */

