/******************************************************************************\
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * All Rights Reserved
 *
 * PAI_version.h
 *
 * PAI module Header File Build Version 3.3.100
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
\******************************************************************************/
/******************************************************************************\
 *
 * The reference implementation of a Pool Access Information (PAI) module 
 *
 * This file defines version information for the PAI module
 *
 * EDIT THIS FILE when implementing a PAI module!!!
 * 
\******************************************************************************/
#ifndef __PAI_VERSION_H_
#define __PAI_VERSION_H_

const char *versionString = "3.3.100";

#endif // __PAI_VERSION_H_
