/*****************************************************************************
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * Unpublished - All Rights Reserved
 *
 * FPGenericStream.h
 *
 * FPLibrary Header File Build Version 3.3.718
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile
 * and the intellectual property contained therein is expressly limited to the
 * terms and conditions of the License Agreement.
 *
 * EMC2  , EMC, Symmetrix, Celerra, CLARiiON, CLARalert, DG, E-Infostructure, 
 * HighRoad, Navisphere, PowerPath, ResourcePak, SnapView/IP, SRDF, VisualSAN, 
 * where information lives, and The EMC Effect are registered trademarks and EMC 
 * Automated Networked Storage, EMC ControlCenter, EMC Developers Program, EMC 
 * Enterprise Storage, EMC Enterprise Storage Network, EMC OnCourse, EMC Proven, 
 * EMC Snap, Access Logix, AutoAdvice, Automated Resource Manager, AutoSwap, 
 * AVALONidm, C-Clip, CacheStorm, Celerra Replicator, Centera, CentraStar, 
 * CLARevent, Connectrix, CopyCross, CopyPoint, CrosStor, Direct Matrix, Direct 
 * Matrix Architecture, EDM, E-Lab, Enginuity, FarPoint, FLARE, GeoSpan, InfoMover, 
 * MirrorView, NetWin, OnAlert, OpenScale, Powerlink, PowerVolume, RepliCare, 
 * SafeLine, SAN Architect, SAN Copy, SAN Manager, SDMS, SnapSure, SnapView, 
 * StorageScope, SupportMate, SymmAPI, SymmEnabler, Symmetrix DMX, TimeFinder, 
 * Universal Data Tone, and VisualSRM are trademarks of EMC Corporation. All other 
 * trademarks used herein are the property of their respective owners.
 *
 * ---------------------------------------------------------------------------
 * Copyright � 1991-2, RSA Data Security, Inc. Created 1991.
 * All rights reserved.
 * License to copy and use this software is granted provided
 * that it is identified as the "RSA Data Security, Inc. MD5
 * Message-Digest Algorithm" in all material mentioning or
 * referencing this software or this function.
 * RSA Data Security, Inc. makes no representations concerning
 * either the merchantability of this software or the
 * suitability of this software for any particular purpose. It
 * is provided "as is" without express or implied warranty of any kind.
 *
 * These notices must be retained in any
 * copies of any part of this documentation and/or software.
 *
 * ---------------------------------------------------------------------------
 * Copyright and Licensing Information for ACE(TM)
 * http://www.cs.wustl.edu/~schmidt/ACE-copying.html
 *
 *****************************************************************************/

#ifndef __FPGENERICSTREAM__
#define __FPGENERICSTREAM__

#include <FPTypes.h>

/**
  @file FPGenericStream.h
   FPLibrary Generic Streams header file.
   This file contains methods to create and work with generic streams.  These are the
   foundations for the higher level stream functions.
*/

/**
   @addtogroup Stream Streaming functions
   @{
*/   
/**
  FP_STREAMINFO_VERSION denotes the current version of the FPStreamInfo structure.
  Changes to FPStreamInfo:
   - 1: initial release
   - 2: no changes to the structure.  Now output stream can also specify buffer in FPStream_PrepareBuffer.
   - 3: mTransferlen of -1 is allowed to indicate that a keep-alive packet has to be sent to the server
 */
#define FP_STREAMINFO_VERSION       3

#ifdef _WIN32
# if defined(_MSC_VER) || defined(__MWERKS__) || defined(__GNUC__) || (__BORLANDC >= 0x0500)
#  pragma pack (8)
# endif
# if defined(__BORLANDC__) && (__BORLANDC__ <= 0x0500)
#  pragma option -a8
# endif
#endif

/**
  This structure passes information about the stream between functions.  The application can
  access this function via a pointer.  The application is allowed to modify only the field members
  as described in the API Reference Guide.
 */
typedef struct {

  short          mVersion ;         /**< current version of FPStreamInfo                                */
  void          *mUserData ;        /**< to application-specific data, untouched by Generic Streams     */

  FPLong         mStreamPos ;       /**< current position                                               */
  FPLong         mMarkerPos ;       /**< position of marker                                             */
  FPLong         mStreamLen ;       /**< length of stream, if known, else -1                            */
  FPBool         mAtEOF ;           /**< have we reached the end of the stream?                         */
  FPBool         mReadFlag ;        /**< read/write indicator, true on export, false on import          */
  void          *mBuffer ;          /**< databuffer supplied by application                             */
  FPLong         mTransferLen ;     /**< number of bytes actually transferred                           */

} FPStreamInfo ;

#ifdef _WIN32
# if defined(_MSC_VER) || defined(__MWERKS__) || defined(__GNUC__) || (__BORLANDC >= 0x0500)
#  pragma pack ()
# endif
# if defined(__BORLANDC__) && (__BORLANDC__ < 0x0500)
#  pragma option -a-
# endif
#endif

typedef long (*FPStreamProc) (FPStreamInfo*) ;

typedef FPLong FPStreamRef;


#ifdef __cplusplus
 extern "C" {
#endif

/*-----------------------------------------------------------------------*/
/** @name Generic Stream Functions
   @{
*/

/**
    This function allocates a stream data structure, declares its methods
    and returns a reference to the created stream. If the stream has not
    been created, the function returns NULL.

    @param pPrepareBufferProc
                This method prepares a buffer that the stream can use. If the stream is
                an input buffer, the callback method prepares a buffer that contains
                the data. The mBuffer field of FPStreamInfo contains a pointer to the
                data. If the stream is an output buffer, the function typically does
                nothing.
    @param pCompleteProc
                The generic stream calls this method when the buffer that has been
                prepared with pPrepareBufferProc is no longer needed. If the
                stream was an input stream, it means that the data has been
                processed successfully. If the stream was an output stream, it means
                that the buffer contains the requested data and can be written to an
                output device.
    @param pSetMarkerProc
                This method tells the generic stream to mark the current position in
                the stream. If the stream supports marking, the function can use the
                mMarkerPos field to indicate the current position.
    @param pResetMarkerProc
                This method tells the stream to go back to the marked position in the
                stream (mMarkerPos). If mMarkerPos is zero, the method may perform a
                different operation than going to a marked position in the stream.
    @param pCloseProc
                This method informs that the application has performed its operations on
                the stream and that the stream can clean up the resources that it has
                allocated.
    @param pUserData
                Any data that the application wants to pass to the method pointers.

    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateGenericStream (
                        const FPStreamProc pPrepareBufferProc,
                        const FPStreamProc pCompleteProc,
                        const FPStreamProc pSetMarkerProc,
                        const FPStreamProc pResetMarkerProc,
                        const FPStreamProc pCloseProc,
                        const void        *pUserData) ;
/**
    The function closes the given stream. Be aware that using this
    function on a stream that has already been closed, may produce
    unwanted results.

    @param  pStream
                The reference to a stream (as returned from the functions
                FPStream_CreateXXX or FPStream_CreateGenericStream() ). The
                reference may also be NULL.

    @since 1.1
*/

EXPORT void          DECL FPStream_Close (const FPStreamRef pStream) ;

/**
    This function returns information about the given stream.

    @param  pStream     The reference to a stream.

    @since 1.1
*/

EXPORT FPStreamInfo* DECL FPStream_GetInfo (const FPStreamRef pStream) ;

/**
    This function calls the prepareBufferProc, which was previously passed
    to FPStream_CreateGenericStream().  The mBuffer field in
    FPStreamInfo is Set to NULL for output streams.  Change it if you
    want to supply your own buffer to receive data.

    @return             a pointer to the stream info or NULL on error
    @param pStream      The reference to a stream.

    @since 1.2
*/

EXPORT FPStreamInfo* DECL FPStream_PrepareBuffer (const FPStreamRef pStream) ;

/**
    This function calls the completeProc from the stream. The completeProc
    was previously passed to FPStream_CreateGenericStream().  If no completeProc
    callback is defined for this stream, then the function does nothing.

    @return             a pointer to the stream info or NULL on error
    @param pStream      The reference to a stream.

    @since 1.2
*/
EXPORT FPStreamInfo* DECL FPStream_Complete (const FPStreamRef pStream) ;

/**
    This function calls the SetMarkerProc from the stream.  This function
    was previously passed to FPStream_CreateGenericStream().
    If no SetMarkerProc callback was specified, then this function returns
    the error FP_OPERATION_REQUIRES_MARK.  This should usually be ignored
    by the application.

    @param pStream      The reference to a stream.

    @since 1.2
*/

EXPORT void          DECL FPStream_SetMark (const FPStreamRef pStream) ;

/**
    This function calls the resetMarkerProc from the stream.  This function
    was previously passed to FPStream_CreateGenericStream().
    If no resetMarkerProc callback was specified, then this function returns
    the error FP_OPERATION_REQUIRES_MARK unless the current position in the stream
    equals the marked position (mMarkerPos matches mStreamPos fields).

    @param pStream      The reference to a stream.

    @since 1.2
*/

EXPORT void          DECL FPStream_ResetMark (const FPStreamRef pStream) ;

/*-----------------------------------------------------------------------*/

#ifdef __cplusplus
 }
#endif

/** @} */ /* Generic Stream Functions member */
/** @} */ /* Stream Functions module */

#endif /* __FPGENERICSTREAM__ */
