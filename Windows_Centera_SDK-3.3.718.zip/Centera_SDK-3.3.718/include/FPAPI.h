#ifndef __FPAPI__
#define __FPAPI__
/*****************************************************************************
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * Unpublished - All Rights Reserved
 *
 * FPAPI.h
 *
 * FPLibrary Header File Build Version 3.3.718
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile 
 * and the intellectual property contained therein is expressly limited to the 
 * terms and conditions of the License Agreement.
 *
 * EMC2  , EMC, Symmetrix, Celerra, CLARiiON, CLARalert, DG, E-Infostructure, 
 * HighRoad, Navisphere, PowerPath, ResourcePak, SnapView/IP, SRDF, VisualSAN, 
 * where information lives, and The EMC Effect are registered trademarks and EMC 
 * Automated Networked Storage, EMC ControlCenter, EMC Developers Program, EMC 
 * Enterprise Storage, EMC Enterprise Storage Network, EMC OnCourse, EMC Proven, 
 * EMC Snap, Access Logix, AutoAdvice, Automated Resource Manager, AutoSwap, 
 * AVALONidm, C-Clip, CacheStorm, Celerra Replicator, Centera, CentraStar, 
 * CLARevent, Connectrix, CopyCross, CopyPoint, CrosStor, Direct Matrix, Direct 
 * Matrix Architecture, EDM, E-Lab, Enginuity, FarPoint, FLARE, GeoSpan, InfoMover, 
 * MirrorView, NetWin, OnAlert, OpenScale, Powerlink, PowerVolume, RepliCare, 
 * SafeLine, SAN Architect, SAN Copy, SAN Manager, SDMS, SnapSure, SnapView, 
 * StorageScope, SupportMate, SymmAPI, SymmEnabler, Symmetrix DMX, TimeFinder, 
 * Universal Data Tone, and VisualSRM are trademarks of EMC Corporation. All other 
 * trademarks used herein are the property of their respective owners.
 *
 * ---------------------------------------------------------------------------
 * Copyright @ 1991-2, RSA Data Security, Inc. Created 1991. 
 * All rights reserved. 
 * License to copy and use this software is granted provided 
 * that it is identified as the "RSA Data Security, Inc. MD5 
 * Message-Digest Algorithm" in all material mentioning or 
 * referencing this software or this function. 
 * RSA Data Security, Inc. makes no representations concerning 
 * either the merchantability of this software or the 
 * suitability of this software for any particular purpose. It 
 * is provided "as is" without express or implied warranty of any kind. 
 *
 * These notices must be retained in any 
 * copies of any part of this documentation and/or software.
 *
 * ---------------------------------------------------------------------------
 * Copyright and Licensing Information for ACE(TM)
 * http://www.cs.wustl.edu/~schmidt/ACE-copying.html
 *
 *****************************************************************************/
/**
  @file FPAPI.h
   FPLibrary header file.
   This file contains all the definitions necessary to use the core FPLibrary functionality.
*/

#include <FPTypes.h>
#include <FPStream.h>
#include <FPLog.h>
#if !defined(__SASC__)
#include <wchar.h>
#endif

/** @defgroup Defines Global Definitions
    @{ */

/** @name FPLibary Options
    Options for FPPool_SetIntOption(), FPPool_SetGlobalOption(),..
    @{  */
#define FP_OPTION_BUFFERSIZE_W                      L"buffersize"            /**< size of internal memory buffers              */
#define FP_OPTION_TIMEOUT_W                         L"timeout"               /**< tcp/ip connection timeout in milliseconds    */
#define FP_OPTION_RETRYCOUNT_W                      L"retrycount"            /**< retry transaction if connection failed       */
#define FP_OPTION_RETRYSLEEP_W                      L"retrysleep"            /**< sleep time in millisecs if retry fails       */
#define FP_OPTION_MAXCONNECTIONS_W                  L"maxconnections"        /**< max. number of simultaneous connections      */
#define FP_OPTION_ENABLE_MULTICLUSTER_FAILOVER_W    L"multiclusterfailover"  /**< enable multicluster failover (default=true)  */
#define FP_OPTION_DEFAULT_COLLISION_AVOIDANCE_W     L"collisionavoidance"    /**< Set collision avoidance on by default        */
#define FP_OPTION_PREFETCH_SIZE_W                   L"prefetchsize"          /**< Prefetch buffersize (in bytes)               */
#define FP_OPTION_CLUSTER_NON_AVAIL_TIME_W          L"clusternonavailtime"   /**< Time cluster is marked 'unavailable' (in secs) */
#define FP_OPTION_PROBE_LIMIT_W                     L"probetimelimit"		 /**< Time to wait for probe, min 3 sec, max 1 hour */
#define FP_OPTION_EMBEDDED_DATA_THRESHOLD_W         L"embedding_threshold"   /**< Size in bytes. Any data < this value is be embedded in the clip.*/
#define FP_OPTION_OPENSTRATEGY_W                    L"openstrategy"          /**< How to open the pools? Fast pool open or not?                   */

#define FP_OPTION_MULTICLUSTER_READ_STRATEGY_W      L"multicluster_read_strategy"   /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_WRITE_STRATEGY_W     L"multicluster_write_strategy"  /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_DELETE_STRATEGY_W    L"multicluster_delete_strategy" /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_EXISTS_STRATEGY_W    L"multicluster_exists_strategy" /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_QUERY_STRATEGY_W     L"multicluster_query_strategy"  /**< How to interact with multi clusters? Primary only, failover or replication?   */

#define FP_OPTION_MULTICLUSTER_READ_CLUSTERS_W      L"multicluster_read_clusters"   /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_WRITE_CLUSTERS_W     L"multicluster_write_clusters"  /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_DELETE_CLUSTERS_W    L"multicluster_delete_clusters" /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_EXISTS_CLUSTERS_W    L"multicluster_exists_clusters" /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_QUERY_CLUSTERS_W     L"multicluster_query_clusters"  /**< Sets clusters used by multi cluster strategy   */

#define FP_OPTION_BUFFERSIZE                        "buffersize"            /**< size of internal memory buffers              */
#define FP_OPTION_TIMEOUT                           "timeout"               /**< tcp/ip connection timeout                    */
#define FP_OPTION_RETRYCOUNT                        "retrycount"            /**< retry transaction if connection failed       */
#define FP_OPTION_RETRYSLEEP                        "retrysleep"            /**< sleep time in millisecs if retry fails       */
#define FP_OPTION_MAXCONNECTIONS                    "maxconnections"        /**< max. number of simultaneous connections      */
#define FP_OPTION_ENABLE_MULTICLUSTER_FAILOVER      "multiclusterfailover"  /**< enable multicluster failover (default=true)  */
#define FP_OPTION_DEFAULT_COLLISION_AVOIDANCE       "collisionavoidance"    /**< Set collision avoidance on by default        */
#define FP_OPTION_PREFETCH_SIZE                     "prefetchsize"          /**< Prefetch buffersize (in bytes)               */
#define FP_OPTION_CLUSTER_NON_AVAIL_TIME            "clusternonavailtime"   /**< Time cluster is marked 'unavailable' (in secs) */
#define FP_OPTION_PROBE_LIMIT                       "probetimelimit"		/**< Time to wait for probe, min 3 sec, max 1 hour */
#define FP_OPTION_EMBEDDED_DATA_THRESHOLD           "embedding_threshold"   /**< Determine clusterlayout to use in FPPool_Open */
#define FP_OPTION_OPENSTRATEGY                      "openstrategy"          /**< How to open the pools? Probe all upfront or just when needed? */

#define FP_OPTION_MULTICLUSTER_READ_STRATEGY        "multicluster_read_strategy"   /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_WRITE_STRATEGY       "multicluster_write_strategy"  /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_DELETE_STRATEGY      "multicluster_delete_strategy" /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_EXISTS_STRATEGY      "multicluster_exists_strategy" /**< How to interact with multi clusters? Primary only, failover or replication?   */
#define FP_OPTION_MULTICLUSTER_QUERY_STRATEGY       "multicluster_query_strategy"  /**< How to interact with multi clusters? Primary only, failover or replication?   */

#define FP_OPTION_MULTICLUSTER_READ_CLUSTERS        "multicluster_read_clusters"   /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_WRITE_CLUSTERS       "multicluster_write_clusters"  /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_DELETE_CLUSTERS      "multicluster_delete_clusters" /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_EXISTS_CLUSTERS      "multicluster_exists_clusters" /**< Sets clusters used by multi cluster strategy   */
#define FP_OPTION_MULTICLUSTER_QUERY_CLUSTERS       "multicluster_query_clusters"  /**< Sets clusters used by multi cluster strategy   */

/** @} */                                                                                                                      
                                                                         
/** @name FP_OPTION_MULTICLUSTER...STRATEGY Options                                                                                                    
    @{  */
#define FP_NO_STRATEGY          0
#define FP_FAILOVER_STRATEGY    1
#define FP_REPLICATION_STRATEGY 2
/** @} */  
                                                 
/** @name FP_OPTION_MULTICLUSTER...CLUSTERS Options                                                                                                    
    @{  */
#define FP_PRIMARY_ONLY                             0
#define FP_PRIMARY_AND_PRIMARY_REPLICA_CLUSTER_ONLY 1
#define FP_NO_REPLICA_CLUSTERS                      2
#define FP_ALL_CLUSTERS                             3
/** @} */    
                                                                         
/** @name FP_OPTION_OPENSTRATEGY Options                                                                                                    
    @{  */
#define FP_NORMAL_OPEN                              0                       /**< Pool probes all access nodes at connect time */
#define FP_LAZY_OPEN                                1                       /**< Pool stops probing access nodes when it finds an active primary cluster */
/** @} */    
                                                      
/** @name FP_OPTION_EMBEDDED_DATA_MAX_SIZE value                                                                                                 
    @{  */
#define FP_OPTION_EMBEDDED_DATA_MAX_SIZE            102400                  /**< Maximum allowed value for embedded data threshold size, in bytes (100 KB) */
/** @} */
                                                            
/** @name FPClip Open Options                                                                                                  
    FPClip_Open() option parameter                                                                                               
    @{  */
#define FP_OPEN_ASTREE                              1                       /**< C-Clip is opened read/write                  */
#define FP_OPEN_FLAT                                2                       /**< C-Clip is opened read-only                   */
/** @} */                                                                                                                      
                                                                                                                              
/** @name BlobWrite Options                                                                                                      
    Options for FPTag_BlobWrite(), FPTag_BlobRead()                                                                              
    @{ */                                                                                                                      
#if __SASC__ != 650                                                                                                                               
#define FP_OPTION_DEFAULT_OPTIONS                   0                       /**< select default options for that parameter                */
                                                                                                                              
#define FP_OPTION_CALCID_MASK                       0x0000000F                                                                
#define FP_OPTION_CLIENT_CALCID                     0x00000001              /**< calculate the digest upfront                             */
#define FP_OPTION_CLIENT_CALCID_STREAMING           0x00000002              /**< calculate the digest by the client while streaming       */
#define FP_OPTION_SERVER_CALCID_STREAMING           0x00000003              /**< calculate the digest by the server                       */
                                                                                                                                            
#define FP_OPTION_CALCID_NOCHECK                    0x00000010              /**< don't check md5 along the way (deprecated)               */
                                                                                                                                           
#define FP_OPTION_ENABLE_DUPLICATE_DETECTION        0x00000020              /**< enable detection of duplicate content addresses          */
#define FP_OPTION_ENABLE_COLLISION_AVOIDANCE        0x00000040              /**< enable collision avoidance (override FPPool - Setting)   */
#define FP_OPTION_DISABLE_COLLISION_AVOIDANCE       0x00000080  

#define FP_OPTION_EMBED_DATA                        0x00000100
#define FP_OPTION_LINK_DATA                         0x00000200

/**< disable collision avoidance (override FPPool - Setting)  */
/** @}  */                                                                                                                                  
                                                                                                                                                
#else
/* Mainframe SAS/C COMPILER Version 6.50 DOES NOT SUPPORT 64 bit integers so use a double word
   structure instead */
const FPLong NULL_LONGLONG={0,0};
const FPLong FP_OPTION_DEFAULT_OPTIONS={0,0};
const FPLong FP_OPTION_MASK={0,0x0000000F};
const FPLong FP_OPTION_CLIENT_CALCID={0,0x00000001};
const FPLong FP_OPTION_CLIENT_CALCID_STREAMING={0,0x00000002};
const FPLong FP_OPTION_SERVER_CALCID_STREAMING={0,0x00000003};
const FPLong FP_OPTION_CALCID_NOCHECK={0,0x00000010};
const FPLong FP_OPTION_ENABLE_DUPLICATE_DETECTION={0,0x00000020};
const FPLong FP_OPTION_ENABLE_COLLISION_AVOIDANCE={0,0x00000040};
const FPLong FP_OPTION_DISABLE_COLLISION_AVOIDANCE={0,0x00000080};
const FPLong FP_OPTION_EMBED_DATA={0,0x00000100};
const FPLong FP_OPTION_LINK_DATA={0,0x000000200};
#endif

/** @name Copy Options
    Options for FPTag_Copy()
    @{ */
                                                                                                                                            
#define FP_OPTION_NO_COPY_OPTIONS                   0x00                    /**< just copy the tag with its attributes                     */
#define FP_OPTION_COPY_BLOBDATA                     0x01                    /**< copy the blobdata (if any) with the tag                   */
#define FP_OPTION_COPY_CHILDREN                     0x02                    /**< copy children of tag too                                  */
/** @} */                                                                                                                                  

/** @time Time options
    Options for FPTime_MillisecondstoString(),
    FPTime_SecondsToString()
    @{ */
#define FP_OPTION_SECONDS_STRING                    0x00
#define FP_OPTION_MILLISECONDS_STRING               0x01
/** @} */

/** @name FPClip Audited Delete Options                                                                                                  
    FPClip_AuditedDelete() option parameter                                                                                               
    @{  */
#define FP_OPTION_DELETE_PRIVILEGED                 1                       /**< C-Clip is deleted in privileged mode                       */
/** @} */                                                                                                                                  
                                                                                                                                          
#define FPPOOL_INFO_VERSION                         2                       /**< versioning of the FPPoolInfo structure                     */
                                                                                                                                          
/** @name Query Results                                                                                                                      
    Result values for FPQuery_FetchResult()                                                                                                  
    @{ */                                                                                                                                  
    
#define FP_QUERY_RESULT_CODE_OK                     0                       /**< query returns valid C-ClipID                                 */
#define FP_QUERY_RESULT_CODE_INCOMPLETE             1                       /**< storage server went down during query, possibly incomplete   */
#define FP_QUERY_RESULT_CODE_COMPLETE               2                       /**< query operation completed                                    */
#define FP_QUERY_RESULT_CODE_END                    3                       /**< query operation finished                                     */
#define FP_QUERY_RESULT_CODE_ABORT                  4                       /**< query operation aborted                                      */
                                                                                                                                            
#define FP_QUERY_RESULT_CODE_ERROR                  -1                      /**< error in Getting query result                                */
#define FP_QUERY_RESULT_CODE_PROGRESS               99                      /**< query operation in progress                                  */

#define FP_QUERY_TYPE_EXISTING                      0x1                     /**< return only existing C-Clips in the query result             */
#define FP_QUERY_TYPE_DELETED                       0x2                     /**< return only deleted C-Clips in the query result              */

#define FP_QUERY_START_TIME_UNBOUNDED               0                       /**< earliest start time for the query (beginning of time)        */
#define FP_QUERY_END_TIME_UNBOUNDED                 -1                      /**< latest end time for the query (present time)                 */

/** @} */                                                                                                                                    
                                                                                                                                            
/** @name RetentionPeriods                                                                                                                    
    Special Retention Period Values for FPClip_SetRetentionPeriod()                                                                              
    @{ */                                                                                                                                      
#if __SASC__ != 650
#define FP_NO_RETENTION_PERIOD                       0                      /**< The clip can be deleted at any time                           */
#define FP_INFINITE_RETENTION_PERIOD                -1                      /**< The clip can never be deleted                                 */
#define FP_DEFAULT_RETENTION_PERIOD                 -2                      /**< Clip deletion depends on cluster default Setting              */
#else
const FPLong FP_NO_RETENTION_PERIOD = {0,0};                                /**< The clip can be deleted at any time                            */
const FPLong FP_INFINITE_RETENTION_PERIOD = {0xFFFFFFFF,0xFFFFFFFF};        /**< The clip can never be deleted                                  */
const FPLong FP_DEFAULT_RETENTION_PERIOD = {0xFFFFFFFF,0xFFFFFFFE};         /**< Clip deletion depends on cluster default setting               */
#endif
/** @} */                                                                                                                                      
                                                                                  
/** @name Streams
    Special named constants for stream creation                                                                                                    
    @{  */
#define FP_STREAM_EOF                               -1                      /**< Used to specify an unknown stream length                      */ 

#define FP_OPTION_STREAM_STRICT_MODE      "FP_OPTION_STREAM_STRICT_MODE"    /**< The global option which may be used to configure strict stream validation */

/** @} */   
                                                                                                                     
/** @name Component Selectors                                                                                                                  
    Version Component Selectors for FPPool_GetComponentVersion()                                                                              
    @{ */                                                                                                                                      
#define FP_VERSION_FPLIBRARY_DLL                     1                      /**< Get the version of the FPLibrary.dll                          */
#define FP_VERSION_FPLIBRARY_JAR                     2                      /**< Get the version of the FPLibrary.jar - java only              */
/** @} */

/** @name Error Classes
    The error class as returned by FPPool_GetLastErrorInfo() in the FPErrorInfo structure
    @{ */
#define FP_NETWORK_ERRORCLASS                        1                      /**< The cause of the error is probably network related                                        */
#define FP_SERVER_ERRORCLASS                         2                      /**< The cause of the error is probably Centera server related                                */
#define FP_CLIENT_ERRORCLASS                         3                      /**< Logical runtime errors that indicate a coding error or wrong usage in the application  */
/** @} */
    
/** @name Capability Constants 
    Constants for FPPool_GetCapability() for tagnames, attributenames and attributevalues 
    @{*/

#define FP_TRUE_W                       L"true"                 /**< constant for 'true'                                                            */
#define FP_FALSE_W                      L"false"                /**< constant for 'false'                                                           */
                                                                                                                                                   
#define FP_READ_W                       L"read"                 /**< is the read-operation allowed? used by FPClip_Open(), FPTag_BlobRead()         */
#define FP_WRITE_W                      L"write"                /**< is the write-operation allowed? used by FPClip_Write(), FPTag_BlobWrite()      */
#define FP_DELETE_W                     L"delete"               /**< is the delete-operation allowed? used by FPClip_Delete()                       */
#define FP_PURGE_W                      L"purge"                /**< is the purge-operation allowed? used by FPClip_Purge(), FPTag_BlobPurge()      */
#define FP_EXIST_W                      L"exist"                /**< is the exists-operation allowed? used by FPClip_Exists()                       */
#define FP_CLIPENUMERATION_W            L"clip-enumeration"     /**< is the query-operation allowed? used by FPQuery_Open()                         */
#define FP_RETENTION_W                  L"retention"            /**< the retention period for the (Full) Compliance Centera server                  */
#define FP_BLOBNAMING_W                 L"blobnaming"           /**< which blobnaming methods are allowed by the server?                            */
#define FP_MONITOR_W                    L"monitor"              /**< are the monitor-operations present on the server? Used by FPMonitor__XX ()     */
#define FP_DELETIONLOGGING_W            L"deletionlogging"      /**< are deletions logged on the server?                                            */
#define FP_PRIVILEGEDDELETE_W           L"privileged-delete"    /**< are privileged deletes allowed?                                                */
#define FP_POOL_POOLMAPPINGS_W          L"poolmappings"         /**< what are all the pool mappings for all the profiles or pools?                  */
#define FP_COMPLIANCE_W                 L"compliance" 
                                                                                                                                                   
#define FP_ALLOWED_W                    L"allowed"              /**< attributeName indicates that operation is allowed                              */
#define FP_SUPPORTED_W                  L"supported"            /**< attributeName indicates that operation is supported                            */
#define FP_UNSUPPORTED_W                L"unsupported"          /**< attributeName indicates that operation is unsupported                          */
#define FP_DUPLICATEDETECTION_W         L"duplicate-detection"  /**< @deprecated                                                                    */
#define FP_DEFAULT_W                    L"default"              /**< attributeName to indicate default value                                        */
#define FP_SUPPORTED_SCHEMES_W          L"supported-schemes"    /**< attributeName to indicate supported blobnaming schemes                         */
#define FP_MD5_W                        L"MD5"                  /**< MD5 blobnaming scheme                                                          */
#define FP_MG_W                         L"MG"                   /**< MD5-GUID blobnaming scheme                                                     */
#define FP_POOLS_W                      L"pools"                /**< List all pools that relate to the particular tag capability                    */
#define FP_PROFILES_W                   L"profiles"             /**< List the profiles that have a pool mapping installed                           */
#define FP_MODE_W                       L"mode"
#define FP_EVENT_BASED_RETENTION_W      L"ebr"                  /**< event based retention capability                                               */
#define FP_RETENTION_HOLD_W             L"retention-hold"       /**< litigation hold capability                                                     */
#define FP_FIXED_RETENTION_MIN_W        L"fixedminimum"         /**< retention fixed minimum time allowed                                           */
#define FP_FIXED_RETENTION_MAX_W        L"fixedmaximum"         /**< retention fixed maximum time allowed                                           */
#define FP_VARIABLE_RETENTION_MIN_W     L"variableminimum"      /**< retention variable minimum time allowed                                        */
#define FP_VARIABLE_RETENTION_MAX_W     L"variablemaximum"      /**< retention variable maximum time allowed                                        */
#define FP_RETENTION_DEFAULT_W          L"default"              /**< retention default time allowed                                                 */
#define FP_RETENTION_MIN_MAX_W          L"min-max"              /**< constant for min-max                                                           */
#define FP_VALUE_W                      L"value"                /**< constant for value                                                             */

#define FP_TRUE                         "true"                  /**< constant for 'true'                                                            */
#define FP_FALSE                        "false"                 /**< constant for 'false'                                                           */
                                                                                                                                                   
#define FP_READ                         "read"                  /**< is the read-operation allowed? used by FPClip_Open(), FPTag_BlobRead().        */
#define FP_WRITE                        "write"                 /**< is the write-operation allowed? used by FPClip_Write(), FPTag_BlobWrite()      */
#define FP_DELETE                       "delete"                /**< is the delete-operation allowed? used by FPClip_Delete()                       */
#define FP_PURGE                        "purge"                 /**< is the purge-operation allowed? used by FPClip_Purge(), FPTag_BlobPurge()      */
#define FP_EXIST                        "exist"                 /**< is the exists-operation allowed? used by FPClip_Exists()                       */
#define FP_CLIPENUMERATION              "clip-enumeration"      /**< is the query-operation allowed? used by FPQuery_Open()                         */
#define FP_RETENTION                    "retention"             /**< the retention period for the (Full) Compliance Centera server                  */
#define FP_BLOBNAMING                   "blobnaming"            /**< which blobnaming methods are allowed by the server?                            */
#define FP_MONITOR                      "monitor"               /**< are the monitor-operations present on the server? Used by FPMonitor__XX()      */
#define FP_DELETIONLOGGING              "deletionlogging"       /**< are deletions logged on the server?                                            */
#define FP_PRIVILEGEDDELETE             "privileged-delete"     /**< are privileged deletes allowed?                                                */
#define FP_POOL_POOLMAPPINGS            "poolmappings"          /**< what are all the pool mappings for all the profiles or pools?                  */
#define FP_COMPLIANCE                   "compliance" 
                                                                                                                                                   
#define FP_ALLOWED                      "allowed"               /**< attributeName indicates that operation is allowed                              */
#define FP_SUPPORTED                    "supported"             /**< attributeName indicates that operation is supported                            */
#define FP_UNSUPPORTED                  "unsupported"           /**< attributeName indicates that operation is unsupported                          */
#define FP_DUPLICATEDETECTION           "duplicate-detection"   /**< @deprecated                                                                    */
#define FP_DEFAULT                      "default"               /**< attributeName to indicate default value                                        */
#define FP_SUPPORTED_SCHEMES            "supported-schemes"     /**< attributeName to indicate supported blobnaming schemes                         */
#define FP_MD5                          "MD5"                   /**< MD5 blobnaming scheme                                                          */
#define FP_MG                           "MG"                    /**< MD5-GUID blobnaming scheme                                                     */
#define FP_POOLS                        "pools"                 /**< List all pools that relate to the particular tag capability                    */
#define FP_PROFILES                     "profiles"              /**< List the profiles that have a pool mapping installed                           */
#define FP_MODE                         "mode"
#define FP_EVENT_BASED_RETENTION        "ebr"                   /**< event based retention capability                                               */
#define FP_RETENTION_HOLD               "retention-hold"        /**< litigation hold capability                                                     */
#define FP_FIXED_RETENTION_MIN          "fixedminimum"          /**< retention fixed minimum time allowed                                           */
#define FP_FIXED_RETENTION_MAX          "fixedmaximum"          /**< retention fixed maximum time allowed                                           */
#define FP_VARIABLE_RETENTION_MIN       "variableminimum"       /**< retention variable minimum time allowed                                        */
#define FP_VARIABLE_RETENTION_MAX       "variablemaximum"       /**< retention variable maximum time allowed                                        */
#define FP_RETENTION_DEFAULT            "default"               /**< retention default time allowed                                                 */
#define FP_RETENTION_MIN_MAX            "min-max"               /**< constant for min-max                                                           */
#define FP_VALUE                        "value"                 /**< constant for value                                                             */

/** @} */

/** @name FPLibrary object types
    These structures encapsulate information about the FilePool Server, but they 
    are opaque to the user
    @{ */
typedef FPLong FPPoolRef ;
typedef FPLong FPClipRef ;
typedef FPLong FPTagRef ;
typedef FPLong FPQueryRef ;
typedef FPLong FPQueryExpressionRef ;
typedef FPLong FPPoolQueryRef ;
typedef FPLong FPQueryResultRef ;
typedef FPLong FPMonitorRef ;
typedef FPLong FPEventCallbackRef ;
typedef FPLong FPRetentionClassContextRef;
typedef FPLong FPRetentionClassRef;

/** @} */
/** @} */ /* defines */

#ifdef __MWERKS__
#pragma mark Pool functions
#endif

#ifdef _WIN32
# if defined(_MSC_VER) || defined(__MWERKS__) || defined(__GNUC__) || (__BORLANDC >= 0x0500)
#  pragma pack (8)
# endif
# if defined(__BORLANDC__) && (__BORLANDC__ <= 0x0500)
#  pragma option -a8
# endif
#endif

/** @defgroup Pool Pool functions
    @{

    The pool functions are a set of function calls that operate at
    pool level. A pool normally consists of multiple clusters or
    nodes, each with their own IP address or DNS name and port
    number(s).

    The system must establish a connection to the pool before
    performing a pool operation. The application should provide one or
    more addresses of the available Access Nodes.

    @note You must close the connection to a pool if that connection is no
    longer needed.
*/

/** The structure that will store the pool information that
    FPPool_GetPoolInfo() retrieves.
  */
typedef struct {

  FPInt     poolInfoVersion;        /**< The current version of this structure (2)          */

  #if __SASC__==650   
  FPInt     dummyint;               /**< need double word boundary for SAS/C 6.50           */
  #endif

  FPLong    capacity;               /**< The total capacity of the pool, in bytes.          */
  
  FPLong    freeSpace;              /**< The total free space of the pool, in bytes.        */
  
  char      clusterID[128];         /**< The cluster identifier of the pool.                */
 
  char      clusterName[128];       /**< The name of the cluster.                           */
 
  char      version[128];           /**< The version of the pool server software.           */

  char      replicaAddress[256];    /**< The pool address (see FPPool_Open()) where the C-Clips are replicated; empty if there is no replication. */ 

} FPPoolInfo;

/** The structure that holds error information, which is retrieved by the FPPool_GetLastErrorInfo()
    function.
  */
typedef struct {
 
  FPInt     error;             /**< The last FPLibrary error that occurred on this thread. */
   
  FPInt     systemError;       /**< The last system error that occurred on this thread.    */
  
  char*     trace;             /**< The function trace for the last error that occurred.   */
  
  char*     message;           /**< The message associated with the FPLibrary error. <br>The string should <b>not</b> be deallocated or modified by the application.        */
  
  char*     errorString ;      /**< The error string associated with the FPLibrary error. <br>The string should <b>not</b> be deallocated or modified by the application.   */
  
  FPShort   errorClass ;       /**< Keeps the class of message:<br>1: Network error <br>2: Server error <br>3: Client error                                                  */

} FPErrorInfo;

#ifdef _WIN32
# if defined(_MSC_VER) || defined(__MWERKS__) || defined(__GNUC__) || (__BORLANDC >= 0x0500)
#  pragma pack ()
# endif
# if defined(__BORLANDC__) && (__BORLANDC__ < 0x0500)
#  pragma option -a-
# endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

  /**
     Provides access to a pool. It will establish a connection with
     one of the Access Nodes and retrieve pool-specific information
     to handle the storage and retrieval of data. The function
     requires one or more addresses of available Access Nodes and
     returns a reference to the opened pool.

     @note Use the FPPool_Close() function to close the pool. Be sure
     to close all pool connections that are no longer needed in order
     to avoid performance loss and resource leakage.

     @param inPoolAddress a comma-separated string containing one or
     more addresses of the available Access Nodes of the pool. The
     format is:

     <pre>
     pooladdress ::= hintlist
     hintlist ::= hint ("," hint)*
     hint ::= [ protocol "://" ] ipreference [ ":" port ]
     protocol ::= "hpp"
     port ::= [0-9]+ (default is 3218)
     ipreference ::= dnsname | ip-address
   
     dnsname ::= DNS name is a DNS maintained name that resolves to
     one or more IP addresses (using round-robin) max length is 256 chars

     ip-address ::= 4-tuple address format
     </pre>

     <b>Examples:</b>

     <pre>
     MyPoolAddress = "152.62.69.153";
     MyPool = FPPool_Open (MyPoolAddress);

     MyPoolAddress = "hpp://centera.acme.com:3218,152.62.69.153";
     MyPool = FPPool_Open (MyPoolAddress);
     </pre>

     @return A reference to the pool, or zero if unsuccessful.

     @since 1.0
  */
  EXPORT FPPoolRef DECL FPPool_Open (const char *inPoolAddress);


  /**
     Takes a wide-character string as input parameter.
     @see FPPool_Open() 

     @since 1.1
  */
  EXPORT FPPoolRef DECL FPPool_OpenW (const wchar_t *inPoolAddress);

  /**
     Uses UTF-8 encoding
     @see FPPool_Open() 
   */
  EXPORT FPPoolRef DECL FPPool_Open8 (const char *inPoolAddr);

  /**
     Uses UTF-16 encoding
     @see FPPool_Open() 
   */
  EXPORT FPPoolRef DECL FPPool_Open16 (const FPChar16 *inPoolAddr);

  /**
     Uses UTF-32 encoding
     @see FPPool_Open() 
   */
  EXPORT FPPoolRef DECL FPPool_Open32 (const FPChar32 *inPoolAddr);

  /**
     Closes the connection to the given pool and frees resources
     associated with the connection. Be aware that using this function
     on a pool that has already been closed, may produce unwanted
     results.

     @note Be sure to close all pool connections that are no longer
     needed in order to avoid performance loss and resource leakage.

     @param inPool   a reference to a pool as returned by FPPool_Open()
     
     @since 1.0
  */
  EXPORT void DECL FPPool_Close (const FPPoolRef inPool);


  /**
     Sets options to the given pool.
     The pool should have been opened with the FPPool_Open() function first.

     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inOptionName a string with the name of the option to be
     Set. The following options can be Set:
     <dl>
      <dt>#FP_OPTION_BUFFERSIZE ("buffersize")<dd>The size of internal
     memory buffers in bytes. The default value is 16*1024. The
     minimum value is 1 Kbyte, the maximum value is 10 Mbyte.

      <dt>#FP_OPTION_TIMEOUT ("timeout")<dd>TCP/IP connection timeout in
     milliseconds. The default value is 120000 ms. The maximum value
     is 600000 ms (10 minutes).
     
      <dt>#FP_OPTION_ENABLE_MULTICLUSTER_FAILOVER ("multiclusterfailover")<dd>enables
     failover to another cluster. (since 1.2)
     
      <dt>#FP_OPTION_DEFAULT_COLLISION_AVOIDANCE ("collisionavoidance")<dd>enables
     collision avoidance of C-Clip / Blob Content Address by adding a 
     globally unique ID.  (since 2.0)
     </dl>

     @param inOptionValue the value for the given option.
     
     <b>Example:</b>

     <pre>
     BufferSize = 32*1024;
     FPPool_SetIntOption (MyPool, FP_OPTION_BUFFERSIZE, BufferSize);
     </pre>
        
    @since 1.0
  */
  EXPORT void DECL FPPool_SetIntOption (const FPPoolRef inPool,
                                        const char *inOptionName,
                                        const FPInt inOptionValue);


  /**
     Same as FPPool_SetIntOption(), but with a
     wide-character string for the name of the option.

     @since 1.1
  */
  EXPORT void DECL FPPool_SetIntOptionW (const FPPoolRef inPool,
                                         const wchar_t *inOptionName,
                                         const FPInt inOptionValue);

  /**
     Uses UTF-8 encoding
     @see FPPool_SetIntOption() 
   */
  EXPORT void DECL FPPool_SetIntOption8 (const FPPoolRef inPool,
                                         const char *inOptionName,
                                         const FPInt inOptionValue);

  /**
     Uses UTF-16 encoding
     @see FPPool_SetIntOption() 
   */
  EXPORT void DECL FPPool_SetIntOption16 (const FPPoolRef inPool,
                                          const FPChar16 *inOptionName,
                                          const FPInt inOptionValue);

  /**
     Uses UTF-32 encoding
     @see FPPool_SetIntOption() 
   */
  EXPORT void DECL FPPool_SetIntOption32 (const FPPoolRef inPool,
                                          const FPChar32 *inOptionName,
                                          const FPInt inOptionValue);
  
  /**
     Retrieves options about the FPPool. The FPPool must have been opened with 
     FPPool_Open first.
     
     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inOptionName a string with the name of the option to be
     Set. See FPPool_SetIntOption() for a list of allowed option names.
   
     @return the value of an option
     
     @since 1.2
  */
     
  EXPORT FPInt DECL FPPool_GetIntOption (const FPPoolRef inPool, 
                                         const char *inOptionName);
                                                
  /**
     Same as FPPool_GetIntOption() but for wide-character option name.
     
     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inOptionName a string with the name of the option to be
     Set. See FPPool_SetIntOption() for a list of allowed option names.
   
     @return the value of an option
     
     @since 1.2
  */
       
  EXPORT FPInt DECL FPPool_GetIntOptionW (const FPPoolRef inPool, 
                                          const wchar_t *inOptionName);

  /**
     Uses UTF-8 encoding
     @see FPPool_GetIntOption()  
   */
  EXPORT FPInt DECL FPPool_GetIntOption8 (const FPPoolRef inPool, 
                                          const char *inOptionName);

  /**
     Uses UTF-16 encoding
     @see FPPool_GetIntOption() 
   */
  EXPORT FPInt DECL FPPool_GetIntOption16 (const FPPoolRef inPool, 
                                           const FPChar16 *inOptionName);

  /**
     Uses UTF-32 encoding
     @see FPPool_GetIntOption() 
   */
  EXPORT FPInt DECL FPPool_GetIntOption32 (const FPPoolRef inPool, 
                                           const FPChar32 *inOptionName);


  /**
     Sets a library-wide option.  The new option takes effect
     immediately and affects all the running threads of the
     application, but not any other application that may be using the
     FPLibrary at the same time on the same machine.

     @param inOptionName the name of the option to be Set. These option names are
     allowed:
     <dl>
       <dt>#FP_OPTION_RETRYCOUNT ("retrycount") <dd>The number of retries that the
       library attempts before reporting an error.  The default value is 6.

       <dt>#FP_OPTION_RETRYSLEEP ("retrysleep") <dd>The number of milliseconds 
       between retries.  The default value is 2000 ms. The maximum value is 
       100000 ms.

       <dt>#FP_OPTION_MAXCONNECTIONS ("maxconnections") <dd>The maximum number of 
       connections opened simultaneously by a single FPPool; also known as
       the size of the connection pool.  The default value is 100; valid values 
       are 0 to 999 inclusive.  The value 0 disables connection pooling, allowing
       the FPLibrary to open as many connections as necessary. (since 1.1) 
     </dl>
     
     @param inOptionValue The value of the option

     <b>Example:</b>

     <pre>
     RetryCount = 0;
     FPPool_SetGlobalOption (FP_OPTION_RETRYCOUNT, RetryCount);
     </pre>

     @since 1.1
  */
  EXPORT void DECL FPPool_SetGlobalOption (const char *inOptionName,
                                           const FPInt inOptionValue);

  /**
     Same as FPPool_SetGlobalOption(), but with a wide-character
     string for the name of the option.

     @since 1.1
  */
  EXPORT void DECL FPPool_SetGlobalOptionW (const wchar_t *inOptionName,
                                            const FPInt inOptionValue);

  /**
     Uses UTF-8 encoding
     @see FPPool_SetGlobalOption() 
   */
  EXPORT void DECL FPPool_SetGlobalOption8 (const char *inOptionName,
                                            const FPInt inOptionValue);

  /**
     Uses UTF-16 encoding
     @see FPPool_SetGlobalOption() 
   */
  EXPORT void DECL FPPool_SetGlobalOption16 (const FPChar16 *inOptionName,
                                             const FPInt inOptionValue);
  
  /**
     Uses UTF-32 encoding
     @see FPPool_SetGlobalOption() 
   */
  EXPORT void DECL FPPool_SetGlobalOption32 (const FPChar32 *inOptionName,
                                             const FPInt inOptionValue);

  /**
     Gets a library-wide option.  

     @param inOptionName the name of the option to be Set; 
     @see   FPPool_SetGlobalOption() for the list of possible option names
     
     @since 1.2
  */
     
  EXPORT FPInt DECL FPPool_GetGlobalOption (const char *inOptionName) ;

  /**
     Gets a library-wide option.  

     @param inOptionName the name of the option to be Set; 
     @see   FPPool_SetGlobalOption() for the of possible option names
     
     @return the value of the option
     
     @since 1.2
  */

  EXPORT FPInt DECL FPPool_GetGlobalOptionW (const wchar_t *inOptionName) ;

  /**
     Uses UTF-8 encoding
     @see FPPool_GetGlobalOption()  
   */
  EXPORT FPInt DECL FPPool_GetGlobalOption8 (const char *inOptionName) ;

  /**
     Uses UTF-16 encoding
     @see FPPool_GetGlobalOption() 
   */
  EXPORT FPInt DECL FPPool_GetGlobalOption16 (const FPChar16 *inOptionName) ;

  /**
     Uses UTF-32 encoding
     @see FPPool_GetGlobalOption() 
   */
  EXPORT FPInt DECL FPPool_GetGlobalOption32 (const FPChar32 *inOptionName) ;

  
  /**
     This function retrieves the error status of the last FPLibrary
     function call and returns the number of the error. If no errors
     were generated, the return value is ENOERR (zero).  Please refer to the
     API Reference Guide for the error codes.
     
     Use the FPPool_GetLastErrorInfo() if you want to retrieve further
     information about the error.

     @note Check the error status after each function call, because
     every function call resets the error status to ENOERR before
     executing.
     
     @return the error result of the last FPLibrary call.

     @since 1.0
  */
  EXPORT FPInt DECL FPPool_GetLastError (void);

  /**
     This function stores your application's name and version, so
     that it may be logged on the Centera.

     @param inAppName A null-terminated string containing the application
                      name
     @param inAppVer  A null-terminated string containing the application
                      version

  */
  EXPORT void DECL FPPool_RegisterApplication(const char* inAppName,
                                              const char* inAppVer);
  /**
     Uses UTF-8 encoding
     @see FPPool_RegisterApplication()  
   */
  EXPORT void DECL FPPool_RegisterApplication8(const char* inAppName,
                                               const char* inAppVer);
  /**
     Uses UTF-16 encoding
     @see FPPool_RegisterApplication() 
   */
  EXPORT void DECL FPPool_RegisterApplication16(const FPChar16* inAppName,
                                                const FPChar16* inAppVer);
  /**
     Uses UTF-32 encoding
     @see FPPool_RegisterApplication() 
   */
  EXPORT void DECL FPPool_RegisterApplication32(const FPChar32* inAppName,
                                                const FPChar32* inAppVer);
  /**
     Uses wide-character strings for the arguments.
     @see FPPool_RegisterApplication() 
  */
  EXPORT void DECL FPPool_RegisterApplicationW(const wchar_t* inAppName,
                                               const wchar_t* inAppVer);
  /**
     This function retrieves the error status of the last FPLibrary
     function call and returns information about the error in the
     FPErrorInfo structure. If no errors were generated, the returned
     structure has null values in its data fields.
     
     @note Check the error status after each function call, because
     every function call resets the error status before executing.
     
     @note Do not modify the contents of the outErrorInfo structure.  Do <b>not</b>
     deallocate the string member variables.

     @param outErrorInfo an instance of the FPErrorInfo structure
     
     @since 2.0
  */
  EXPORT void  DECL FPPool_GetLastErrorInfo (FPErrorInfo *outErrorInfo);
  

  /**
     This function retrieves information about the given pool and
     saves it in outPoolInfo.

     @since 1.0
  */
 #define FPPool_GetPoolInfo(inPool,outPoolInfo) { if (outPoolInfo) { (outPoolInfo)->poolInfoVersion=FPPOOL_INFO_VERSION ; } _FPPool_GetPoolInfo(inPool,outPoolInfo); }

  /**
     This function retrieves information about the given pool and
     saves it in outPoolInfo.  This function is a helper function for the 
     FPPool_GetPoolInfo-macro which <b>must</b> be used instead.

     @param inPool     a reference to an open pool
     @param outPoolInfo   an instance of an FPPoolInfo structure
     
     @since 1.0
  */
  EXPORT void DECL _FPPool_GetPoolInfo (const FPPoolRef inPool, 
                                        FPPoolInfo *outPoolInfo);


  /**
    This function retrieves the current server capability for a tag/attribute.
    
    Refer to the documentation on the FPPool_GetCapabilities() function in
    the SDK APIRefGuide for a list of some of the allowable parameters into 
    this function. The actual parameters are controlled by the version of the CentraStar
    software.

    @param inPool                a reference to an open pool
    @param inCapabilityName      capability tag name
    @param inCapabilityAttributeName attribute within capability tag
    @param outCapabilityValue    Pointer to a memory buffer to receive the 
                                 capability string.
    @param ioCapabilityValueLen  On input the length of the outCapabilityValue 
                                 buffer.  On output the the actual length of the 
                                 string
    
    @since 1.2
  */
  EXPORT void DECL FPPool_GetCapability (const FPPoolRef inPool,
                                         const char *inCapabilityName, 
                                         const char *inCapabilityAttributeName,
                                         char *outCapabilityValue, 
                                         FPInt *ioCapabilityValueLen);

  /**
    This function retrieves the current server capability for a tag/attribute.

    Same as FPPool_GetCapability(), but with wide-character parameters.
    
    @param inPool                a reference to an open pool
    @param inCapabilityName      capability tag name
    @param inCapabilityAttributeName attribute within capability tag
    @param outCapabilityValue    Pointer to a memory buffer to receive the 
                                 capability string.
    @param ioCapabilityValueLen  On input the length of the outCapabilityValue 
                                 buffer.  On output the the actual length of the string
    
    @since 1.2
  */
  EXPORT void DECL FPPool_GetCapabilityW (const FPPoolRef inPool, 
                                          const wchar_t *inCapabilityName,
                                          const wchar_t *inCapabilityAttributeName,
                                          wchar_t *outCapabilityValue, 
                                          FPInt *ioCapabilityValueLen);

  /**
     uses UTF-8 encoding
     @see FPPool_GetCapability()
   */
  EXPORT void DECL FPPool_GetCapability8 (const FPPoolRef inPool, 
                                          const char *inCapabilityName, 
                                          const char *inCapabilityAttributeName,
                                          char *outCapabilityValue, 
                                          FPInt *ioCapabilityValueLen);

  /**
     Uses UTF-16 encoding
     @see FPPool_GetCapability() 
   */
  EXPORT void DECL FPPool_GetCapability16 (const FPPoolRef inPool, 
                                           const FPChar16 *inCapabilityName, 
                                           const FPChar16 *inCapabilityAttributeName,
                                           FPChar16 *outCapabilityValue, 
                                           FPInt *ioCapabilityValueLen);

  /**
     Uses UTF-32 encoding
     @see FPPool_GetCapability() 
   */
  EXPORT void DECL FPPool_GetCapability32 (const FPPoolRef inPool, 
                                           const FPChar32 *inCapabilityName, 
                                           const FPChar32 *inCapabilityAttributeName,
                                           FPChar32 *outCapabilityValue, 
                                           FPInt *ioCapabilityValueLen);

  /**
    This function retrieves the current server time.
    
    @param inPool    A reference to an open pool
    @param outClusterTime Pointer to a memory buffer to receive the cluster date/time in 
                "YYYY.MM.DD hh:mm:ss GMT" format
    @param ioClusterTimeLen On input the length of the outClusterTime buffer.  On output the
                the actual length of the string
    
    @since 1.2
  */
  EXPORT void DECL FPPool_GetClusterTime (const FPPoolRef inPool, char *outClusterTime, FPInt *ioClusterTimeLen);

  /**
    Wide version
    @see FPPool_GetClusterTime
    @since 2.4
  */
  EXPORT void DECL FPPool_GetClusterTimeW (const FPPoolRef inPool, wchar_t *outClusterTime, FPInt *ioClusterTimeLen);

  /**
    Uses UTF-8 encoding
    @see FPPool_GetClusterTime() 
    @since 2.4
  */
  EXPORT void DECL FPPool_GetClusterTime8 (const FPPoolRef inPool, char *outClusterTime, FPInt *ioClusterTimeLen);

  /**
    Uses UTF-16 encoding
    @see FPPool_GetClusterTime() 
    @since 2.4
  */
  EXPORT void DECL FPPool_GetClusterTime16 (const FPPoolRef inPool, FPChar16 *outClusterTime, FPInt *ioClusterTimeLen);

  /**
    Uses UTF-32 encoding
    @see FPPool_GetClusterTime() 
    @since 2.4
  */
  EXPORT void DECL FPPool_GetClusterTime32 (const FPPoolRef inPool, FPChar32 *outClusterTime, FPInt *ioClusterTimeLen);

  /**
    This function converts the string returned by FPPool_GetClusterTime() to an
    FPLong representing the number of seconds since the epoch
    1 January 1970 00:00:00.  Times before the epoch are unsupported.
    
    @param inClusterTime Pointer to a memory buffer containing the cluster
           date/time in "YYYY.MM.DD hh:mm:ss GMT" format, as returned by
           FPPool_GetClusterTime()
    
    @since 3.0

    @deprecated use FPTime_StringToSeconds or FPTime_StringToMilliseconds 
                instead
  */
  EXPORT FPLong DECL FPTime_StringToLong (const char *inClusterTime);

  /**
    Wide version
    @see FPTime_StringToLong()
    @since 3.0
    @deprecated
  */
  EXPORT FPLong DECL FPTime_StringToLongW (const wchar_t *inClusterTime);

  /**
    Uses UTF-8 encoding
    @see FPTime_StringToLong()
    @since 3.0
    @deprecated
  */
  EXPORT FPLong DECL FPTime_StringToLong8 (const char *inClusterTime);

  /**
    Uses UTF-16 encoding
    @see FPTime_StringToLong() 
    @since 3.0
    @deprecated
  */
  EXPORT FPLong DECL FPTime_StringToLong16 (const FPChar16 *inClusterTime);

  /**
    Uses UTF-32 encoding
    @see FPTime_StringToLong() 
    @since 3.0
    @deprecated
  */
  EXPORT FPLong DECL FPTime_StringToLong32 (const FPChar32 *inClusterTime);

  /**
    This function converts an FPLong representing the number of seconds since
    the epoch of 1 January 1970 00:00:00, into a string of the form
    "YYYY.MM.DD HH:MM:SS GMT".  Times before the epoch are unsupported.
    
    @param inTime FPLong representing the number of seconds since the epoch

    @param outClusterTime A buffer which will contain the output string.

    @param ioClusterTimeLen On input the length of the outClusterTime
           buffer.  On output this parameter is the number of characters in
           the string, including the null terminator.

    @since 3.0

    @deprecated use FPTime_SecondsToString or FPTime_MillisecondsToString 
                instead
  */
  EXPORT void DECL FPTime_LongToString (const FPLong inTime,
                                        char *outClusterTime,
                                        FPInt *ioClusterTimeLen);

  /**
    Wide version
    @see FPTime_LongToString()
    @since 3.0
    @deprecated
  */
  EXPORT void DECL FPTime_LongToStringW (const FPLong inTime,
                                         wchar_t *outClusterTime,
                                         FPInt *ioClusterTimeLen);

  /**
    Uses UTF-8 encoding
    @see FPTime_LongToString()
    @since 3.0
    @deprecated
  */
  EXPORT void DECL FPTime_LongToString8 (const FPLong inTime,
                                         char *outClusterTime,
                                         FPInt *ioClusterTimeLen);

  /**
    Uses UTF-16 encoding
    @see FPTime_LongToString() 
    @since 3.0
    @deprecated
  */
  EXPORT void DECL FPTime_LongToString16 (const FPLong inTime,
                                          FPChar16 *outClusterTime,
                                          FPInt *ioClusterTimeLen);

  /**
    Uses UTF-32 encoding
    @see FPTime_LongToString() 
    @since 3.0
    @deprecated
  */
  EXPORT void DECL FPTime_LongToString32 (const FPLong inTime,
                                          FPChar32 *outClusterTime,
                                          FPInt *ioClusterTimeLen);

  /**
    This function converts the string returned by FPPool_GetClusterTime() to an
    FPLong representing the number of seconds since the epoch
    1 January 1970 00:00:00.  Times before the epoch are unsupported.
    
    @param inClusterTime Pointer to a memory buffer containing the cluster
           date/time in "YYYY.MM.DD hh:mm:ss[.ms] GMT" format
    
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToSeconds (const char *inClusterTime);

  /**
    Wide version
    @see FPTime_StringToSeconds()
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToSecondsW (const wchar_t *inClusterTime);

  /**
    Uses UTF-8 encoding
    @see FPTime_StringToSeconds()
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToSeconds8 (const char *inClusterTime);

  /**
    Uses UTF-16 encoding
    @see FPTime_StringToSeconds() 
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToSeconds16 (const FPChar16 *inClusterTime);

  /**
    Uses UTF-32 encoding
    @see FPTime_StringToSeconds() 
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToSeconds32 (const FPChar32 *inClusterTime);

  /**
    This function converts an FPLong representing the number of seconds since
    the epoch of 1 January 1970 00:00:00, into a string of the form
    "YYYY.MM.DD HH:MM:SS[.ms] GMT".  Times before the epoch are unsupported.
    
    @param inTime FPLong representing the number of seconds since the epoch
    @param outClusterTime A buffer which will contain the output string.
    @param ioClusterTimeLen On input the length of the outClusterTime
           buffer.  On output this parameter is the number of characters in
           the string, including the null terminator.
    @param inOptions Configures whether the created string contains the
           milliseconds field or not.  Possible values are
           FP_OPTION_MILLISECONDS_STRING, or FP_OPTION_SECONDS_STRING.
    @since 3.1
  */
  EXPORT void DECL FPTime_SecondsToString (const FPLong inTime,
                                           char *outClusterTime,
                                           FPInt *ioClusterTimeLen,
                                           FPInt inOptions);

  /**
    Wide version
    @see FPTime_SecondsToString()
    @since 3.1
  */
  EXPORT void DECL FPTime_SecondsToStringW (const FPLong inTime,
                                            wchar_t *outClusterTime,
                                            FPInt *ioClusterTimeLen,
                                            FPInt inOptions);

  /**
    Uses UTF-8 encoding
    @see FPTime_SecondsToString()
    @since 3.1
  */
  EXPORT void DECL FPTime_SecondsToString8 (const FPLong inTime,
                                            char *outClusterTime,
                                            FPInt *ioClusterTimeLen,
                                            FPInt inOptions);

  /**
    Uses UTF-16 encoding
    @see FPTime_SecondsToString() 
    @since 3.1
  */
  EXPORT void DECL FPTime_SecondsToString16 (const FPLong inTime,
                                             FPChar16 *outClusterTime,
                                             FPInt *ioClusterTimeLen,
                                             FPInt inOptions);

  /**
    Uses UTF-32 encoding
    @see FPTime_SecondsToString() 
    @since 3.1
  */
  EXPORT void DECL FPTime_SecondsToString32 (const FPLong inTime,
                                             FPChar32 *outClusterTime,
                                             FPInt *ioClusterTimeLen,
                                             FPInt inOptions);
                                          
  /**
    This function converts the string returned by FPPool_GetClusterTime() to an
    FPLong representing the number of milliseconds since the epoch
    1 January 1970 00:00:00.  Times before the epoch are unsupported.
    
    @param inClusterTime Pointer to a memory buffer containing the cluster
           date/time in "YYYY.MM.DD hh:mm:ss[.ms] GMT" format
    
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToMilliseconds (const char *inClusterTime);

  /**
    Wide version
    @see FPTime_StringToMilliseconds()
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToMillisecondsW (const wchar_t *inClusterTime);

  /**
    Uses UTF-8 encoding
    @see FPTime_StringToMilliseconds()
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToMilliseconds8 (const char *inClusterTime);

  /**
    Uses UTF-16 encoding
    @see FPTime_StringToMilliseconds() 
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToMilliseconds16 (const FPChar16 *inClusterTime);

  /**
    Uses UTF-32 encoding
    @see FPTime_StringToMilliseconds() 
    @since 3.1
  */
  EXPORT FPLong DECL FPTime_StringToMilliseconds32 (const FPChar32 *inClusterTime);

  /**
    This function converts an FPLong representing the number of milliseconds
    since the epoch of 1 January 1970 00:00:00, into a string of the form
    "YYYY.MM.DD HH:MM:SS GMT".  Times before the epoch are unsupported.
    
    @param inTime FPLong representing the number of milliseconds since the epoch
    @param outClusterTime A buffer which will contain the output string.
    @param ioClusterTimeLen On input the length of the outClusterTime
           buffer.  On output this parameter is the number of characters in
           the string, including the null terminator.
    @param inOptions Configures whether the created string contains the milliseconds
           field or not.  Possible values are FP_OPTION_MILLISECONDS_STRING, or
           FP_OPTION_SECONDS_STRING.
    @since 3.1
  */
  EXPORT void DECL FPTime_MillisecondsToString (const FPLong inTime,
                                                char *outClusterTime,
                                                FPInt *ioClusterTimeLen,
                                                FPInt inOptions);

  /**
    Wide version
    @see FPTime_MillisecondsToString()
    @since 3.1
  */
  EXPORT void DECL FPTime_MillisecondsToStringW (const FPLong inTime,
                                                 wchar_t *outClusterTime,
                                                 FPInt *ioClusterTimeLen,
                                                 FPInt inOptions);

  /**
    Uses UTF-8 encoding
    @see FPTime_MillisecondsToString()
    @since 3.1
  */
  EXPORT void DECL FPTime_MillisecondsToString8 (const FPLong inTime,
                                                 char *outClusterTime,
                                                 FPInt *ioClusterTimeLen,
                                                 FPInt inOptions);

  /**
    Uses UTF-16 encoding
    @see FPTime_MillisecondsToString() 
    @since 3.1
  */
  EXPORT void DECL FPTime_MillisecondsToString16 (const FPLong inTime,
                                                  FPChar16 *outClusterTime,
                                                  FPInt *ioClusterTimeLen,
                                                  FPInt inOptions);

  /**
    Uses UTF-32 encoding
    @see FPTime_MillisecondsToString() 
    @since 3.1
  */
  EXPORT void DECL FPTime_MillisecondsToString32 (const FPLong inTime,
                                                  FPChar32 *outClusterTime,
                                                  FPInt *ioClusterTimeLen,
                                                  FPInt inOptions);

  /**
    This function returns the version of the different Centera Client Libraries
    
    @param inComponent  indicates the component that we want the version of:
            - 1 FPLibrary.dll
            - 2 FPLibrary.jar (only available in Java)
    @param outVersion    Pointer to a memory buffer to receive the version string
    @param ioVersionLen On input the length of the outVersion buffer. On output the actual length
                       of the string (without end-of-string character)
    
    @since 1.2
   */
   EXPORT void DECL FPPool_GetComponentVersion (const FPInt inComponent,
                                                char  *outVersion,
                                                FPInt *ioVersionLen) ;

  /**
    This function returns the version of the different Centera Client Libraries

    Same as FPPool_GetComponentVersion(), but with wide-character parameters.
    
    @param inComponent  indicates the component that we want the version of:
            - 1 FPLibrary.dll
            - 2 FPLibrary.jar (only available in Java)
    @param outVersion   Pointer to a memory buffer to receive the version string
    @param ioVersionLen On input the length of the outVersion buffer. On output the actual length
                       of the string (without end-of-string character)
    
    @since 1.2
   */
   EXPORT void DECL FPPool_GetComponentVersionW (const FPInt inComponent,
                                                 wchar_t *outVersion,
                                                 FPInt *ioVersionLen) ;
   /**
     Same as FPPool_GetComponentVersion(), but uses UTF-8 encoding
    */
   EXPORT void DECL FPPool_GetComponentVersion8 (const FPInt inComponent,
                                                 char *outVersion,
                                                 FPInt *ioVersionLen) ;

   /**
      Uses UTF-16 encoding
      @see FPPool_GetComponentVersion() 
    */
   EXPORT void DECL FPPool_GetComponentVersion16 (const FPInt inComponent,
                                                  FPChar16 *outVersion,
                                                  FPInt *ioVersionLen) ;

   /**
      Uses UTF-32 encoding
      @see FPPool_GetComponentVersion() 
    */
   EXPORT void DECL FPPool_GetComponentVersion32 (const FPInt inComponent,
                                                  FPChar32 *outVersion,
                                                  FPInt *ioVersionLen) ;



  /** @} */ /* pool functions */

#ifdef __MWERKS__
#pragma mark Clip functions
#endif

  /** @defgroup Clip Clip functions
      @{

      The clip functions are a Set of function calls that operate on
      C-Clips. A clip function can handle an entire C-Clip, retrieve
      information about a C-Clip, or retrieve a single tag from a
      C-Clip. Therefore the three groups of clip functions are:

      - clip handling functions
      - clip info functions
      - clip tag functions

      You must open the C-Clip before you can perform a clip function
      (do not forget to close the C-Clip when you are finished).
  */


  /**
     Creates a new, empty C-Clip and stores it in memory. The function
     returns a reference to the new C-Clip.

     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inName A string holding the name of the C-Clip.  Note: If inName 
     is NULL, the name of the C-Clip will be "untitled".

     @return a reference to an open C-Clip, or NULL in case of error

     <b>Example:</b>
     <pre>
     MyClip = FPClip_Create (MyPool, "anotherclip");
     </pre>

     @since 1.0
  */
  EXPORT FPClipRef DECL FPClip_Create (const FPPoolRef inPool, 
                                       const char *inName);


  /** Same as FPClip_Create(), but using wide characters.  This
      function accepts
      <a href="http://www.w3.org/TR/REC-xml#NT-Name">all Unicode
      characters specified by the XML 1.0 standard</a>.

      @since 1.1
  */
  EXPORT FPClipRef DECL FPClip_CreateW (const FPPoolRef inPool, 
                                        const wchar_t *inName);

  /**
     Uses UTF-8 encoding
     @see FPClip_Create() 
   */
  EXPORT FPClipRef DECL FPClip_Create8 (const FPPoolRef inPool, 
                                        const char *inName);

  /**
     Uses UTF-16 encoding
     @see FPClip_Create() 
   */
  EXPORT FPClipRef DECL FPClip_Create16 (const FPPoolRef inPool, 
                                         const FPChar16 *inName);

  /**
     Uses UTF-32 encoding
     @see FPClip_Create() 
   */
  EXPORT FPClipRef DECL FPClip_Create32 (const FPPoolRef inPool, 
                                         const FPChar32 *inName);


  /**
     With FPClip_Open, you can open a stored C-Clip either as a tree
     structure or as a flat structure. The function returns a
     reference to the opened C-Clip.

     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inClipID The C-Clip ID that the FPClip_Write() function has
     returned.

     @param inOpenMode The method of opening a C-Clip. Current options
     are:
     <dl>
      <dt>#FP_OPEN_ASTREE <dd>opens the C-Clip as a tree structure in
     read/write mode and enables hierarchical navigation through the
     tags of the C-Clip.
      <dt>#FP_OPEN_FLAT <dd>opens the C-Clip as a flat structure in read
     only mode and enables sequential access within the C-Clip. This
     option is very useful for reading C-Clips that do not fit in
     memory.
     </dl>
     
     @return a reference to an open C-Clip, or NULL in case of error

     <b>Example:</b>
     <pre>MyClip = FPClip_Open (MyPool, MyClipID, FP_OPEN_ASTREE)</pre>

     @since 1.0
  */
  EXPORT FPClipRef DECL FPClip_Open (const FPPoolRef inPool, 
                                     const FPClipID inClipID, 
                                     const FPInt inOpenMode);


  /**
     The function closes the given C-Clip and frees up all memory
     allocated to the C-Clip. Be aware that using this function on a
     C-Clip that has already been closed, may produce unwanted
     results.  This function requires exclusive access to the C-Clip
     reference in memory.

     @note You will lose all changes when you close the C-Clip if it
     has been modified since it was opened but not yet written to the
     pool using FPClip_Write().

     @param inClip The reference to a C-Clip that was opened by the
     FPClip_Open() or FPClip_Create() function.

     @since 1.0
  */
  EXPORT void DECL FPClip_Close (const FPClipRef inClip);

  /**
    The function returns the FPPoolRef to the pool to which the clip belongs.

     @param inClip The reference to a C-Clip that was opened by the
     FPClip_Open() or FPClip_Create() function.
     
     @return the reference to an FPPoolRef used to open or create the FPClip

     @since 1.2
  */
  EXPORT FPPoolRef DECL FPClip_GetPoolRef (const FPClipRef inClip);
  
  /**
     This function determines if the given C-Clip exists in the given
     pool and returns true or false.
     The function will <b>not</b> determine if all the blobs in the C-Clip
     exist on the Centera cluster.

     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inClipID The ID of a C-Clip as created by FPClip_Write().

     @since 1.0
   */
  EXPORT FPBool DECL FPClip_Exists (const FPPoolRef inPool, 
                                    const FPClipID inClipID);


  /**
     Deletes the given C-Clip from the given pool. This call does
     not delete associated blobs.

     @note Following the successful deletion of the C-Clip, associated
     blobs may become garbage collected.

     @note Same as FPClip_AuditedDelete (inPool, inClipID, "", 0);
     
     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inClipID The ID of a C-Clip as created by FPClip_Write().

     @since 1.0
  */
  EXPORT void DECL FPClip_Delete (const FPPoolRef inPool, 
                                  const FPClipID inClipID);

  /**
     Deletes the given C-Clip from the given pool and adds audit information.
     This call does not delete associated blobs.

     @note Following the successful deletion of the C-Clip, associated
     blobs may become garbage collected.
     
     @param inPool      The reference to a pool that the FPPool_Open()
     function has opened.

     @param inClipID The ID of a C-Clip as created by FPClip_Write().
     
     @param inReason    The reason for the delete. This information will be added
                        to the audit information.
                        
     @param inOptions   Additional options to specify the delete behaviour.

     @since 2.3
  */
  EXPORT void DECL FPClip_AuditedDelete (const FPPoolRef inPool, 
                                         const FPClipID inClipID,
                                         const char *inReason, 
                                         const FPLong inOptions);

  /**
     Deletes the given C-Clip from the given pool and adds audit information.
     This call does not delete associated blobs.

     @note Following the successful deletion of the C-Clip, associated
     blobs may become garbage collected.
     
     @param inPool      The reference to a pool that the FPPool_Open()
     function has opened.

     @param inClipID The ID of a C-Clip as created by FPClip_Write().
     
     @param inReason    The reason for the delete. This information will be added
                        to the audit information.
                        
     @param inOptions   Additional options to specify the delete behaviour.

     @since 2.3
  */
  EXPORT void DECL FPClip_AuditedDeleteW (const FPPoolRef inPool, 
                                          const FPClipID inClipID,
                                          const wchar_t *inReason, 
                                          const FPLong inOptions);

  /**
   *  Same as FPClip_AuditedDelete, but uses UTF-8 encoding
   */
  EXPORT void DECL FPClip_AuditedDelete8 (const FPPoolRef inPool, 
                                          const FPClipID inClipID,
                                          const char *inReason, 
                                          const FPLong inOptions);

  /**
   *  Same as FPClip_AuditedDelete, but uses UTF-16 encoding
   */
  EXPORT void DECL FPClip_AuditedDelete16 (const FPPoolRef inPool, 
                                           const FPClipID inClipID,
                                           const FPChar16 *inReason, 
                                           const FPLong inOptions);

  /**
   *  Same as FPClip_AuditedDelete, but uses UTF-32 encoding
   */
  EXPORT void DECL FPClip_AuditedDelete32 (const FPPoolRef inPool, 
                                           const FPClipID inClipID,
                                           const FPChar32 *inReason, 
                                           const FPLong inOptions);


  /**
     Purges the given C-Clip from the given pool.
     
     Earlier versions of the Centera Access API provided this function to
     purge a CDF and associated blob(s) from the pool. From version 2.0
     this function only purges the CDF from the first writeable cluster in
     the given pool but not its associated blob(s). This function does not
     take into account the retention period and will remove the CDF,
     regardless of the expiration date of the C-Clip.

     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inClipID The ID of a C-Clip as created by FPClip_Write().

     @since 1.0
     @deprecated use FPClip_Delete() instead
  */
  EXPORT void DECL FPClip_Purge (const FPPoolRef inPool, const FPClipID inClipID);


  /**
     Retrieves a reference to the top-level tag in a C-Clip that has
     been opened as a tree. If the tag structure is empty, you can use
     the returned tag as the parent tag to create the first tag in the
     tree.

     If the tag structure is not empty, you can use the returned tag
     as a starting point for further navigation. You can use
     FPTag_GetFirstChild() and FPTag_GetSibling() to retrieve related
     tags or FPClip_FetchNext() to retrieve tags in sequential order.

     The function retrieves a reference to the first tag in a C-Clip
     that has been opened in flat mode. You can then only use
     FPClip_FetchNext() to retrieve other tags.

     @param inClip The reference to a C-Clip that was opened by the
     FPClip_Open() or FPClip_Create() function.
     
     @return a reference to the top tag of the C-Clip

     @since 1.0
  */
  EXPORT FPTagRef DECL FPClip_GetTopTag (const FPClipRef inClip);

  /**
     Retrieves the number of blobs that are stored in the given
     C-Clip.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.
     
     @return the number of blobs in the C-Clip

     @since 1.0
  */
  EXPORT FPInt DECL FPClip_GetNumBlobs (const FPClipRef inClip);

  /**
     Retrieves the number of tags that are stored in the given
     C-Clip.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.
     
     @return the number of tags in the C-Clip

     @since 1.2
  */
  EXPORT FPInt DECL FPClip_GetNumTags (const FPClipRef inClip);
  
  /**
     Retrieves the total size (in bytes) of all blobs stored in the
     given C-Clip.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @note This function does not take into consideration a blob size if it is 
           embedded.
     
     @return the size (in bytes) of all blobs in the C-Clip

     @since 1.0
  */
  EXPORT FPLong DECL FPClip_GetTotalSize (const FPClipRef inClip);


  /**
     Retrieves the ID of the given C-Clip and returns it in the inClipID parameter.
     The ID is empty if FPClip_Write() has not been called on the
     C-Clip. 
     
     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param outClipID A buffer where this function writes the ID of the
     C-Clip.

     @since 1.0
  */
  EXPORT void DECL FPClip_GetClipID (const FPClipRef inClip, FPClipID outClipID);

  /**
     Sets the name of the FPClip.
     
     @param inClip      The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param inClipName  The new name of the C-Clip.
     
     @since 2.1
   */
   
  EXPORT void DECL FPClip_SetName (const FPClipRef inClip, const char *inClipName) ;

  /**
     Sets the name of the FPClip.
     
     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param inClipName  the new name of the C-Clip.
     
     @since 2.1
   */

  EXPORT void DECL FPClip_SetNameW (const FPClipRef inClip, 
                                    const wchar_t *inClipName) ;

  /**
     Uses UTF-8 encoding
     @see FPClip_SetName 
   */
  EXPORT void DECL FPClip_SetName8 (const FPClipRef inClip, 
                                    const char *inClipName) ;

  /**
     Uses UTF-16 encoding
     @see FPClip_SetName 
   */
  EXPORT void DECL FPClip_SetName16 (const FPClipRef inClip, 
                                    const FPChar16 *inClipName);

  /**
     Uses UTF-32 encoding
     @see FPClip_SetName 
   */
  EXPORT void DECL FPClip_SetName32 (const FPClipRef inClip, 
                                     const FPChar32*inClipName) ;
  
  /**
     Retrieves the name of the given C-Clip. The name is returned in
     outName.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param outName A pointer to a buffer that will receive the name of
     the C-Clip.

     @param ioNameLen On input, this parameter must specify the size of
     the buffer in characters.  At most (*ioNameLen - 1) characters
     will be written to the buffer, plus a terminating null character.
     On output, this parameter contains the actual number of characters
     in the name, including the terminating null character.

     <b>Example:</b>
     <pre>
     int namesize = MAX_NAME_SIZE;
     char name[MAX_NAME_SIZE];
     FPClip_GetName (MyClip, name, &namesize)
     </pre>
     @since 1.0
  */
  EXPORT void DECL FPClip_GetName (const FPClipRef inClip, 
                                   char *outName, 
                                   FPInt *ioNameLen);

  /**
     Like FPClip_GetName(), but using wide characters.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param outName A pointer to a buffer that will receive the name of
     the C-Clip.

     @param ioNameLen On input, this parameter must specify the size of
     the buffer in characters (not bytes).  At most (*ioNameLen - 1)
     characters (not bytes) will be written to the buffer, plus a
     terminating null character.  On output, this parameter contains
     the actual number of characters, including the
     terminating null character.

     @since 1.1
  */
  EXPORT void DECL FPClip_GetNameW(const FPClipRef inClip, 
                                   wchar_t *outName, 
                                   FPInt *ioNameLen);

  /**
     Uses UTF-8 encoding
     @see FPClip_GetName 
   */
  EXPORT void DECL FPClip_GetName8(const FPClipRef inClip, 
                                   char *outName, 
                                   FPInt *ioNameLen);

  /**
     Uses UTF-16 encoding
     @see FPClip_GetName  
   */
  EXPORT void DECL FPClip_GetName16(const FPClipRef inClip, 
                                    FPChar16 *outName, 
                                    FPInt *ioNameLen);

  /**
     Uses UTF-32 encoding
     @see FPClip_GetName 
   */
  EXPORT void DECL FPClip_GetName32(const FPClipRef inClip, 
                                    FPChar32 *outName, 
                                    FPInt *ioNameLen);


  /**
     Retrieves the creation date of the C-Clip. The time is specified
     in UTC (Coordinated Universal Time, also known as GMT - Greenwich
     Mean Time) and is based on the cluster time.

     February 21st, 2002 is expressed as: 2002.02.21 10:46:32 GMT

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param outDate A pointer to the buffer that will store the creation
     date of the C-Clip.

     @param ioDateLen On input, this parameter must specify the size of
     the buffer in characters.  At most (*ioDateLen - 1) characters
     will be written to the buffer, plus a terminating null character.
     On output, this parameter contains the actual number of characters
     in the date, including the terminating null character.

     <b>Example:</b>
     <pre>
     int datesize = MAX_DATE_SIZE;
     char date[MAX_DATE_SIZE];
     FPClip_GetCreationDate (MyClip, date, &datesize)
     </pre>

     @since 1.0
  */
  EXPORT void DECL FPClip_GetCreationDate (const FPClipRef inClip, 
                                           char *outDate, 
                                           FPInt *ioDateLen);

  /**
     Wide version
     @see FPClip_GetCreationDate()
     @since 2.4
  */
  EXPORT void DECL FPClip_GetCreationDateW (const FPClipRef inClip, 
                                            wchar_t *outDate, 
                                            FPInt *ioDateLen);

  /**
     Uses UTF-8 encoding
     @see FPClip_GetCreationDate()
     @since 2.4
  */
  EXPORT void DECL FPClip_GetCreationDate8 (const FPClipRef inClip, 
                                            char *outDate, 
                                            FPInt *ioDateLen);

  /**
     Uses UTF-16 encoding
     @see FPClip_GetCreationDate()
     @since 2.4
  */
  EXPORT void DECL FPClip_GetCreationDate16 (const FPClipRef inClip, 
                                            FPChar16 *outDate, 
                                            FPInt *ioDateLen);

  /**
     Uses UTF-32 encoding
     @see FPClip_GetCreationDate()
     @since 2.4
  */
  EXPORT void DECL FPClip_GetCreationDate32 (const FPClipRef inClip, 
                                            FPChar32 *outDate, 
                                            FPInt *ioDateLen);


  /**
     Set a retention period during which the C-Clip cannot be deleted.
     The retention period specifies how long a C-Clip
     has to be stored before you are allowed to delete it.
     
     @param inClip a valid clip reference

     @param inRetentionSecs the retention period in seconds, or one of:
     <dl>
      <dt>#FP_NO_RETENTION_PERIOD        <dd>if the clip can always be deleted
      <dt>#FP_INFINITE_RETENTION_PERIOD  <dd>if the clip can never be deleted again
      <dt>#FP_DEFAULT_RETENTION_PERIOD   <dd>if the deletion strategy should
                         depend on the cluster Setting. (default)
     </dl>
     
     @since 1.2
  */
  EXPORT void DECL FPClip_SetRetentionPeriod (const FPClipRef inClip, 
                                              const FPLong inRetentionSecs) ;


  /**
     Retrieves the retention period for a C-Clip.
     The retention period specifies how long a C-Clip
     has to be stored before you are allowed to delete it.

     @param inClip A valid clip reference
    
     @return The retention period previously Set using FPClip_SetRetentionPeriod()
    
     @since 1.2
  */
  EXPORT FPLong DECL FPClip_GetRetentionPeriod (const FPClipRef inClip) ;


  /**
     Retrieves the modification status of a C-Clip that you have
     already opened or created. The function returns true if the
     C-Clip has been modified locally since it was created, opened or
     written, or false if the C-Clip is the same as the C-Clip that is
     written to the pool.

     @note Use this function to determine whether a C-Clip should be
     written to a pool or not. If the function returns false, then
     there is no need to write the C-Clip to the pool.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.
     
     @return true if this C-Clip has been modified

     @since 1.0
  */
  EXPORT FPBool DECL FPClip_IsModified (const FPClipRef inClip);


  /**
     Retrieves the first tag in the C-Clip structure of the given
     C-Clip if the function was not used before. Subsequent function
     calls retrieve the next tags in the tag structure.

     The function retrieves the tags in the same sequence regardless
     of how the C-Clip has been opened; in flat mode or as a tree.

     If the function cannot find any tags, the function returns zero.

     @note You can Get access to a tag structure of a C-Clip only by
     using this function or FPClip_GetTopTag(). Use FPClip_GetTopTag()
     if the C-Clip has been opened as a tree.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @return the reference to the next tag in the C-Clip, or zero if
     an error occurred.

     <b>Example:</b>
     <pre>
     MyClip = FPClip_Open(MyPool, MyClipID, FP_OPEN_FLAT);
     while ((MyTag = FPClip_FetchNext(MyClip)) ! = 0)
     {
        // do something with the tag
        FPTag_Close(MyTag);
     }
     </pre>

     @since 1.0
  */
  EXPORT FPTagRef DECL FPClip_FetchNext (const FPClipRef inClip);


  /**
     Writes a C-Clip to the pool and computes the C-Clip ID from the
     content of the C-Clip. 

     @note The function writes the data in chunks that equal the
     internal memory buffer size. The default value of the internal
     memory buffer is 16 Kbyte. To enlarge this size, use the function
     FPPool_SetIntOption().

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param outClipID The C-Clip ID that the function returns.

     <b>Example:</b>
     <pre>FPClip_Write (MyClip, MyClipID);</pre>

     @since 1.0
  */
  EXPORT void DECL FPClip_Write (const FPClipRef inClip, FPClipID outClipID);

  /**
     Reads the content of the C-Clip into inStream. The application can
     store this content on another device for subsequent restore
     operations of the C-Clip. The application must not change the
     content of the C-Clip.
    
     @param inClip The reference to a C-Clip that the FPClip_Open
     function has returned.

     @param inStream The reference to a stream that has been created by
     an FPStream_CreateXXX function or a generic stream for writing.
     The stream does not have to support marking.
                             
     @since 1.1
  */
  EXPORT void DECL FPClip_RawRead (const FPClipRef inClip, 
                                   const FPStreamRef inStream);
  

  /**
     Reads the content of inStream and creates a new C-Clip.  The new
     C-Clip ID has to match the given C-Clip ID. When the C-Clip has
     been created, the function returns a reference to that
     C-Clip. The function returns NULL if no C-Clip has been built.
    
     @param inPool The reference to a pool that the FPPool_Open
     function has opened.

     @param inClipID The C-Clip that was used to reference the C-Clip
     that has to be read from the stream.

     @param inStream The reference to an input stream. Marking support
     is not necessary.

     @param inOptions Set to 0, currently unused

     @return a reference to an open C-Clip, or NULL in case of error

     @since 1.1
  */
  EXPORT FPClipRef DECL FPClip_RawOpen (const FPPoolRef inPool, 
                                        const FPClipID inClipID, 
                                        const FPStreamRef inStream, 
                                        const FPLong inOptions);

  /**
    Migrates a clip (no blobs) from its pool to the destination pool.
    Use FPTag_Migrate to migrate the blobs.
    
    @param inClipRef A reference to an open clip that will be migrated to the inTargetPool
    @param inTargetPool A pool ref that represents the Cluster to migrate the clip to.

    @since 4.0
   */

  // Don't publicly expose at this time
  //EXPORT void DECL FPClip_Migrate(const FPClipRef inClipRef,
  //                                const FPPoolRef inTargetPool);

  
  /**
     Adds a user settable C-Clip attribute.
     This attribute is recorded in the <custom-meta/> tag of the C-Clip.
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
            FPClip_Create function has returned.
     
     @param inAttrName  The name of the attribute
     @param inAttrValue The value of the attribute.  
                        If NULL, then the name/value pair is deleted.
     
     @since 2.1 
  */
  EXPORT void DECL FPClip_SetDescriptionAttribute (const FPClipRef inClip, 
                                                   const char *inAttrName,
                                                   const char *inAttrValue);

  /**
     Adds a user settable C-Clip attribute.
     This attribute is recorded in the <custom-meta/> tag of the C-Clip.
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
            FPClip_Create function has returned.
     
     @param inAttrName  The name of the attribute
     @param inAttrValue The value of the attribute.
     
     @since 2.1 
  */

  EXPORT void DECL FPClip_SetDescriptionAttributeW (const FPClipRef inClip, 
                                                    const wchar_t *inAttrName,
                                                    const wchar_t *inAttrValue);

  /**
     Uses UTF-8 encoding
     @see FPClip_SetDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_SetDescriptionAttribute8 (const FPClipRef inClip, 
                                                    const char *inAttrName,
                                                    const char *inAttrValue);

  /**
     Uses UTF-16 encoding
     @see FPClip_SetDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_SetDescriptionAttribute16 (const FPClipRef inClip, 
                                                     const FPChar16 *inAttrName,
                                                     const FPChar16 *inAttrValue);

  /**
     Uses UTF-32 encoding
     @see FPClip_SetDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_SetDescriptionAttribute32 (const FPClipRef inClip, 
                                                     const FPChar32 *inAttrName,
                                                     const FPChar32 *inAttrValue);

  /**
     Removes a user settable attribute from the C-Clip
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
            FPClip_Create function has returned.
     
     @param inAttrName  The name of the attribute
     
     @since 2.1 
  */
  EXPORT void DECL FPClip_RemoveDescriptionAttribute (const FPClipRef inClip,
                                                      const char *inAttrName);

  /**
     Removes a user settable attribute from the C-Clip
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
            FPClip_Create function has returned.
     
     @param inAttrName  The name of the attribute
     
     @since 2.1 
  */

  EXPORT void DECL FPClip_RemoveDescriptionAttributeW (const FPClipRef inClip, 
                                                       const wchar_t *inAttrName);

  /**
     Uses UTF-8 encoding
     @see FPClip_RemoveDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_RemoveDescriptionAttribute8 (const FPClipRef inClip, 
                                                       const char *inAttrName);

  /**
     Uses UTF-16 encoding
     @see FPClip_RemoveDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_RemoveDescriptionAttribute16 (const FPClipRef inClip, 
                                                        const FPChar16 *inAttrName);

  /**
     Uses UTF-32 encoding
     @see FPClip_RemoveDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_RemoveDescriptionAttribute32 (const FPClipRef inClip, 
                                                        const FPChar32 *inAttrName);

  /**
     Gets a user settable C-Clip attribute.
     This attribute is recorded in the <custom-meta/> tag of the C-Clip.
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
            FPClip_Create function has returned.
     
     @param inAttrName   The name of the attribute
     @param outAttrValue A pointer to a buffer to receive the attribute value.
     @param ioAttrValueLen    On input, this parameter must specify the
         size of the buffer in characters.  At most (*ioAttrValueLen - 1)
         characters will be written to the buffer, plus a terminating null
         character.  On output, this parameter contains the actual number of
         characters in the attribute string, including the terminating null
         character.
     
     @since 2.1 
  */

  EXPORT void DECL FPClip_GetDescriptionAttribute (const FPClipRef inClip, 
                                                   const char* inAttrName,
                                                   char* outAttrValue, 
                                                   FPInt* ioAttrValueLen) ;

  /**
     Gets a user settable C-Clip attribute.
     This attribute is recorded in the <custom-meta/> tag of the C-Clip.
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
            FPClip_Create function has returned.
     
     @param inAttrName   The name of the attribute
     @param outAttrValue   A pointer to a buffer to receive the attribute value.
     @param ioAttrValueLen On input, this parameter must specify the
         size of the buffer in wide characters.  At most (*ioAttrValueLen - 1)
         characters will be written to the buffer, plus a terminating null
         character.  On output, this parameter contains the actual number of
         characters in the attribute string, including the terminating null
         character.
     
     @since 2.1 
  */

  EXPORT void DECL FPClip_GetDescriptionAttributeW (const FPClipRef inClip, 
                                                    const wchar_t* inAttrName,
                                                    wchar_t* outAttrValue, 
                                                    FPInt* ioAttrValueLen);

  /**
     Uses UTF-8 encoding
     @see FPClip_GetDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_GetDescriptionAttribute8 (const FPClipRef inClip, 
                                                    const char* inAttrName,
                                                    char* outAttrValue, 
                                                    FPInt* ioAttrValueLen);

  /**
     Uses UTF-16 encoding
     @see FPClip_GetDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_GetDescriptionAttribute16 (const FPClipRef inClip, 
                                                     const FPChar16* inAttrName,
                                                     FPChar16* outAttrValue, 
                                                     FPInt* ioAttrValueLen);

  /**
     Uses UTF-32 encoding
     @see FPClip_GetDescriptionAttribute() 
   */
  EXPORT void DECL FPClip_GetDescriptionAttribute32 (const FPClipRef inClip, 
                                                     const FPChar32* inAttrName,
                                                     FPChar32* outAttrValue, 
                                                     FPInt* ioAttrValueLen);
  
  
  /**
     Returns the name and value of an attribute according to its index in the 
     custom-meta tag.
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
                   FPClip_Create function has returned.
     
     @param inIndex  The index number (zero based) of the attribute that
                    has to be retrieved.
     @param outAttrName  A pointer to a buffer to receive the attribute name
     @param ioAttrNameLen On input, this parameter must specify the
         size of the buffer in characters (not bytes).  At most
         (*ioAttrNameLen - 1) characters (not bytes) will be written to the
         buffer, plus a terminating null character.  On output, this
         parameter contains the actual number of characters in the
         attribute name, including the terminating null character.
     
     @param outAttrValue A pointer to a buffer to receive the attribute value.
     @param ioAttrValueLen    On input, this parameter must specify the
         size of the buffer in wide characters.  At most (*ioAttrValueLen - 1)
         characters will be written to the buffer, plus a terminating null
         character.  On output, this parameter contains the actual number of
         characters in the attribute string, including the terminating null
         character.
     
     @since 2.1 
  */

  EXPORT void DECL FPClip_GetDescriptionAttributeIndex(const FPClipRef inClip, 
                                                       const FPInt inIndex,
                                                       char* outAttrName, 
                                                       FPInt* ioAttrNameLen,
                                                       char* outAttrValue, 
                                                       FPInt* ioAttrValueLen);

  /**
     Returns the name and value of an attribute according to its index in the 
     custom-meta tag.
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
                   FPClip_Create function has returned.
     
     @param inIndex  The index number (zero based) of the attribute that
                    has to be retrieved.
     @param outAttrName  A pointer to a buffer to receive the attribute name
     @param ioAttrNameLen On input, this parameter must specify the
             size of the buffer in characters (not bytes).  At most
             (*ioAttrNameLen - 1) characters (not bytes) will be written to the
             buffer, plus a terminating null character.  On output, this
             parameter contains the actual number of characters in the
             attribute name, including the terminating null character.
     
     @param outAttrValue A pointer to a buffer to receive the attribute value.
     @param ioAttrValueLen    On input, this parameter must specify the
             size of the buffer in wide characters.  At most (*ioAttrValueLen - 1)
             characters will be written to the buffer, plus a terminating null
             character.  On output, this parameter contains the actual number of
             characters in the attribute string, including the terminating null
             character.
     
     @since 2.1 
  */

  EXPORT void DECL FPClip_GetDescriptionAttributeIndexW(const FPClipRef inClip, 
                                                        const FPInt inIndex,
                                                        wchar_t* outAttrName, 
                                                        FPInt* ioAttrNameLen,
                                                        wchar_t* outAttrValue, 
                                                        FPInt* ioAttrValueLen);

  /**
     Uses UTF-8 encoding
     @see FPClip_GetDescriptionAttributeIndex() 
   */
  EXPORT void DECL FPClip_GetDescriptionAttributeIndex8(const FPClipRef inClip, 
                                                        const FPInt inIndex,
                                                        char* outAttrName, 
                                                        FPInt* ioAttrNameLen,
                                                        char* outAttrValue, 
                                                        FPInt* ioAttrValueLen);

  /**
     Uses UTF-16 encoding
     @see FPClip_GetDescriptionAttributeIndex() 
   */
  EXPORT void DECL FPClip_GetDescriptionAttributeIndex16(const FPClipRef inClip, 
                                                         const FPInt inIndex,
                                                         FPChar16* outAttrName, 
                                                         FPInt* ioAttrNameLen,
                                                         FPChar16* outAttrValue, 
                                                         FPInt* ioAttrValueLen);

  /**
     Uses UTF-32 encoding
     @see FPClip_GetDescriptionAttributeIndex() 
   */
  EXPORT void DECL FPClip_GetDescriptionAttributeIndex32(const FPClipRef inClip, 
                                                         const FPInt inIndex,
                                                         FPChar32* outAttrName, 
                                                         FPInt* ioAttrNameLen,
                                                         FPChar32* outAttrValue, 
                                                         FPInt* ioAttrValueLen);


  /**
     Returns the number of Description attributes in the C-Clip.  Both standard 
     as user attributes are counted.
     
     @param inClip The reference to a C-Clip that the FPClip_Open or 
                   FPClip_Create function has returned.
     
     @return the number of description attributes in the C-Clip.
     
     @since 2.1 
  */

  EXPORT FPInt DECL FPClip_GetNumDescriptionAttributes (const FPClipRef inClip);

  /**
     Get the current wait state for a clip. 

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @return The call returns true if EBR has been enabled on the clip, 
     or false otherwise.

     <b>Example:</b>
     <pre>bWaiting = FPClip_IsEBREnabled (MyClip);</pre>

     @since 3.1
  */
  EXPORT FPBool DECL FPClip_IsEBREnabled (const FPClipRef inClip);

  /**
     This function retrieves the time the EBR event was triggered.
    
     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param outEBREventTime Pointer to a memory buffer to receive the 
     EBR event time in "YYYY.MM.DD hh:mm:ss GMT" format

     @param ioEBREventTimeLen On input the length of the outEBREventTime
     buffer.  On output the actual length of the string

     @return The call returns the time the EBR event occurred, or 0 if it
     has not occurred.

     @since 3.1
  */
  EXPORT void DECL FPClip_GetEBREventTime (const FPClipRef inClip, 
                                           char* outEBREventTime, 
                                           FPInt* ioEBREventTimeLen);

  /**
     @see FPClip_GetEBREventTime()
     @since 3.1
   */
  EXPORT void DECL FPClip_GetEBREventTimeW (const FPClipRef inClip, 
                                            wchar_t* outEBREventTime, 
                                            FPInt* ioEBREventTimeLen);

  /**
     Uses UTF-8 encoding
     @see FPClip_GetEBREventTime() 
    @since 3.1
   */
  EXPORT void DECL FPClip_GetEBREventTime8 (const FPClipRef inClip, 
                                            char* outEBREventTime, 
                                            FPInt* ioEBREventTimeLen);

  /**
     Uses UTF-16 encoding
     @see FPClip_GetEBREventTime() 
     @since 3.1
   */
  EXPORT void DECL FPClip_GetEBREventTime16 (const FPClipRef inClip, 
                                             FPChar16* outEBREventTime, 
                                             FPInt* ioEBREventTimeLen);

  /**
     Uses UTF-32 encoding
     @see FPClip_GetEBREventTime() 
     @since 3.1
   */
  EXPORT void DECL FPClip_GetEBREventTime32 (const FPClipRef inClip, 
                                             FPChar32* outEBREventTime, 
                                             FPInt* ioEBREventTimeLen);


  /**
     Get the waiting period of a clip which is configured to wait for an
     event.

     @note The function attempts to return the EBR period assigned to the 
     clip.  The value returned, when used with the value returned from 
     FPClip_GetEBREventTime, can be used to determine how much longer the 
     clip is under retention for.  This value will default to 0 if it has
     not been set.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @return The call returns the explicit retention period as set on the 
     clip.

     <b>Example:</b>
     <pre>vWaitingTime = FPClip_GetEBRPeriod (MyClip);</pre>

     @since 3.1
  */
  EXPORT FPLong DECL FPClip_GetEBRPeriod (const FPClipRef inClip);

  /**
    Get the waiting period of a clip which is configured to wait for an
    event.

    @param inClipRef The reference to the clip where the EBR class is 
                     retrieved from.

    @param ioClassName The buffer where the name of the retention class
                       that is associated with the passed in clip ref is
                       stored. If the name is larger than what can fit in this
                       buffer, it is truncated. The caller should check the
                       value of the ioNameLen param on completion of this call
                       to verify whether or not the buffer contains the full 
                       name. If not the caller should resize their buffer and
                       make this call again.
                        
                       If the passed ref does not have a retention class assigned to it, 
                       then this call will populate this buffer only with a NULL 
                       terminating character. 

    @param ioNameLen On input, this param should represent the size of the
                     outClassName buffer.
                     On output, this param is populated with the actual length 
                     of the retention class name including the NULL terminator.

    @since 3.1
   */
  EXPORT void DECL FPClip_GetEBRClassName(const FPClipRef inClipRef, 
                                                char* ioClassName, 
                                                FPInt* ioNameLen);

  /**
    @see FPClip_GetEBRClassName()
    @since 3.1
   */
  EXPORT void DECL FPClip_GetEBRClassNameW(const FPClipRef inClipRef, 
                                                 wchar_t* ioClassName, 
                                                 FPInt* ioNameLen);

  /**
     Uses UTF-8 encoding
     @see FPClip_GetEBRClassName() 
    @since 3.1
   */
  EXPORT void DECL FPClip_GetEBRClassName8(const FPClipRef inClipRef, 
                                                 char* ioClassName, 
                                                 FPInt* ioNameLen);

  /**
     Uses UTF-16 encoding
     @see FPClip_GetEBRClassName() 
     @since 3.1
   */
  EXPORT void DECL FPClip_GetEBRClassName16(const FPClipRef inClipRef, 
                                                  FPChar16* ioClassName, 
                                                  FPInt* ioNameLen);

  /**
     Uses UTF-32 encoding
     @see FPClip_GetEBRClassName() 
     @since 3.1
   */
  EXPORT void DECL FPClip_GetEBRClassName32(const FPClipRef inClipRef, 
                                                  FPChar32* ioClassName, 
                                                  FPInt* ioNameLen);

  /**
     Enable the EBR waiting period of a clip configured to wait for an
     event.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param inSeconds A value used to explicitly set the wait period
     The time is measured from the time this event is received.

     <b>Example:</b>
     <pre>FPClip_EnableEBRWithPeriod (MyClip, 300);</pre>

     @since 3.1
  */
  EXPORT void DECL FPClip_EnableEBRWithPeriod (const FPClipRef inClip, 
                                                     FPLong inSeconds);

  /**
     Enable the EBR retention class of a clip configured to wait for an
     event.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param inClass A reference to a retention class, used to
     indirectly set the wait period.  The time is measured from the 
     time this event is received.

     <b>Example:</b>
     <pre>FPRetentionClassContextRef vContextRef;</pre>
     <pre>FPRetentionClassRef vClassRef;</pre>
     <pre>vContextRef = FPPool_GetRetentionClassContext(inPool);</pre>
     <pre>vClassRef = FPRetentionClassContext_GetFirstClass(vContextRef);</pre>
     <pre>FPClip_EnableEBRWithClass (MyClip, vClassRef);</pre>

     @since 3.1
  */
  EXPORT void DECL FPClip_EnableEBRWithClass (
      const FPClipRef inClip, 
      const FPRetentionClassRef inClass);

  /**
     Trigger the EBR event that the clip is waiting for.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     <b>Example:</b>
     <pre>FPClip_TriggerEBREvent (MyClip);</pre>

     @since 3.1
  */
  EXPORT void DECL FPClip_TriggerEBREvent (const FPClipRef inClip);

  /**
     Trigger the EBR event that the clip is waiting for with a period.

     @note The input period will only be assigned to the clip if it is
     greater than the current retention period of the clip.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param inSeconds A value used to explicitly set the wait period
     The time is measured from the time this event is received.

     <b>Example:</b>
     <pre>FPClip_TriggerEBREventWithPeriod (MyClip, 300);</pre>

     @since 3.1
  */
  EXPORT void DECL FPClip_TriggerEBREventWithPeriod (const FPClipRef inClip, 
                                                           FPLong inSeconds);

  /**
     Trigger the EBR event that the clip is waiting for with a retention class.

     @note The input class will only be assigned to the clip if it specifies
     a greater period than the current class of the clip specifies.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param inClass A reference to a retention class, used to
     indirectly set the wait period.  The time is measured from the 
     time this event is received.

     <b>Example:</b>
     <pre>FPRetentionClassContextRef vContextRef;</pre>
     <pre>FPRetentionClassRef vClassRef;</pre>
     <pre>vContextRef = FPPool_GetRetentionClassContext(inPool);</pre>
     <pre>vClassRef = FPRetentionClassContext_GetLastClass(vContextRef);</pre>
     <pre>FPClip_TriggerEBREventWithClass (MyClip, vClassRef);</pre>

     @since 3.1
  */
  EXPORT void DECL FPClip_TriggerEBREventWithClass (
      const FPClipRef inClip, 
      const FPRetentionClassRef inClass);

  /**
     Get whether or not the clip is under retention hold. 

     @note The function checks to see if the clip is under any named
     retention holds.  If yes, then true is returned, otherwise false is 
     returned.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @return The call returns true if the clip is being held.

     <b>Example:</b>
     <pre>vOnRetentionHold = FPClip_GetRetentionHold (MyClip);</pre>

     @since 3.1
  */
  EXPORT FPBool DECL FPClip_GetRetentionHold (const FPClipRef inClip);

  /**
     Set or unset a retention hold on the C-Clip. 

     @note The function sets or unsets the named retention hold 
     if the inHoldFlag argument is true, or it removes the retention
     hold from the metadata if the flag is false.

     @param inClip The reference to a C-Clip that the FPClip_Open() or
     FPClip_Create() function has opened.

     @param inHoldFlag FPBool value used to set/unset the hold state.  A
     value of true will set the hold, a value of false will unset the hold.
     If a clip has a hold state enabled, it may not be deleted.

     @param inHoldID The HoldID is the user defined name of the hold.  This 
     allows multiple holds to be assigned concurrently to a single clip.

     <b>Example:  to turn a hold on</b>
     <pre>FPClip_SetRetentionHold (MyClip, true, "eventcancel");</pre>

     <b>Example:  to turn a hold off</b>
     <pre>FPClip_SetRetentionHold (MyClip, false, "eventcancel");</pre>

     @since 3.1
  */
  EXPORT void DECL FPClip_SetRetentionHold (const FPClipRef inClip,
                                            const FPBool inHoldFlag,
                                            const char* inHoldID);

  /**
     Same as FPClip_SetRetentionHold(), but with a wide-character
     string for the name of the option.

     @since 1.1
  */
  EXPORT void DECL FPClip_SetRetentionHoldW (const FPClipRef inClip,
                                             const FPBool inHoldFlag,
                                             const wchar_t* inHoldID);

  /**
     Uses UTF-8 encoding
     @see FPClip_SetRetentionHold() 
   */
  EXPORT void DECL FPClip_SetRetentionHold8 (const FPClipRef inClip,
                                             const FPBool inHoldFlag,
                                             const char* inHoldID);

  /**
     Uses UTF-16 encoding
     @see FPClip_SetRetentionHold() 
   */
  EXPORT void DECL FPClip_SetRetentionHold16 (const FPClipRef inClip,
                                              const FPBool inHoldFlag,
                                              const FPChar16* inHoldID);
  
  /**
     Uses UTF-32 encoding
     @see FPClip_SetRetentionHold() 
   */
  EXPORT void DECL FPClip_SetRetentionHold32 (const FPClipRef inClip,
                                              const FPBool inHoldFlag,
                                              const FPChar32* inHoldID);

  /** @} */ /* clip functions */

#ifdef __MWERKS__
#pragma mark Tag functions
#endif

  /**
     @defgroup Tag Tag functions
     @{

     The tag functions operate at the level of a C-Clip tag.  They
     allow you to manipulate tags, to navigate through the C-Clip tag
     structure, to manipulate tag attributes, and to manipulate blobs.

     Before you can perform a tag operation, you must first create the
     tag or Get a reference to it using FPClip_GetTopTag().  Do not
     forget to close the tag afterwards.

     There are two ways to navigate through the tag structure of a
     C-Clip.
     
     - Hierarchically: you open the C-Clip as a tree structure (see
     FPClip_Open()). The C-Clip will open in read/write mode.  You
     then use FPTag_GetFirstChild() and FPTag_GetSibling() to navigate
     through the tree.

     - Sequentially: you open the C-Clip as a flat structure (see
     FPClip_Open()). The C-Clip will open in read-only mode. This
     option avoids the use of large memory buffers and is very useful
     for reading C-Clips that do not fit in memory.  You then
     use FPClip_FetchNext() to navigate through the flat structure.

     Each tag has a Set of attributes, which are essentially
     name-value pairs.  You can Get and Set the attributes using the
     appropriate functions.  Each function that Sets an attribute will
     overwrite the existing value, if any, or add a new attribute to
     the tag.  You can use FPTag_RemoveAttribute() and
     FPTag_RemoveAttributeW() to delete attributes.

  */


  /**
     Creates a new tag within a C-Clip that has been opened in tree
     mode (see FPClip_Open()), and returns a reference to the new tag.

     @note You will always need a reference to a parent tag to create
     a new tag.

     @param inParent The reference to the parent tag of the new tag
     that you are creating.

     @param inName the buffer that holds the name of the new tag. The
     value cannot be NULL.  The characters accepted by this function
     are ASCII characters in the Set [a-zA-Z0-9_-. ]. The first
     character must be a letter or an underscore "_".  Furthermore,
     the tag name must not start with "xml" or "eclip"; those prefixes
     are reserved.  If your application requires other characters, use
     FPTag_CreateW().

     @since 1.0
  */
  EXPORT FPTagRef DECL FPTag_Create (const FPTagRef inParent, const char *inName);


  /**
     Like FPTag_Create(), but with wide characters.  This function
     accepts <a href="http://www.w3.org/TR/REC-xml#NT-Name">all
     Unicode characters specified by the XML 1.0 standard</a>.

     @since 1.1
  */
  EXPORT FPTagRef DECL FPTag_CreateW(const FPTagRef inParent, 
                                     const wchar_t *inName);

  /**
     Uses UTF-8 encoding
     @see FPTag_Create() 
   */
  EXPORT FPTagRef DECL FPTag_Create8(const FPTagRef inParent, const char *inName);

  /**
     Uses UTF-16 encoding
     @see FPTag_Create() 
   */
  EXPORT FPTagRef DECL FPTag_Create16(const FPTagRef inParent, 
                                      const FPChar16 *inName);

  /**
     Uses UTF-32 encoding
     @see FPTag_Create() Uses UTF-32 encoding
   */
  EXPORT FPTagRef DECL FPTag_Create32(const FPTagRef inParent, 
                                      const FPChar32 *inName);



  /**
     Closes the given tag. It also closes all structures and frees up
     all memory allocated to that tag without deleting the tag from
     the C-Clip. Be aware that using this function on a tag that has
     already been closed, may produce unwanted results.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @since 1.0
  */
  EXPORT void DECL FPTag_Close (const FPTagRef inTag);

  /**
    Returns a copy of the tag and inserts it under a new parent.  This parent
    can belong to the same or a different C-Clip, but must belong to the same 
    cluster.
    
    @param inTag The tag to make a copy from
    @param inNewParent The new parent tag for the copy. 
    @param inOptions one or more of these options
        <dl>
         <dt>#FP_OPTION_NO_COPY_OPTIONS     <dd>Only copy the tag and its attributes
         <dt>#FP_OPTION_COPY_BLOBDATA       <dd>Also copy the blobdata (if any)
         <dt>#FP_OPTION_COPY_CHILDREN       <dd>Also copy the children below this tag
        </dl>

    @since 1.2
  */
  EXPORT FPTagRef DECL FPTag_Copy (const FPTagRef inTag, 
                                   const FPTagRef inNewParent, 
                                   const FPInt inOptions);

  /**
    Migrates all the eclipblob tags of the passed in tag ref.from their pool to the 
	destination pool.
    Use FPClip_Migrate to migrate the clip.
    
    @param inTagRef A reference to tag that will be migrated to the inTargetPool
    @param inTargetPool A pool ref that represents the Cluster to migrate the tag blob to.

    @since 4.0
   */
  // Don't publicly expose at this time
  //EXPORT void DECL FPTag_Migrate(const FPTagRef inTagRef,
  //                               const FPPoolRef inTargetPool);

  /**
    Returns the reference to the clip that this tag belongs to.
    @param inTag a valid FPTag reference
    @return a reference to the C-Clip

    @since 1.2
  */
  
  EXPORT FPClipRef DECL FPTag_GetClipRef (const FPTagRef inTag) ;
  
  /**
    Returns the reference to the pool for the clip that this tag belongs to.
    @param inTag a valid FPTag reference
    @return a reference to the FPPool object

    @since 1.2
  */

  #define FPTag_GetPoolRef(inTag)  FPClip_GetPoolRef(FPTag_GetClipRef(inTag))
  
  /**
     Retrieves the sibling tag of the given tag.  The C-Clip must have
     been opened in tree mode (see FPClip_Open()).  A sibling tag is
     at the same level as the given tag in the tag hierarchy of the
     C-Clip.

     @return The sibling tag, or zero if none exists or an error
     occurs.

     @since 1.0
   */
  EXPORT FPTagRef DECL FPTag_GetSibling (const FPTagRef inTag);

  /**
     Retrieves the previous sibling tag of the given tag.  The C-Clip must have
     been opened in tree mode (see FPClip_Open()).  A previous sibling tag is
     at the same level as the given tag in the tag hierarchy of the
     C-Clip (but in opposite direction as what FPTag_GetSibling returns)

     @return The previous sibling tag, or zero if none exists or an error
     occurs.

     @since 1.0
   */
  EXPORT FPTagRef DECL FPTag_GetPrevSibling (const FPTagRef inTag);

  /**
     Retrieves the first child tag of the given tag. The C-Clip must
     have been opened in tree mode (see FPClip_Open()). A child tag is
     the tag that is one level down in the tag hierarchy from the
     given tag.

     @return A reference to the first child of the specified tag, or
     zero if no such tag exists or an error occurs.  You can traverse
     the other child tags of inTag using FPTag_GetSibling() on the
     returned tag reference.

     @since 1.0
  */
  EXPORT FPTagRef DECL FPTag_GetFirstChild (const FPTagRef inTag);


  /**
     Retrieves the parent tag of the given tag. The C-Clip must have
     been opened in tree mode (see FPClip_Open()). A parent tag is one
     level up in the tag hierarchy from the given tag.

     @return The parent tag, or zero if none exists or an error occurs.

     @since 1.0
  */
  EXPORT FPTagRef DECL FPTag_GetParent (const FPTagRef inTag);


  /**
     Deletes a tag (and all children of the tag) in the tag structure
     of a C-Clip. If the tag refers to data (a blob tag), it will not
     delete that data.

     @note After a successful deletion, the system deallocates the
     memory for the tag and inTag becomes invalid. Any function call to
     the tag (for example, with the FPTag_Close() function) will result
     in an #FP_WRONG_REFERENCE_ERR error.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @since 1.0
  */
  EXPORT void DECL FPTag_Delete (const FPTagRef inTag);


  /**
     Retrieves the name of the given tag in the opened C-Clip.  This
     function is thread safe.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().
     
     @param outName A pointer to the buffer that will store the name of
     the tag.

     @param ioNameLen On input, this parameter must specify the size of
     the buffer in characters.  At most (*ioNameLen - 1) characters
     will be written to the buffer, plus a terminating null character.
     On output, this parameter contains the actual number of characters
     in the name, including the terminating null character.

     @since 1.0
  */
  EXPORT void DECL FPTag_GetTagName (const FPTagRef inTag, 
                                     char *outName, 
                                     FPInt *ioNameLen);


  /**
     Retrieves the name of the given tag in the opened C-Clip.
     

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().
     
     @param outName A pointer to the buffer that will store the name of
     the tag.

     @param ioNameLen On input, this parameter must specify the size of
     the buffer in characters (not bytes).  At most (*ioNameLen - 1)
     characters (not bytes) will be written to the buffer, plus a
     terminating null character.  On output, this parameter contains
     the actual number of characters in the name, including the
     terminating null character.

     @since 1.1
  */
  EXPORT void DECL FPTag_GetTagNameW(const FPTagRef inTag, 
                                     wchar_t *outName, 
                                     FPInt *ioNameLen);

  /**
     Uses UTF-8 encoding
     @see FPTag_GetTagName() 
   */
  EXPORT void DECL FPTag_GetTagName8(const FPTagRef inTag, 
                                     char *outName, 
                                     FPInt *ioNameLen);

  /**
     Uses UTF-16 encoding
     @see FPTag_GetTagName() 
   */
  EXPORT void DECL FPTag_GetTagName16(const FPTagRef inTag, 
                                      FPChar16 *outName, 
                                      FPInt *ioNameLen);

  /**
     Uses UTF-32 encoding
     @see FPTag_GetTagName() 
   */
  EXPORT void DECL FPTag_GetTagName32(const FPTagRef inTag, 
                                      FPChar32 *outName, 
                                      FPInt *ioNameLen);


  /**
     Sets a string attribute of the given tag in an opened C-Clip. The
     C-Clip must have been opened in tree mode (see FPClip_Open()).

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inAttrName The name of the attribute.  Valid characters for
     attribute names are [A-Za-z0-9_-].  The name must begin with a
     letter or an underscore, and must not start with "xml" or
     "eclip", which are reserved prefixes.

     @param inAttrValue The value of the attribute.
    
     @since 1.0
  */
  EXPORT void DECL FPTag_SetStringAttribute (const FPTagRef inTag, 
                                             const char *inAttrName, 
                                             const char *inAttrValue);


  /**
     Like FPTag_SetStringAttribute(), but with wide characters.  For
     the attribute name, this function accepts <a
     href="http://www.w3.org/TR/REC-xml#NT-Name">all Unicode
     characters specified by the XML 1.0 standard</a>.

     @since 1.1
  */
  EXPORT void DECL FPTag_SetStringAttributeW(const FPTagRef inTag, 
                                             const wchar_t *inAttrName, 
                                             const wchar_t *inAttrValue);

  /**
     Uses UTF-8 encoding
     @see FPTag_SetStringAttribute() 
   */
  EXPORT void DECL FPTag_SetStringAttribute8(const FPTagRef inTag, 
                                             const char *inAttrName, 
                                             const char *inAttrValue);

  /**
     Uses UTF-16 encoding
     @see FPTag_SetStringAttribute() 
   */
  EXPORT void DECL FPTag_SetStringAttribute16(const FPTagRef inTag, 
                                              const FPChar16 *inAttrName, 
                                              const FPChar16 *inAttrValue);

  /**
     Uses UTF-32 encoding
     @see FPTag_SetStringAttribute() 
   */
  EXPORT void DECL FPTag_SetStringAttribute32(const FPTagRef inTag, 
                                              const FPChar32 *inAttrName, 
                                              const FPChar32 *inAttrValue);


  /**
     Like FPTag_SetStringAttribute(), but for large integer values.
     @since 1.0
   */
  EXPORT void DECL FPTag_SetLongAttribute (const FPTagRef inTag, 
                                           const char *inAttrName, 
                                           const FPLong inAttrValue);


  /**
     Like FPTag_SetStringAttributeW(), but for large integer values.
     @since 1.1
   */
  EXPORT void DECL FPTag_SetLongAttributeW(const FPTagRef inTag, 
                                           const wchar_t *inAttrName, 
                                           const FPLong inAttrValue);

  /**
     Uses UTF-8 encoding
     @see FPTag_SetLongAttribute(), 
   */
  EXPORT void DECL FPTag_SetLongAttribute8(const FPTagRef inTag, 
                                           const char *inAttrName, 
                                           const FPLong inAttrValue);

  /**
     Uses UTF-16 encoding
     @see FPTag_SetLongAttribute() 
   */
  EXPORT void DECL FPTag_SetLongAttribute16(const FPTagRef inTag, 
                                            const FPChar16 *inAttrName,
                                            const FPLong inAttrValue);

  /**
     Uses UTF-32 encoding
     @see FPTag_SetLongAttribute() 
   */
  EXPORT void DECL FPTag_SetLongAttribute32(const FPTagRef inTag, 
                                            const FPChar32 *inAttrName, 
                                            const FPLong inAttrValue);

  /**
     Like FPTag_SetStringAttribute(), but for boolean values.
     @since 1.0
  */
  EXPORT void DECL FPTag_SetBoolAttribute (const FPTagRef inTag, 
                                           const char *inAttrName, 
                                           const FPBool inAttrValue);


  /**
     Like FPTag_SetStringAttributeW(), but for boolean values.
     @since 1.0
  */
  EXPORT void DECL FPTag_SetBoolAttributeW(const FPTagRef inTag, 
                                           const wchar_t *inAttrName, 
                                           const FPBool inAttrValue);

  /**
     Uses UTF-8 encoding
     @see FPTag_SetBoolAttribute() 
   */
  EXPORT void DECL FPTag_SetBoolAttribute8(const FPTagRef inTag, 
                                           const char *inAttrName, 
                                           const FPBool inAttrValue);

  /**
     Uses UTF-16 encoding
     @see FPTag_SetBoolAttribute() 
   */
  EXPORT void DECL FPTag_SetBoolAttribute16(const FPTagRef inTag, 
                                            const FPChar16 *inAttrName, 
                                            const FPBool inAttrValue);

  /**
     Uses UTF-32 encoding
     @see FPTag_SetBoolAttribute() 
   */
  EXPORT void DECL FPTag_SetBoolAttribute32(const FPTagRef inTag, 
                                            const FPChar32 *inAttrName, 
                                            const FPBool inAttrValue);


  /**
     Retrieves the value of the specified attribute from a tag.
     

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inAttrName The name of the attribute.  Valid characters for
     attribute names are [A-Za-z0-9_-].  The name must begin with a
     letter or an underscore, and must not start with "xml" or
     "eclip", which are reserved prefixes.

     @param outAttrValue A pointer to a buffer that will receive the
     value of the attribute.

     @param ioAttrValueLen On input, this parameter must specify the
     size of the buffer in characters.  At most (*ioAttrValueLen - 1)
     characters will be written to the buffer, plus a terminating null
     character.  On output, this parameter contains the actual number of
     characters in the value string, including the terminating null
     character.

     @since 1.0
  */
  EXPORT void DECL FPTag_GetStringAttribute (const FPTagRef inTag, 
                                             const char *inAttrName, 
                                             char *outAttrValue, 
                                             FPInt *ioAttrValueLen);


  /**
     Like FPTag_GetStringAttribute(), but with wide-character strings
     for both the attribute name and value.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inAttrName The name of the attribute.  Valid characters for
     attribute names are [A-Za-z0-9_-].  The name must begin with a
     letter or an underscore, and must not start with "xml" or
     "eclip", which are reserved prefixes.

     @param outAttrValue A pointer to a buffer that will receive the
     value of the attribute.

     @param ioAttrValueLen On input, this parameter must specify the
     size of the buffer in characters (not bytes).  At most
     (*ioAttrValueLen - 1) characters (not bytes) will be written to the
     buffer, plus a terminating null character.  On output, this
     parameter contains the actual number of characters in the value
     string, including the terminating null character.

     @since 1.1
  */
  EXPORT void DECL FPTag_GetStringAttributeW(const FPTagRef inTag, 
                                             const wchar_t *inAttrName, 
                                             wchar_t *outAttrValue, 
                                             FPInt *ioAttrValueLen);

  /**
     Uses UTF-8 encoding
     @see FPTag_GetStringAttribute() 
   */
  EXPORT void DECL FPTag_GetStringAttribute8(const FPTagRef inTag, 
                                             const char *inAttrName, 
                                             char *outAttrValue, 
                                             FPInt *ioAttrValueLen);

  /**
     Uses UTF-16 encoding
     @see FPTag_GetStringAttribute() 
   */
  EXPORT void DECL FPTag_GetStringAttribute16(const FPTagRef inTag, 
                                              const FPChar16 *inAttrName, 
                                              FPChar16 *outAttrValue, 
                                              FPInt *ioAttrValueLen);

  /**
     Uses UTF-32 encoding
     @see FPTag_GetStringAttribute() 
   */
  EXPORT void DECL FPTag_GetStringAttribute32(const FPTagRef inTag, 
                                              const FPChar32 *inAttrName, 
                                              FPChar32 *outAttrValue, 
                                              FPInt *ioAttrValueLen);


  /**
     Like FPTag_GetStringAttribute(), but for large integers.
     @since 1.0
  */
  EXPORT FPLong DECL FPTag_GetLongAttribute (const FPTagRef inTag, 
                                             const char *inAttrName);


  /**
     Like FPTag_GetStringAttributeW(), but for large integers.
     @since 1.1
  */
  EXPORT FPLong DECL FPTag_GetLongAttributeW(const FPTagRef inTag, 
                                             const wchar_t *inAttrName);

  /**
     Uses UTF-8 encoding
     @see FPTag_GetLongAttribute()
   */
  EXPORT FPLong DECL FPTag_GetLongAttribute8(const FPTagRef inTag, 
                                             const char *inAttrName);

  /**
     Uses UTF-16 encoding
     @see FPTag_GetLongAttribute() 
   */
  EXPORT FPLong DECL FPTag_GetLongAttribute16(const FPTagRef inTag, 
                                              const FPChar16 *inAttrName);

  /**
     Uses UTF-32 encoding
     @see FPTag_GetLongAttribute() 
   */
  EXPORT FPLong DECL FPTag_GetLongAttribute32(const FPTagRef inTag, 
                                              const FPChar32 *inAttrName);
  

  /**
     For boolean values.
     @see FPTag_GetStringAttribute() 
     @since 1.0
  */
  EXPORT FPBool DECL FPTag_GetBoolAttribute (const FPTagRef inTag, 
                                             const char *inAttrName);


  /**
     For boolean values.
     @see FPTag_GetStringAttributeW() 
     @since 1.1
  */
  EXPORT FPBool DECL FPTag_GetBoolAttributeW(const FPTagRef inTag, 
                                             const wchar_t *inAttrName);

  /**
     Uses UTF-8 encoding
     @see FPTag_GetBoolAttribute() 
   */
  EXPORT FPBool DECL FPTag_GetBoolAttribute8(const FPTagRef inTag, 
                                             const char *inAttrName);

  /**
     Uses UTF-16 encoding
     @see FPTag_GetBoolAttribute() 
   */
  EXPORT FPBool DECL FPTag_GetBoolAttribute16(const FPTagRef inTag, 
                                              const FPChar16 *inAttrName);

  /**
     Uses UTF-32 encoding
     @see FPTag_GetBoolAttribute() 
   */
  EXPORT FPBool DECL FPTag_GetBoolAttribute32(const FPTagRef inTag, 
                                              const FPChar32 *inAttrName);


  /**
     Removes the specified attribute from a tag.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inAttrName The name of the attribute.  Valid characters for
     attribute names are [A-Za-z0-9_-].  The name must begin with a
     letter or an underscore, and must not start with "xml" or
     "eclip", which are reserved prefixes.

     @since 1.0
  */
  EXPORT void DECL FPTag_RemoveAttribute (const FPTagRef inTag, 
                                          const char *inAttrName);


  /**
     Uses wide-character string
     @see FPTag_RemoveAttribute() 
     
     @since 1.1
  */
  EXPORT void DECL FPTag_RemoveAttributeW(const FPTagRef inTag, 
                                          const wchar_t *inAttrName);

  /**
     Uses UTF-8 encoding
     @see FPTag_RemoveAttribute() 
   */
  EXPORT void DECL FPTag_RemoveAttribute8(const FPTagRef inTag, 
                                          const char *inAttrName);

  /**
     Uses UTF-16 encoding
     @see FPTag_RemoveAttribute() 
   */
  EXPORT void DECL FPTag_RemoveAttribute16(const FPTagRef inTag, 
                                           const FPChar16 *inAttrName);

  /**
     Uses UTF-32 encoding
     @see FPTag_RemoveAttribute() 
   */
  EXPORT void DECL FPTag_RemoveAttribute32(const FPTagRef inTag, 
                                           const FPChar32 *inAttrName);


  /**
     Returns the number of attributes in a tag.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @since 1.0
  */
  EXPORT FPInt DECL FPTag_GetNumAttributes (const FPTagRef inTag);


  /**
     Returns the name and value of an attribute according to the rank
     of the attribute in the specified tag.  This function requires
     exclusive access to the C-Clip reference in memory.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inIndex the index number (zero based) of the attribute that
     has to be retrieved.

     @param outAttrName A pointer to the buffer that will receive the
     name of the attribute.

     @param ioAttrNameLen On input, this parameter must specify the
     size of the buffer in characters (not bytes).  At most
     (*ioAttrNameLen - 1) characters (not bytes) will be written to the
     buffer, plus a terminating null character.  On output, this
     parameter contains the actual number of characters in the
     attribute name, including the terminating null character.

     @param outAttrValue A pointer to the buffer that will receive the
     value of the attribute.

     @param ioAttrValueLen On input, this parameter must specify the
     size of the buffer in characters (not bytes).  At most
     (*ioAttrValueLen - 1) characters (not bytes) will be written to the
     buffer, plus a terminating null character.  On output, this
     parameter contains the actual number of characters in the
     attribute value, including the terminating null character.

     <b>Example:</b>
     <pre>
     char TagAttrName[MAX_NAME_SIZE];
     char TagAttrValue[MAX_NAME_SIZE];
     NumAttributes = FPTag_GetNumAttributes(Tag);
     if (FPPool_GetLastError() != 0)
        handle error...

     for (i = 0; i < NumAttributes; i++)
     {
        AttrNameSize = MAX_NAME_SIZE;
        AttrValueSize = MAX_NAME_SIZE;

        FPTag_GetIndexAttribute(Tag, i,
                                TagAttrName, &AttrNameSize,
                                TagAttrValue, &AttrValueSize);

        if (FPPool_GetLastError() != 0)
           handle error

        printf("Attribute #%d has name \"%s\" and value \"%s\".\n",
               i, TagAttrName, TagAttrValue);
     }
     </pre>

     @since 1.0
  */
  EXPORT void DECL FPTag_GetIndexAttribute (const FPTagRef inTag,
                                            const FPInt inIndex, 
                                            char *outAttrName,  
                                            FPInt *ioAttrNameLen, 
                                            char *outAttrValue, 
                                            FPInt *ioAttrValueLen);
   

  /**
     Like FPTag_GetIndexAttribute(), but using wide-character strings.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inIndex the index number (zero based) of the attribute that
     has to be retrieved.

     @param outAttrName A pointer to the buffer that will receive the
     name of the attribute.

     @param ioAttrNameLen On input, this parameter must specify the
     size of the buffer in characters (not bytes).  At most
     (*ioAttrNameLen - 1) characters (not bytes) will be written to the
     buffer, plus a terminating null character.  On output, this
     parameter contains the actual number of characters in the
     attribute name, including the terminating null character.

     @param outAttrValue A pointer to the buffer that will receive the
     value of the attribute.

     @param ioAttrValueLen On input, this parameter must specify the
     size of the buffer in characters (not bytes).  At most
     (*ioAttrValueLen - 1) characters (not bytes) will be written to the
     buffer, plus a terminating null character.  On output, this
     parameter contains the actual number of characters in the
     attribute value, including the terminating null character.

     @since 1.1
  */
  EXPORT void DECL FPTag_GetIndexAttributeW(const FPTagRef inTag,
                                            const FPInt inIndex, 
                                            wchar_t *outAttrName,  
                                            FPInt *ioAttrNameLen, 
                                            wchar_t *outAttrValue, 
                                            FPInt *ioAttrValueLen);

  /**
     Uses UTF-8 encoding
     @see FPTag_GetIndexAttribute() 
   */
  EXPORT void DECL FPTag_GetIndexAttribute8(const FPTagRef inTag,
                                            const FPInt inIndex, 
                                            char *outAttrName,  
                                            FPInt *ioAttrNameLen, 
                                            char *outAttrValue, 
                                            FPInt *ioAttrValueLen);

  /**
     Uses UTF-16 encoding
     @see FPTag_GetIndexAttribute() 
   */
  EXPORT void DECL FPTag_GetIndexAttribute16(const FPTagRef inTag,
                                             const FPInt inIndex, 
                                             FPChar16 *outAttrName,  
                                             FPInt *ioAttrNameLen, 
                                             FPChar16 *outAttrValue, 
                                             FPInt *ioAttrValueLen);

  /**
     Uses UTF-32 encoding
     @see FPTag_GetIndexAttribute() 
   */
  EXPORT void DECL FPTag_GetIndexAttribute32(const FPTagRef inTag,
                                             const FPInt inIndex, 
                                             FPChar32 *outAttrName,  
                                             FPInt *ioAttrNameLen, 
                                             FPChar32 *outAttrValue, 
                                             FPInt *ioAttrValueLen);

  /** @} */ /* tag functions */

#ifdef __MWERKS__
#pragma mark Blob functions
#endif

  /** @defgroup Blob Blob functions
      @{
  */


  /**
     Retrieves the size of the blob referenced by the specified tag.

     @param inTag the valid reference to a tag

     @return the size, in bytes, of the blob referenced by this tag.
     Returns -1 if the tag contains no data.

     @since 1.1
  */
  EXPORT FPLong DECL FPTag_GetBlobSize (const FPTagRef inTag);


  /**
     Stores blob data in the pool from a stream object that the
     application provides.

     The function opens a new blob, reads bytes from the stream
     object, writes the bytes to the pool, closes the blob, and
     associates the calculated content address (CA) with the
     tag. Whether the function calculates the CA before or while
     sending the data to the pool, depends on the given parameters.

     @note The function writes the data in chunks that equal the
     internal memory buffer size. The default value of the internal
     memory buffer is 16 Kbyte. To enlarge this size, use
     FPPool_SetIntOption().

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inStream The reference to a stream as returned from
     FPStream_CreateWithFile(), FPStream_CreateWithBuffer() or
     FPStream_CreateTemporaryFile().

     @param inOptions A numeric code that identifies how the content
     address should be calculated. You must use one of the following
     options:
     <dl>
      <dt>#FP_OPTION_CLIENT_CALCID_STREAMING <dd>The client
     calculates the address while sending the data to the server.
      <dt>#FP_OPTION_SERVER_CALCID_STREAMING <dd>The server calculates the
     address (as the application server sends the data).
     </dl>
     <p>
     The following option may be used in conjunction with any of the
     options above:
     <dl>
      <dt>#FP_OPTION_ENABLE_COLLISION_AVOIDANCE <dd>Enables content address
     collision by appending a globally unique ID to the blob's content address.
      <dt>#FP_OPTION_DISABLE_COLLISION_AVOIDANCE <dd>If the collision avoidance
     option is on (FPPool_SetIntOption), disable this capability for this
     BlobWrite only.
      <dt>#FP_OPTION_EMBED_DATA <dd>Forces the data being written to be embedded
      within the clip.
     </dl>
     
     <b>Example:</b>
     <pre>
     // Calculate the address on the client with
     // end-to-end checking.
     FPTag_BlobWrite (MyTag, MyStream, FP_OPTION_CLIENT_CALCID);

     // Calculate the address on the server without
     // end-to-end checking.
     FPTag_BlobWrite (MyTag, MyStream,
                       FP_OPTION_SERVER_CALCID_STREAMING);
     </pre>

     @since 1.0
  */
  EXPORT void DECL FPTag_BlobWrite (const FPTagRef inTag, 
                                    const FPStreamRef inStream, 
                                    const FPLong inOptions);

  /**
     See the CenteraAPIRefGuide for a more detailed explanation of this function.

     This function does not work with any of the embedded options. If the inOptions
     param includes FP_OPTION_EMBED_DATA (force embed) then an error will occur. 
     If an embedded data threshold has been set, it is ignored by this function.

     There are two main purposes for this function:
       - Allow an application to use multiple threads to write a single piece of 
         data to Centera
       - Allow an application to append data to existing data contained within an 
         existing tag.

     This function can be used any place the FPTag_BlobWrite function can be used, 
     however if an application has no need to multithread or append particular data
     then it should use the FPTag_BlobWrite function instead.

     Any data written to Centera using this function can be read back using any of the 
     SDK read functions in a transparent fashion. This means no additional code on the 
     application side is required to read the data written using this function.

     @note The function writes the data in chunks that equal the
     internal memory buffer size. The default value of the internal
     memory buffer is 16 Kbyte. To enlarge this size, use
     FPPool_SetIntOption().

     @param inTag The reference to a tag as returned from
                  FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
                  FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().
                  This function allows multiple threads, or the same thread,
                  to use the same inTag if the application wishes to multithread
                  or append to a particular piece of data.

     @param inStream The reference to a stream as returned from
                     FPStream_CreateWithFile(), FPStream_CreateWithBuffer() or
                     FPStream_CreateTemporaryFile(). It is the applications 
                     responsibility to create streams to different segments of 
                     their data if they wish to use this function with the same inTag..

     @param inOptions A numeric code that identifies how the content
     address should be calculated. You must use one of the following
     options:
     <dl>
      <dt>#FP_OPTION_CLIENT_CALCID_STREAMING <dd>The client
     calculates the address while sending the data to the server.
      <dt>#FP_OPTION_SERVER_CALCID_STREAMING <dd>The server calculates the
     address (as the application server sends the data).
     </dl>
     <p>
     The following option may be used in conjunction with any of the
     options above:
     <dl>
      <dt>#FP_OPTION_ENABLE_DUPLICATE_DETECTION <dd>The SDK will return the
     #FP_DUPLICATE_FILE_ERR error if a blob with the same content address
     has been discovered in the pool.
      <dt>#FP_OPTION_ENABLE_COLLISION_AVOIDANCE <dd>Enables content address
     collision by appending a globally unique ID to the blob's content address.
      <dt>#FP_OPTION_DISABLE_COLLISION_AVOIDANCE <dd>If the collision avoidance
     option is on (FPPool_SetIntOption), disable this capability for this
     BlobWrite only.
      
     @param inSequenceID A numerical identifier that is used to determine the sequence 
                         of the written data. This inSequenceID is only important 
                         if this function is being used by a single thread or multiple 
                         threads using the same inTag. The sequence does not determine the
                         order in which the data are written, rather it determines the order
                         the data are read when being read back from Centera. Only the 
                         following rules apply to the inSequenceID:
                           - IDs must be >= zero or an FPParameterException occurs
                           - Duplicate IDs are not allowed between threads that are using 
                             the same inTag param, each one must be unique or an 
                             FPDuplicateSeqIdException occurs.
                           - Once an FPTag_Close() has been performed on a particular
                             tag, the application IS allowed to reuse the same 
                             sequenceIDs that were previously used for that tag
                             in the new series of BlobWritePartial calls for that
                             reopened tag. In other words duplicate IDs are only 
                             considered from time of creation, or reopening, of a 
                             tag to closing of that same tag.
                           - When reading back the data associated with each ID, it is 
                             read back from lowest ID to highest ID
                         Data being written to a tag that has existing data will automatically 
                         be written to the end of the existing data.
     @since 3.0

   */
  EXPORT void DECL FPTag_BlobWritePartial (const FPTagRef inTag, 
                                           const FPStreamRef inStream, 
                                           const FPLong inOptions, 
                                           const FPLong inSequenceID);


  /**
     Retrieves the blob data from the pool and writes it to the stream
     object provided.  The function Gets the content address from the
     tag, opens the blob, reads the data in chunks of 16 Kbyte, writes
     the bytes to the stream, and closes the blob.

     @note FPTag_BlobRead leaves the marker at the end of the
     stream.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inStream The reference to a stream as returned from
     FPStream_CreateWithFile(), FPStream_CreateWithBuffer() or
     FPStream_CreateTemporaryFile().

     @param inOptions A numeric code that identifies the option to be
     used.  You can only use the following options:
     <dl>
      <dt>#FP_OPTION_DEFAULT_OPTIONS <dd>The default is to verify the data read
          from the Centera server.
      </dl>
     
     <b>Example:</b>
     <pre>FPTag_BlobRead (MyTag, MyStream, FP_OPTION_DEFAULT_OPTIONS)</pre>

     @since 1.0
  */
  EXPORT void DECL FPTag_BlobRead (const FPTagRef inTag, 
                                   const FPStreamRef inStream,
                                   const FPLong inOptions);


  /**
     Retrieves the blob data from the pool and writes the data to the
     stream object provided.  The function Gets the content address
     from the tag, opens the blob, starts reading the blob packet as
     specified by the given offset, writes the specified bytes to the
     stream, and closes the blob.

     You can use FPStream_GetMarker() and FPStream_SetMarker() to
     determine and specify the position in the stream to which you
     want to write the blob packet.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @param inStream The reference to a stream as returned from
     FPStream_CreateWithFile(), FPStream_CreateWithBuffer() or
     FPStream_CreateTemporaryFile().

     @param inOffset The offset, in the blob, at which the read
     operation should begin (in bytes).

     @param inReadLength The length in bytes of the data chunk to be
     read.  Specify -1 if you want to read all data from inOffset to
     the end of the blob.

     @param inOptions A numeric code that identifies the option to be
     used.  You can only use the following options:
     <dl>
      <dt>#FP_OPTION_DEFAULT_OPTIONS <dd>The default is to verify the data read
          from the Centera server if <i>inOffset</i> = 0 and
          <i>inReadLength</i> = -1.
      </dl>
     
     <b>Examples:</b>
     <pre>
     // Read 8 Kbytes of the blob, starting at the first byte.
     FPTag_BlobReadPartial(MyTag, MyStream, 0, 8192, FP_OPTION_DEFAULT_OPTIONS);

     // Read 8 Kbytes of the blob, starting at offset 32 Kbytes.
     FPTag_BlobReadPartial(MyTag, MyStream, 32768, 8192, FP_OPTION_DEFAULT_OPTIONS);

     // Read the entire blob, equivalent to FPTag_BlobRead(MyTag,
     // MyStream, 0) .
     FPTag_BlobReadPartial(MyTag, MyStream, 0, -1, FP_OPTION_DEFAULT_OPTIONS);
     </pre>

     @since 1.0
  */
  EXPORT void DECL FPTag_BlobReadPartial (const FPTagRef inTag, 
                                          const FPStreamRef inStream,
                                          const FPLong inOffset, 
                                          const FPLong inReadLength, 
                                          const FPLong inOptions);


  /**
     Purges a blob from the given tag in an opened C-Clip. The tag
     itself will not be deleted.

     @note Purging a blob from a pool actually removes the blob
     irrespective of any references to it. Errors will occur if an
     application tries to read a blob that no longer exists. The
     application developer has to write code to handle this.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @deprecated  use FPTag_Delete instead 

     @since 1.0
  */
  EXPORT void DECL FPTag_BlobPurge (const FPTagRef inTag);

  /**
     Checks the existence of the blobdata in the tag.

     @param inTag The reference to a tag as returned from
     FPTag_Create(), FPTag_GetParent(), FPTag_GetFirstChild(),
     FPTag_GetSibling(), FPClip_GetTopTag() or FPClip_FetchNext().

     @return false if the tag has blobs which do not exist on server
             true  if all blobdata is present
             -1 if the tag has no blobs

     @since 2.1
  */
  EXPORT FPInt DECL FPTag_BlobExists (const FPTagRef inTag);

  /** @} */ /* blob functions */

  /** @defgroup PoolQuery PoolQuery functions
      @{
  */

#ifdef __MWERKS__
#pragma mark QueryExpression functions
#endif


  /**
     Define the conditions on which to query the Pool.  An reference to a
     FPQueryExpression needs to be made before a FPPoolQuery can be started.
     
     @return a reference to an opened FPQueryExpression object
     
     @since 2.3 
  */
     EXPORT FPQueryExpressionRef DECL FPQueryExpression_Create (void) ;
     
  /**
     Close the query expression and releases all memory.  This method should
     be called after using the FPQueryExpressionRef in the FPPoolQuery_Open, 
     or when you've done with the expression.
     
     @param inRef A query expression created using FPQueryExpression_Create 
                  or NULL
     
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_Close (const FPQueryExpressionRef inRef);
     
   /**
     Sets a query condition.  The C-Clips to be retrieved in the query result 
     have a time later than the time indicated.  Default is 0, the earliest 
     possible time.
     
     @param inRef    a query expression created using FPQueryExpression_Create
     @param inTime   starting time of query in milliseconds since epoch
        
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_SetStartTime (const FPQueryExpressionRef inRef,
                                                      const FPLong inTime) ;

   /**
     Sets a query condition.  The C-Clips to be retrieved in the query result 
     have a time no later than the time indicated.  Default is -1, which 
     retrieves C-Clips up to the present time.
     
     @param inRef    a query expression created using FPQueryExpression_Create
     @param inTime   ending time of query in milliseconds since epoch
        
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_SetEndTime (const FPQueryExpressionRef inRef,
                                                    const FPLong inTime) ;
 
   /**
     Sets a query condition.  The C-Clips to be retrieved in the query result must be
     either:
     - existing C-Clips, use FP_QUERY_TYPE_EXISTING
     - deleted C-Clips,  use FP_QUERY_TYPE_DELETED
     - or both,          use (FP_QUERY_TYPE_EXISTING | FP_QUERY_TYPE_DELETED)
     
     @param inRef    a query expression created using FPQueryExpression_Create
     @param inType   the type of C-Clips wanted in the query result
        
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_SetType (const FPQueryExpressionRef inRef,
                                                 const FPInt inType) ;

   /**
     Get the start time from the query expression.
     
     @param inRef    a query expression created using FPQueryExpression_Create
     @return the starttime as set using FPQueryExpression_SetStartTime() or 0. Units are
             seconds since epoch.
     
     @since 2.3
   */
     EXPORT FPLong DECL FPQueryExpression_GetStartTime (const FPQueryExpressionRef inRef) ;

   /**
     Get the end time from the query expression.
     
     @param inRef    a query expression created using FPQueryExpression_Create
     @return the endtime as set using FPQueryExpression_SetEndTime() or 0. Units are
             seconds since epoch.
     
     @since 2.3
   */
     EXPORT FPLong DECL FPQueryExpression_GetEndTime (const FPQueryExpressionRef inRef) ;

   /**
     Get the query type from the query expression. 
     
     @param inRef    a query expression created using FPQueryExpression_Create
     @return the query type:
         - FP_QUERY_TYPE_EXISTING: query for existing clips only
     	 - FP_QUERY_TYPE_DELETED:  query for deleted clips only
     	 - FP_QUERY_TYPE_EXISTING|FP_QUERY_TYPE_DELETED: query for both deleted as existing clips
     	 
     @since 2.3
   */
     EXPORT FPInt DECL FPQueryExpression_GetType (const FPQueryExpressionRef inRef) ;

   /**
     Selects that a C-Clip description attribute is included in the query result.
     No error is returned if the C-Clip does not contain the attribute indicated.

     @param inRef   a query expression created using FPQueryExpression_Create
     @param inFieldName the name of a C-Clip description attribute
     
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_SelectField (const FPQueryExpressionRef inRef, 
                                                     const char* inFieldName);

   /**
     Selects that a C-Clip description attribute is included in the query result.
     No error is returned if the C-Clip does not contain the attribute indicated.
     
     @param inRef   a query expression created using FPQueryExpression_Create
     @param inFieldName   the name of a C-Clip description attribute
     
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_SelectFieldW (const FPQueryExpressionRef inRef, 
                                                      const wchar_t* inFieldName);

    /**
       Uses UTF-8 encoding
       @see FPQueryExpression_SelectField() 
     */
     EXPORT void DECL FPQueryExpression_SelectField8 (const FPQueryExpressionRef inRef, 
                                                      const char* inFieldName);

    /**
       Uses UTF-16 encoding
       @see FPQueryExpression_SelectField() 
     */
     EXPORT void DECL FPQueryExpression_SelectField16 (const FPQueryExpressionRef inRef,
                                                       const FPChar16* inFieldName);

    /**
       Uses UTF-32 encoding
       @see FPQueryExpression_SelectField() 
     */
     EXPORT void DECL FPQueryExpression_SelectField32 (const FPQueryExpressionRef inRef,
                                                       const FPChar32* inFieldName);

   /**
     Deselects a C-Clip description attribute. It was previously added to the 
     QueryExpression using FPQueryExpression_SelectField. No error is returned if
     the QueryExpression does not contain the attribute indicated.

     @param inRef   a query expression created using FPQueryExpression_Create
     @param inFieldName the name of a C-Clip description attribute
     
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_DeselectField (const FPQueryExpressionRef inRef,
                                                       const char* inFieldName) ;

   /**
     Deselects a C-Clip description attribute is was previously added to the 
     QueryExpression using FPQueryExpression_SelectField. No error is returned if
     the QueryExpression does not contain the attribute indicated.

     @param inRef   a query expression created using FPQueryExpression_Create
     @param inFieldName the name of a C-Clip description attribute
     
     @since 2.3
   */
     EXPORT void DECL FPQueryExpression_DeselectFieldW (const FPQueryExpressionRef inRef, 
                                                        const wchar_t* inFieldName) ;

    /**
       Uses UTF-8 encoding
       @see FPQueryExpression_DeselectField() 
     */
    EXPORT void DECL FPQueryExpression_DeselectField8 (const FPQueryExpressionRef inRef,
                                                       const char* inFieldName) ;

    /**
       Uses UTF-16 encoding
       @see FPQueryExpression_DeselectField() 
     */
    EXPORT void DECL FPQueryExpression_DeselectField16 (const FPQueryExpressionRef inRef,
                                                        const FPChar16* inFieldName) ;

    /**
       Uses UTF-32 encoding
       @see FPQueryExpression_DeselectField() 
     */
    EXPORT void DECL FPQueryExpression_DeselectField32 (const FPQueryExpressionRef inRef,
                                                        const FPChar32* inFieldName) ;

   /**
     Returns if the QueryExpression is configured to return the indicated 
     description attribute.

     @param inRef   a query expression created using FPQueryExpression_Create
     @param inFieldName   the name of a C-Clip description attribute
     @return true if the QueryExpression is configured to return the attribute

     @since 2.3
   */
     EXPORT FPBool DECL FPQueryExpression_IsFieldSelected (const FPQueryExpressionRef inRef, 
                                                           const char* inFieldName);

   /**
     Returns if the QueryExpression is configured to return the indicated 
     description attribute.

     @param inRef   a query expression created using FPQueryExpression_Create
     @param inFieldName   the name of a C-Clip description attribute
     @return true if the QueryExpression is configured to return the attribute

     @since 2.3
   */
    EXPORT FPBool DECL FPQueryExpression_IsFieldSelectedW (const FPQueryExpressionRef inRef,
                                                           const wchar_t* inFieldName);

    /**
       Uses UTF-8 encoding
       @see FPQueryExpression_IsFieldSelected() 
     */
    EXPORT FPBool DECL FPQueryExpression_IsFieldSelected8 (const FPQueryExpressionRef inRef, 
                                                           const char* inFieldName);

    /**
       Uses UTF-16 encoding
       @see FPQueryExpression_IsFieldSelected() 
     */
    EXPORT FPBool DECL FPQueryExpression_IsFieldSelected16 (const FPQueryExpressionRef inRef,
                                                            const FPChar16* inFieldName);

    /**
       Uses UTF-32 encoding
       @see FPQueryExpression_IsFieldSelected() 
     */
    EXPORT FPBool DECL FPQueryExpression_IsFieldSelected32 (const FPQueryExpressionRef inRef,
                                                            const FPChar32* inFieldName);


#ifdef __MWERKS__
#pragma mark PoolQuery functions
#endif

   /**
     Starts a Query on the Pool.  
     The QueryExpression is used to define the conditions on the query.
     
     @param inPoolRef   a valid pool reference as returned by FPPool_Open()
     @param inQueryExpressionRef a valid query expression reference as returned 
     by FPQueryExpression_Create()

     @return a reference to the open PoolQuery object
     
     @since 2.3
   */
     EXPORT FPPoolQueryRef DECL FPPoolQuery_Open (const FPPoolRef inPoolRef,
                                                  FPQueryExpressionRef inQueryExpressionRef) ;

   /**
     Closes a query on the Pool.  You have to call this method to deallocate any
     resources that the query has opened.  
     
     @param inPoolQueryRef   a valid PoolQuery reference as returned by FPPoolQuery_Open() or NULL
     
     @since 2.3
   */
     EXPORT void DECL FPPoolQuery_Close (const FPPoolQueryRef inPoolQueryRef) ;
     
   /**
     Returns the FPPoolRef used to open to query object.
    
     @param inPoolQueryRef   a valid PoolQuery reference as returned by 
                             FPPoolQuery_Open()
     
     @return the PoolReference associated with the open poolquery object

     @since 2.3
  */
     EXPORT FPPoolRef DECL FPPoolQuery_GetPoolRef (const FPPoolQueryRef inPoolQueryRef) ;


#ifdef __MWERKS__
#pragma mark QueryResult functions
#endif

   /**
     Retrieves a result from the query to the application.  The result is 
     encoded in the QueryResult object and the application can get to its fields 
     via various getter-methods.
     
     @param inPoolQueryRef  a valid PoolQuery reference as returned by 
                            FPPoolQuery_Open()
     @param inTimeout        inTimeout refers to the time in milliseconds that
                             the function will wait for the next result. If 
                             inTimeout = -1, the function uses the default 
                             timeout of 120000 ms (2 minutes).
     @return a reference to a QueryResult object.
             NOTE that the caller must release this object by using the delete 
             keyword when done with it.
     
     @since 2.3
   */
     EXPORT FPQueryResultRef DECL FPPoolQuery_FetchResult (const FPPoolQueryRef inPoolQueryRef, 
                                                           const FPInt inTimeout) ;


   /**
     Closes the QueryResult object as returned by FPPoolQuery_FetchResult().  The application has
     to call this method once it has retrieved all information from a single query result.
     
     @param inQueryResultRef    a valid QueryResult reference as returned by FPPoolQuery_FetchResult or NULL

     @since 2.3
   */

     EXPORT void DECL FPQueryResult_Close (const FPQueryResultRef inQueryResultRef) ;
     
   /** 
     This method returns the ClipID from the query result.
     
     @param inQueryResultRef  a valid QueryResult reference as returned by 
                              FPPoolQuery_FetchResult
     @param outClipID         buffer of type FPClipID used to hold the returned 
                              C-Clip ID

     @since 2.3
   */
     EXPORT void DECL FPQueryResult_GetClipID (const FPQueryResultRef inQueryResultRef,
                                               FPClipID outClipID) ;

   /** 
     This method returns the timestamp from the query result.  
     - For existing C-Clips, this is the time the C-Clip was created on the
       Centera system.
     - For deleted C-Clips, this is the time the C-Clip was deleted from the 
       Centera system.
     
     @param inQueryResultRef  a valid QueryResult reference as returned by 
                              FPPoolQuery_FetchResult
     @return the timestamp in seconds since epoch

     @since 2.3
   */
     EXPORT FPLong DECL FPQueryResult_GetTimestamp (const FPQueryResultRef inQueryResultRef) ;

   /**
     Retrieve the value of a description attribute from a queried C-Clip, if it 
     exists.  If not, outAttrValue is an empty string and ioAttrValueLen is 0.
     
     @param  inQueryResultRef   a valid QueryResult reference as returned by FPPoolQuery_FetchResult
     @param  inAttrName         the name of a C-Clip description attribute
     @param  outAttrValue       a buffer to hold the value of the description attribute
     @param  ioAttrValueLen     - on input, the length of the outAttrValue buffer
                                - on output, the actual length of the attribute value

     @since 2.3
    */
     EXPORT void DECL FPQueryResult_GetField (const FPQueryResultRef inQueryResultRef,
                                              const char *inAttrName,
                                              char *outAttrValue,
                                              FPInt *ioAttrValueLen) ;


   /**
     Retrieve the value of a description attribute from a queried C-Clip, if it 
     exists.  If not, outAttrValue is an empty string and ioAttrValueLen is 0.
     
     @param  inQueryResultRef   a valid QueryResult reference as returned by FPPoolQuery_FetchResult
     @param  inAttrName        the name of a C-Clip description attribute
     @param  outAttrValue      a buffer to hold the value of the attribute
     @param  ioAttrValueLen    - on input, the length of the outAttrValue buffer
                                - on output, the actual length of the attribute value

     @since 2.3
    */
     EXPORT void DECL FPQueryResult_GetFieldW (const FPQueryResultRef inQueryResultRef,
                                               const wchar_t *inAttrName,
                                               wchar_t *outAttrValue,
                                               FPInt *ioAttrValueLen) ;

    /**
       Uses UTF-8 encoding
       @see FPQueryResult_GetField() 
     */
    EXPORT void DECL FPQueryResult_GetField8 (const FPQueryResultRef inQueryResultRef,
                                              const char *inAttrName,
                                              char *outAttrValue,
                                              FPInt *ioAttrValueLen) ;

    /**
       Uses UTF-16 encoding
       @see FPQueryResult_GetField() 
     */
    EXPORT void DECL FPQueryResult_GetField16 (const FPQueryResultRef inQueryResultRef,
                                               const FPChar16 *inAttrName,
                                               FPChar16* outAttrValue,
                                               FPInt *ioAttrValueLen) ;

    /**
       Uses UTF-32 encoding
       @see FPQueryResult_GetField() 
     */
    EXPORT void DECL FPQueryResult_GetField32 (const FPQueryResultRef inQueryResultRef,
                                               const FPChar32 *inAttrName,
                                               FPChar32 *outAttrValue,
                                               FPInt *ioAttrValueLen) ;

   /**
     Retrieve the result code from the query result.  The result code is one of:
        - FP_QUERY_RESULT_CODE_OK         
        - FP_QUERY_RESULT_CODE_INCOMPLETE 
        - FP_QUERY_RESULT_CODE_COMPLETE   
        - FP_QUERY_RESULT_CODE_END        
        - FP_QUERY_RESULT_CODE_ABORT      

        - FP_QUERY_RESULT_CODE_ERROR      
        - FP_QUERY_RESULT_CODE_PROGRESS   

     @param inQueryResultRef    a valid QueryResult reference as returned by 
                                FPPoolQuery_FetchResult
     @return the result code from this query
     
     @since 2.3
    */
     EXPORT FPInt DECL FPQueryResult_GetResultCode (const FPQueryResultRef inQueryResultRef) ;


   /**
     Retrieve the type of C-Clip in the query result.  It is one of:
         - FP_QUERY_TYPE_EXISTING
         - FP_QUERY_TYPE_DELETED
     
     @param inQueryResultRef    a valid QueryResult reference as returned by 
                                FPPoolQuery_FetchResult
     @return the type of C-Clip in the query result
     
     @since 2.3
    */
     EXPORT FPInt DECL FPQueryResult_GetType (const FPQueryResultRef inQueryResultRef) ;

  /** @} */ /* poolquery functions */
       

#ifdef __MWERKS__
#pragma mark Query functions
#endif

  /** @defgroup Query Query functions
      @{
  */

  /**
     Opens a query stream to the given pool and queries the C-Clips
     that have been stored in the pool from the given start time until
     the given stop time. 
   
     @param inPool The reference to a pool that the FPPool_Open()
     function has opened.

     @param inStartTime Specifies from what time the C-Clips that you
     query must have been written to the pool. The time has to be
     given in milliseconds counted from midnight January 1, 1970 and
     is based on the UTC (Coordinated Universal Time, formerly known
     as GMT  Greenwich Mean Time) of the system clock of the
     Centera server that has stored the C-Clips. If inStartTime is 0,
     the function queries all C-Clips that have been stored on the
     pool until inStopTime.

     @param inStopTime Specifies until what time the C-Clips that you
     query must have been written to the pool. The time has to be
     given in milliseconds counted from midnight January 1, 1970 and
     is based on UTC (Coordinated Universal Time, formerly known as
     GMT  Greenwich Mean Time) of the system clock of the Centera
     server that has stored the C-Clips. inStopTime must be before or
     the same as the time when this function is called. inStopTime = -1
     refers to the current time.

     @param inReserved this parameter is currently not in use.  Set it to NULL.

     @return a reference to an opened query object
     
     @deprecated  use FPPoolQuery_Open instead
     
     @since 1.1
  */
  EXPORT FPQueryRef DECL FPQuery_Open(const FPPoolRef inPool, 
                                      const FPLong inStartTime,
                                      const FPLong inStopTime, 
                                      const char *inReserved);
                                       
  /**
     Like FPQuery_Open(), but the pReserved parameter is a wide
     character string.
   
     @deprecated  use FPPoolQuery_Open instead

     @since 1.1
  */
  EXPORT FPQueryRef DECL FPQuery_OpenW (const FPPoolRef inPool, 
                                        const FPLong inStartTime,
                                        const FPLong inStopTime, 
                                        const wchar_t *inReserved);

  /**
     Uses UTF-8 encoding
     @see FPQuery_Open() 
   */
  EXPORT FPQueryRef DECL FPQuery_Open8 (const FPPoolRef inPool, 
                                        const FPLong inStartTime,
                                        const FPLong inStopTime, 
                                        const char *inReserved);

  /**
     Uses UTF-16 encoding
     @see FPQuery_Open() 
   */
  EXPORT FPQueryRef DECL FPQuery_Open16 (const FPPoolRef inPool, 
                                         const FPLong inStartTime,
                                         const FPLong inStopTime, 
                                         const FPChar16 *inReserved);

  /**
     Uses UTF-32 encoding
     @see FPQuery_Open() 
   */
  EXPORT FPQueryRef DECL FPQuery_Open32 (const FPPoolRef inPool, 
                                         const FPLong inStartTime,
                                         const FPLong inStopTime, 
                                         const FPChar32 *inReserved);
    
                                        

  /**
     Fetches the C-Clips one by one in time ascending order that
     FPQuery_Open() has queried and returns a value that indicates the
     status of the function.  
    
     If FPPool_GetLastError() returns a timeout error (the particular
     error depends on the Operating System), then retry this
     function. It means that the server is still busy but the timeout
     value is too small.
   
     @param inQuery The reference to the query stream that FPQuery_Open
     has opened.

     @param outResultClip The C-Clip ID of the C-Clip that is returned
     to the function.

     @param outTimestamp outTimestamp refers to the time when the returned
     C-Clip has been stored on the pool.

     @param inTimeout inTimeout refers to the time in milliseconds that
     the function will wait for the next result. If inTimeout = -1, the
     function uses the default timeout of 120000 ms (2 minutes).
 
     @return a value that indicates the status of the result:<br><br>
     <dl>
      <dt>#FP_QUERY_RESULT_CODE_OK <dd>The function has fetched a valid C-Clip
     ID that can be processed by the application.

      <dt>#FP_QUERY_RESULT_CODE_INCOMPLETE <dd>The following results of the query 
     may be incomplete because two or more Storage Nodes were not online during 
     the query.
  
      <dt>#FP_QUERY_RESULT_CODE_COMPLETE <dd>This value will always be returned 
     after FP_QUERY_RESULT_CODE_INCOMPLETE. Although the results of the query are 
     complete, they may not be valid. We recommend restarting the query from the 
     last valid outTimestamp before FP_QUERY_RESULT_CODE_INCOMPLETE was returned.

      <dt>#FP_QUERY_RESULT_CODE_END <dd>The query has been finished, no more
     query results are expected.

      <dt>#FP_QUERY_RESULT_CODE_ABORT <dd>The query has been aborted because
     of a problem at the server side or because inStartTime used with 
     FPQuery_Open() is later than the current server time. Check inStartTime and 
     retry the query.

      <dt>#FP_QUERY_RESULT_CODE_PROGRESS <dd>The query is in progress.
     </dl>
     
    @deprecated

     @since 1.1
  */
  EXPORT FPInt DECL FPQuery_FetchResult (const FPQueryRef inQuery, 
                                         FPClipID outResultClip, 
                                         FPLong *outTimestamp, 
                                         const FPInt inTimeout);
  

  /**
     Closes a query stream that has been opened by FPQuery_Open().
    
     @param inQuery The reference to a query stream as returned from
     the FPQuery_Open() function. The reference may also be NULL.

     @deprecated

     @since 1.1
  */
  EXPORT void DECL FPQuery_Close (const FPQueryRef inQuery);


  /**
     Returns the FPPoolRef used to open to query object.
    
     @param inQuery The reference to a query stream as returned from
     the FPQuery_Open function. The reference may also be NULL.
     
     @return the PoolReference associated with the open query object

     @deprecated

     @since 1.1
  */
  EXPORT FPPoolRef DECL FPQuery_GetPoolRef (const FPQueryRef inQuery) ;

  /** @} */ /* query functions */
       
#ifdef __MWERKS__
#pragma mark Monitor functions
#endif



  /**
    Creates a new object to monitor the state of the Centera.
    The monitor transactions will go to the first IP address in the list that is
    available.  It checks the availability of an AN using the UDP Probe 
    transaction, whose reply contains the clusterID needed for the authentication
    phase. The method uses the PAI module to get authentication information. 

    @param inClusterAddress a comma separated list of AN ip addresses.
    @return  a reference to an FPMonitor object.
	
	@since 2.1
  */ 

  EXPORT FPMonitorRef DECL FPMonitor_Open (const char *inClusterAddress) ;

  /**
    Creates a new object to monitor the state of the Centera.
    The monitor transactions will go to the first IP address in the list that is 
    available.  It checks the availability of an AN using the UDP Probe 
    transaction, whose reply contains the clusterID needed for the authentication
    phase. The method uses the PAI module to get authentication information.

    @param inClusterAddress a comma separated list of AN ip addresses.
    @return  a reference to an FPMonitor object.
	
	@since 2.1
  */ 

  EXPORT FPMonitorRef DECL FPMonitor_OpenW (const wchar_t *inClusterAddress) ;

  /**
     Uses UTF-8 encoding
     @see FPMonitor_Open() 
   */
  EXPORT FPMonitorRef DECL FPMonitor_Open8 (const char *inClusterAddress) ;

  /**
     Uses UTF-16 encoding
     @see FPMonitor_Open() 
   */
  EXPORT FPMonitorRef DECL FPMonitor_Open16 (const FPChar16 *inClusterAddress) ;

  /**
     Uses UTF-32 encoding
     @see FPMonitor_Open() 
   */
  EXPORT FPMonitorRef DECL FPMonitor_Open32 (const FPChar32 *inClusterAddress) ;
  

  /**
    Closes the FPMonitor object and frees all related (memory) resources.
    @param inMonitor A monitor reference as previously returned by 
                     FPMonitor_Open()
   
	@since 2.1
  */ 
  
  EXPORT void DECL FPMonitor_Close (const FPMonitorRef inMonitor) ;

  /**
    Returns discovery information about the Centera cluster as an xml-formatted 
    text. The monitor object was previously successfully opened using 
    FPMonitor_Open. It is not guaranteed that if the application retries the call
    (eg. because the buffer was not large enough), that the new data is identical
    to the first call.  This has to be clearly documented.
    
    @param inMonitor reference to monitor as returned by FPMonitor_Open
    @param outData pointer to buffer that will receive the xml-formatted 
                   discovery info
 	@param ioDataLen
                -on input: the length of the buffer that outData points to
                -on output: the actual length of the discovery information

	@since 2.1

	@deprecated use FPMonitor_GetDiscoveryStream instead

  */ 

  EXPORT void DECL FPMonitor_GetDiscovery (const FPMonitorRef inMonitor,
  				                           char *outData,
  									       FPInt *ioDataLen) ;

  /**
    Returns discovery information about the Centera cluster as an xml-formatted 
    text. The monitor object was previously successfully opened using 
    FPMonitor_Open. It is not guaranteed that if the application retries the call
    (eg. because the buffer was not large enough), that the new data is identical
    to the first call.  This has to be clearly documented.
    
    @param inMonitor reference to monitor as returned by FPMonitor_Open
    @param inStream a generic stream used to output the discovery information.

	@since 2.1
  */ 

  EXPORT void DECL FPMonitor_GetDiscoveryStream (const FPMonitorRef inMonitor,
  	                                             const FPStreamRef inStream) ;
  									
  /**
    Returns all available statistical information about the Centera cluster as an xml-formatted text.  
    The monitor object was previously successfully opened using FPMonitor_Open.
    It is not guaranteed that if the application retries the call (eg. because 
    the buffer was not large enough), that the new data is identical to the first
    call.

    @param inMonitor reference to monitor as returned by FPMonitor_Open
    @param outData pointer to buffer that will receive the xml-formatted 
                   statistical info
    @param ioDataLen
                -on input: the length of the buffer that outData points to
                -on output: the actual length of the statistical information

	@since 2.1
 
	@deprecated use FPMonitor_GetAllStatisticsStream instead

  */ 

  EXPORT void DECL FPMonitor_GetAllStatistics (const FPMonitorRef inMonitor,
  							                   char *outData,
  									           FPInt *ioDataLen) ;

  /**
    Returns all available statistical information about the Centera cluster as an
    xml-formatted text. The monitor object was previously successfully opened 
    using FPMonitor_Open. It is not guaranteed that if the application retries 
    the call (eg. because the buffer was not large enough), that the new data is 
    identical to the first call.

    @param inMonitor reference to monitor as returned by FPMonitor_Open
    @param inStream a generic stream used to output the statistical information.

	@since 2.1

	@deprecated use FPMonitor_GetAllStatisticsStream instead

  */ 

  EXPORT void DECL FPMonitor_GetAllStatisticsStream(const FPMonitorRef inMonitor,
    									            const FPStreamRef inStream) ;


  /**
    Registers a stream to receive all events from a cluster.
    The events are received asynchronously.  This means that the stream cannot
    be closed before the registration is closed.
    
    @param inMonitor reference to monitor as returned by FPMonitor_Open
    @param inStream  a generic stream used to output the events information.
    @return a reference to the callback registration. This reference is needed to 
            close the event registration.
    
    @since 2.1
  */
  
  EXPORT FPEventCallbackRef DECL FPEventCallback_RegisterForAllEvents (const FPMonitorRef inMonitor,
                                                                       const FPStreamRef inStream) ;

  /**
    Stops the collection of events from the cluster.  
    The task is unregistered.  The application can now close the stream.
    
    @param inRegisterRef  reference to a registration as returned by 
                          FPMonitor_RegisterForAllEvents
    
    @since 2.1
  */

  EXPORT void DECL FPEventCallback_Close (const FPEventCallbackRef inRegisterRef);

  /**
    Bind the specified content address to the pool profile.
   
    @param inPool FPPoolRef opened by FPPool_Open() function.
    @param inContentAddress FPClipID returned by FPClip_Write() function.
   
    <b>Example:</b>
    <pre>FPPool_SetClipID(MyPool, MyClipID);</pre>
   
    @since 2.3
   */
  EXPORT void DECL FPPool_SetClipID (const FPPoolRef inPool, 
                                     const FPClipID inContentAddress);

  /**
    Get the content address bound to the pool profile.
   
    @param inPool FPPoolRef opened by FPPool_Open() function.
    @param outContentAddress FPClipID to write the content address into.
   
    <b>Example:</b>
    <pre>FPPool_GetClipID(MyPool, MyClipID);</pre>
   
    @since 2.3
   */
  EXPORT void DECL FPPool_GetClipID (const FPPoolRef inPool, 
                                     FPClipID outContentAddress);

  
  /**
    @param inPoolRef The pool where to retrieve the FPRetentionClassContextRef from.
    @return The FPRetentionClassContextRef associated with the passed in pool. 
            This returned object has a list of the retention classes that are 
            understood by the server the pool is connected to.
            NULL is returned if the server that the passed in pool is connected to
            does not support retention classes.
            NOTE: This return value (if not NULL) must be released by calling the
            function FPRetentionClassContext_Close(...)
    @since 2.3
   */
  EXPORT FPRetentionClassContextRef DECL FPPool_GetRetentionClassContext(const FPPoolRef inPoolRef);

  /**
    @param inContextRef The FPRetentionClassContextRef as returned by the function 
                        FPPool_GetRetentionClassContext(...)
    @since 2.3
   */
  EXPORT void DECL FPRetentionClassContext_Close(const FPRetentionClassContextRef inContextRef);

  /**
    @param inContextRef The FPRetentionClassContextRef as returned by a call to
                        FPPool_GetRetentionClassContext(FPPoolRef inPool)
    @return The number of retention classes contained within the passed in 
            FPRetentionClassContextRef
    @since 2.3
   */
  EXPORT FPInt DECL FPRetentionClassContext_GetNumClasses(const FPRetentionClassContextRef inContextRef);

  /**
    Gets the first FPRetentionClass object that is stored within the passed in 
    context. 
    @param inContextRef A FPRetentionClassContextRef as returned by the function 
                        FPPool_GetRetentionClassContext(...)
    @return A ref to a class that represents the name and interval of the first
            retention class within this context.
            NOTE: This return value (if not zero) must be released by calling 
                  FPRetentionClass_Close()
    @since 2.3
   */
  EXPORT FPRetentionClassRef  DECL FPRetentionClassContext_GetFirstClass(const FPRetentionClassContextRef inContextRef);

  /**
    Gets the last FPRetentionClass object that is stored within this context.
    @param inContextRef A FPRetentionClassContextRef as returned by the function 
                        FPPool_GetRetentionClassContext(...)
    @return A ref to a class that represents the name and interval of the last
            retention class within this context.
            NOTE: This return value (if not zero) must be released by calling 
                  FPRetentionClass_Close()
    @since 2.3
   */
  EXPORT FPRetentionClassRef  DECL FPRetentionClassContext_GetLastClass(const FPRetentionClassContextRef inContextRef);

  /**
    Gets the next available FPRetentionClass object that is stored within this
    context.
    @param inContextRef A FPRetentionClassContextRef as returned by the function 
                        FPPool_GetRetentionClassContext(...)
    @return A ref that represents the name and interval of the next
            retention class within this context, or zero (0) if there are no more
            (next) retention classes to return.
            NOTE: This return value (if not zero) must be released by calling 
                  FPRetentionClass_Close()
    @since 2.3
   */
  EXPORT FPRetentionClassRef  DECL FPRetentionClassContext_GetNextClass(const FPRetentionClassContextRef inContextRef);

  /**
    Gets the previous FPRetentionClass object that is stored within this
    context.
    @param inContextRef A FPRetentionClassContextRef as returned by the function 
                        FPPool_GetRetentionClassContext(...)
    @return A ref that represents the name and interval of the previous
            retention class within this context, or zero (0) if there are no more
            (previous) retention classes to return.
            NOTE: This return value (if not zero) must be released by calling 
                  FPRetentionClass_Close()
    @since 2.3
   */
  EXPORT FPRetentionClassRef  DECL FPRetentionClassContext_GetPreviousClass(const FPRetentionClassContextRef inContextRef);

  /**
    FPPool_GetRetentionClassContext(FPPoolRef inPool)
    @param inContextRef A FPRetentionClassContextRef as returned by the function 
                        FPPool_GetRetentionClassContext(...)
    @param inName The name of the retention class to retrieve from the passed in 
                  FPRetentionClassContextRef.
    @return A referance to the named retention class 
            or NULL if the requested name is not contained within the passed in 
            FPRetentionClassContextRef
            
            NOTE: This return value should be released by calling FPRetentionClass_Close()
    @since 2.3
   */
  EXPORT FPRetentionClassRef DECL FPRetentionClassContext_GetNamedClass(const FPRetentionClassContextRef inContextRef,
                                                                        const char* inName);
  /**
     @see FPRetentionClassContext_GetNamedClass(...)
     @since 2.3
   */
  EXPORT FPRetentionClassRef DECL FPRetentionClassContext_GetNamedClassW(const FPRetentionClassContextRef inContextRef,
                                                                         const wchar_t* inName);

  /**
     Uses UTF-8 encoding
     @see FPRetentionClassContext_GetNamedClass() 
     @since 2.3
   */
  EXPORT FPRetentionClassRef DECL FPRetentionClassContext_GetNamedClass8(const FPRetentionClassContextRef inContextRef,
                                                                         const char* inName);

  /**
     Uses UTF-16 encoding
     @see FPRetentionClassContext_GetNamedClass() 
     @since 2.3
   */
  EXPORT FPRetentionClassRef DECL FPRetentionClassContext_GetNamedClass16(const FPRetentionClassContextRef inContextRef,
                                                                          const FPChar16* inName);

  /**
     Uses UTF-32 encoding
     @see FPRetentionClassContext_GetNamedClass() 
     @since 2.3
   */
  EXPORT FPRetentionClassRef DECL FPRetentionClassContext_GetNamedClass32(const FPRetentionClassContextRef inContextRef,
                                                                          const FPChar32* inName);
  
  /**
    @param inClassRef The reference to the retention class to get the name from.
    @param outName The buffer where the name of the retention class that is 
                   associated with the passed ref is stored. 
                   
                   If the name is larger than what can fit in this buffer, it is 
                   truncated. The caller should check the value of the ioNameLen 
                   param on completion of this call to verify whether or not the 
                   buffer contains the full name. If not the caller should resize
                   their buffer and make this call again.
                   
                   If the passed ref does not have a retention class assigned to 
                   it, then this call will populate this buffer only with a NULL 
                   erminating character. 
    @param ioNameLen On input, this param should represent the size of the
                     outName buffer.
                     On output, this param is populated with the actual length 
                     of the retention class name that is retrieved.
    @since 2.3
   */
  EXPORT void DECL FPRetentionClass_GetName(const FPRetentionClassRef inClassRef,
                                            char* outName,
                                            FPInt* ioNameLen);

  /**
    @see FPRetentionClass_GetName(...)
    @since 2.3
   */
  EXPORT void DECL FPRetentionClass_GetNameW(const FPRetentionClassRef inClassRef,
                                             wchar_t* outName,
                                             FPInt* ioNameLen);

  /**
     Uses UTF-8 encoding
     @see FPRetentionClass_GetName() 
     @since 2.3
   */
  EXPORT void DECL FPRetentionClass_GetName8(const FPRetentionClassRef inClassRef,
                                             char* outName,
                                             FPInt* ioNameLen);

  /**
     Uses UTF-16 encoding
     @see FPRetentionClass_GetName() 
     @since 2.3
   */
  EXPORT void DECL FPRetentionClass_GetName16(const FPRetentionClassRef inClassRef,
                                              FPChar16* outName,
                                              FPInt* ioNameLen);

  /**
     Uses UTF-32 encoding
     @see FPRetentionClass_GetName() 
     @since 2.3
   */
  EXPORT void DECL FPRetentionClass_GetName32(const FPRetentionClassRef inClassRef,
                                              FPChar32* outName,
                                              FPInt* ioNameLen);

  /**
    @param inClassRef An FPRetentionClassRef as returned by a call to one of the
                      following functions:
                      1) FPRetentionClassContext_GetFirstClass(...)
                      2) FPRetentionClassContext_GetLastClass(...)
                      3) FPRetentionClassContext_GetNextClass(...)
                      4) FPRetentionClassContext_GetPreviousClass(...)
                      5) FPRetentionClassContext_GetNamedClass(...)
                      6) FPRetentionClassContext_GetNamedClassW(...)
                     
    @return The interval of the retention class that relates to the passed in ref.
    @since 2.3
   */
  EXPORT FPLong DECL FPRetentionClass_GetPeriod(const FPRetentionClassRef inClassRef);

  /**
    Releases the passed in ref.
    @param inClassRef A FPRetentionClassRef as returned by one of the getter calls
    @since 2.3
   */
  EXPORT void DECL FPRetentionClass_Close(const FPRetentionClassRef inClassRef);


  /**
    @param inClipRef The reference to the clip where the passed in retention class is set.
    @param inClassRef A ref to a retention class as returned by one of the following 
                      functions:
                      1) FPRetentionClassContext_GetFirstClass(...)
                      2) FPRetentionClassContext_GetLastClass(...)
                      3) FPRetentionClassContext_GetNextClass(...)
                      4) FPRetentionClassContext_GetPreviousClass(...)
                      5) FPRetentionClassContext_GetNamedClass(...)
                      6) FPRetentionClassContext_GetNamedClassW(...)
    @since 2.3
   */
  EXPORT void DECL FPClip_SetRetentionClass(const FPClipRef inClipRef, const FPRetentionClassRef inClassRef);

  /**
    @param inClipRef The reference to the clip which will have its retention class 
                     removed.
    @since 2.3
   */
  EXPORT void DECL FPClip_RemoveRetentionClass(const FPClipRef inClipRef);

  /**
    @param inClipRef The reference to the clip where the retention class is 
                     retrieved from.
    @param outClassName The buffer where the name of the retention class
                        that is associated with the passed in clip ref is
                        stored. If the name is larger than what can fit in this
                        buffer, it is truncated. The caller should check the
                        value of the ioNameLen param on completion of this call
                        to verify whether or not the buffer contains the full 
                        name. If not the caller should resize their buffer and
                       make this call again.
                        
                        If the passed ref does not have a retention class assigned to it, 
                        then this call will populate this buffer only with a NULL 
                        terminating character. 
    @param ioNameLen On input, this param should represent the size of the
                     outClassName buffer.
                     On output, this param is populated with the actual length 
                     of the retention class name including the NULL terminator.
    @since 2.3
   */
  EXPORT void DECL FPClip_GetRetentionClassName(const FPClipRef inClipRef, 
                                                char* outClassName, 
                                                FPInt* ioNameLen);

  /**
    @see FPClip_GetRetentionClassName()
    @since 2.3
   */
  EXPORT void DECL FPClip_GetRetentionClassNameW(const FPClipRef inClipRef, 
                                                 wchar_t* outClassName, 
                                                 FPInt* ioNameLen);

  /**
     Uses UTF-8 encoding
     @see FPClip_GetRetentionClassName() 
     @since 2.3
   */
  EXPORT void DECL FPClip_GetRetentionClassName8(const FPClipRef inClipRef, 
                                                 char* outClassName, 
                                                 FPInt* ioNameLen);

  /**
     Uses UTF-16 encoding
     @see FPClip_GetRetentionClassName() 
     @since 2.3
   */
  EXPORT void DECL FPClip_GetRetentionClassName16(const FPClipRef inClipRef, 
                                                  FPChar16* outClassName, 
                                                  FPInt* ioNameLen);

  /**
     Uses UTF-32 encoding
     @see FPClip_GetRetentionClassName() 
     @since 2.3
   */
  EXPORT void DECL FPClip_GetRetentionClassName32(const FPClipRef inClipRef, 
                                                  FPChar32* outClassName, 
                                                  FPInt* ioNameLen);

  /**
    @param inContextRef The FPRetentionClassContextRef as returned by a call to
                        FPPool_GetRetentionClassContext(FPPoolRef inPool)
    @param inClipRef The clip ref whose associated retention class will be validated.
    @return true if the retention class that is associate with the passed in clip ref
            is a class that is understood by the server.
            false otherwise.
    @since 2.3
   */
  EXPORT FPBool DECL FPClip_ValidateRetentionClass(const FPRetentionClassContextRef inContextRef,
                                                   const FPClipRef inClipRef);

  /**
    Convert the string representation of a content address into the 
    platform neutral canonical format. Canonical format is ideal for 
    storing the content address into databases.
    @param inClipID A content address in string format
    @param outClipID Storage for the content address in canonical format
    @since 3.0
   */
  EXPORT void DECL FPClipID_GetCanonicalFormat (const FPClipID inClipID, 
                                              FPCanonicalClipID outClipID);
  EXPORT void DECL FPClip_GetCanonicalFormat (const FPClipID inClipID, 
                                              FPCanonicalClipID outClipID);  

  /**
    Convert the canonical representation of a content address into the 
    platform specific string format. String format of a content address
    is ideal for sharing in email or in other text based media.
    @param inClipID A content address in canonical format
    @param outClipID Storage for the content address in string format
    @since 3.0
   */
  EXPORT void DECL FPClipID_GetStringFormat (const FPCanonicalClipID inClipID, 
                                           FPClipID outClipID);
  EXPORT void DECL FPClip_GetStringFormat (const FPCanonicalClipID inClipID, 
                                           FPClipID outClipID);


  /**
     Uses UTF-8 encoding
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForInput8 (const char *pFilePath, 
                                                        const char *pPerm, 
                                                        const long pBuffSize) ;
  /**
     Uses UTF-16 encoding
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForInput16 (const FPChar16 *pFilePath, 
                                                         const FPChar16 *pPerm, 
                                                         const long pBuffSize) ;
  /**
     Uses UTF-32 encoding
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForInput32 (const FPChar32 *pFilePath, 
                                                         const FPChar32 *pPerm, 
                                                         const long pBuffSize) ;
  /**
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForInputW (wchar_t *pFilePath, 
                                                        wchar_t *pPerm, 
                                                        const long pBuffSize) ;
  /**
     Uses UTF-8 encoding
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForOutput8 (const char *pFilePath, const char *pPerm) ;

  /**
     Uses UTF-16 encoding
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForOutput16 (const FPChar16 *pFilePath, const FPChar16 *pPerm) ;

  /**
     Uses UTF-32 encoding
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForOutput32 (const FPChar32 *pFilePath, const FPChar32 *pPerm) ;

  /**
     @see FPStream_CreateFileForInput() 
     @since 4.0
   */
  EXPORT FPStreamRef DECL FPStream_CreateFileForOutputW (const wchar_t *pFilePath, const wchar_t *pPerm) ;

  #if  __SASC__==650
 /* Functions to support long long under SAS/C 6.50 */

 /* Name:     FP_LL_CMP
  * Function: compare two FPLong Structs
  * Returns: 0 if equal
  *          1 if A>B
  *          -1 if B> A
 */
EXPORT int DECL FP_LL_CMP(FPLong A, FPLong B);

 /* Name:     FP_LL_HI
  * Function: return high order word from input FPLONG struct
 */
EXPORT unsigned int DECL FP_LL_HI (FPLong A);

 /* Name:     FP_LL_LO
  * Function: return low order word from input FPLONG struct
 */
EXPORT unsigned int DECL  FP_LL_LO (FPLong A);

 /* Name:     FP_LL_PRINT
    Function: print FPLong Structure
 */
EXPORT char * DECL FP_LL_PRINT(FPLong A);

/* Name: FP_LL_SET_HI
   Function: set the high order word of an FPLONG struct
 */
EXPORT void DECL FP_LL_SET_HI(FPLong *A, FPInt B);

/* Name: FP_LL_SET_LO
   Function: set the low order word of an FPLONG struct
 */
EXPORT void DECL FP_LL_SET_LO(FPLong *A, FPInt B);
#endif /* SASC650  only functions */

#ifdef __cplusplus
}
#endif

#ifdef __SASC__
#ifndef SDK_SASC_STATIC     /* NOT the case of static bind of SAS/C application */
/**
 * This SAS/C section must be the last code in FPAPI.h.  Only add
 * code above this point.
 */ 


/*****************************************************************************
 *
 * SAS/C on zOS only:
 * This header file defines a function pointer table for use by the SAS/C
 * dynamic loading facility. This permits, at the cost of some ugliness, the
 * stub program functions to be used without link-editing FPZstub to the
 * application. See SAS/C 7.00 Library Reference, Volume 2 Chapter 1.
 *
 *****************************************************************************/

struct FPftab
{
    FPPoolRef            (*FPPool_Open)(const char *pPoolAddr);                  //  001
    FPPoolRef            (*FPPool_OpenW)(const wchar_t *pPoolAddr);              //  002
    void                 (*FPPool_Close)(const FPPoolRef pPool);                 //  003
    void                 (*FPPool_SetIntOption)(const FPPoolRef pPool,           //  004
                             const char *pOptionName,                            
                             const FPInt pOptionValue);
    void                 (*FPPool_SetIntOptionW)(const FPPoolRef pPool,          //  005
                             const wchar_t *pOptionName,
                             const FPInt pOptionValue);
    FPInt                (*FPPool_GetIntOption)(const FPPoolRef pPool,           //  006
                             const char *pOptionName);
    FPInt                (*FPPool_GetIntOptionW)(const FPPoolRef pPool,          //  007
                             const wchar_t *pOptionName);
    void                 (*FPPool_SetGlobalOption)(const char *pOptionName,      //  008
                             const FPInt pOptionValue);
    void                 (*FPPool_SetGlobalOptionW)(const wchar_t *pOptionName,  //  009
                             const FPInt pOptionValue);
    FPInt                (*FPPool_GetGlobalOption)(const char *pOptionName);     //  010
    FPInt                (*FPPool_GetGlobalOptionW)(const wchar_t *pOptionName);  // 011
    FPInt                (*FPPool_GetLastError)(void);                            // 012
    void                 (*FPPool_GetLastErrorInfo)(FPErrorInfo *pErrorInfo);     // 013
    void                 (*_FPPool_GetPoolInfo)(const FPPoolRef pPool,            // 014
                             FPPoolInfo *pPoolInfo);
    void                 (*FPPool_GetCapability)(const FPPoolRef pPool,           // 015
                             const char *pCapabilityName,
                             const char *pCapabilityAttributeName,
                             char *pCapabilityValue,
                             FPInt *pCapabilityValueLen);
    void                 (*FPPool_GetCapabilityW)(const FPPoolRef pPool,          // 016
                             const wchar_t *pCapabilityName,
                             const wchar_t *pCapabilityAttributeName,
                             wchar_t *pCapabilityValue,
                             FPInt *pCapabilityValueLen);
    void                 (*FPPool_GetClusterTime)(const FPPoolRef pPool,          // 017
                             char *pClusterTime,
                             FPInt *pClusterTimeLen);
    void                 (*FPPool_GetComponentVersion)(const FPInt pComponent,    // 018
                             char *pVersion,
                             FPInt *pVersionLen);
    void                 (*FPPool_GetComponentVersionW)(const FPInt pComponent,   // 019
                             wchar_t *pVersion,
                             FPInt  *pVersionLen);
    FPClipRef            (*FPClip_Create)(const FPPoolRef pPool,                  // 020
                             const char *pName);
    FPClipRef            (*FPClip_CreateW)(const FPPoolRef pPool,                 // 021
                             const wchar_t *pName);
    FPClipRef            (*FPClip_Open)(const FPPoolRef pPool,                    // 022
                             const FPClipID pClipID,
                             const FPInt pOpenMode);
    void                 (*FPClip_Close)(const FPClipRef pClip);                  // 023
    FPPoolRef            (*FPClip_GetPoolRef)(const FPClipRef pClip);             // 024
    FPBool               (*FPClip_Exists)(const FPPoolRef pPool,                  // 025
                             const FPClipID pClipID);
    void                 (*FPClip_Delete)(const FPPoolRef pPool,                  // 026
                             const FPClipID pClipID);
    void                 (*FPClip_AuditedDelete)(const FPPoolRef pPool,           // 027
                             const FPClipID pClipID,
                             const char *inReason,
                             const FPLong inOptions);
    void                 (*FPClip_AuditedDeleteW)(const FPPoolRef pPool,          // 028
                             const FPClipID pClipID,
                             const wchar_t *inReason,
                             const FPLong inOptions);
    void                 (*FPClip_Purge)(const FPPoolRef pPool,                   // 029
                             const FPClipID pClipID);
    FPTagRef             (*FPClip_GetTopTag)(const FPClipRef pClip);              // 030
    FPInt                (*FPClip_GetNumBlobs)(const FPClipRef pClip);            // 031
    FPInt                (*FPClip_GetNumTags)(const FPClipRef pClip);             // 032
    FPLong               (*FPClip_GetTotalSize)(const FPClipRef pClip);           // 033
    void                 (*FPClip_GetClipID)(const FPClipRef pClip,               // 034
                             FPClipID pClipID);
    void                 (*FPClip_SetName)(const FPClipRef pClip,                 // 035
                             const char *inClipName);
    void                 (*FPClip_SetNameW)(const FPClipRef pClip,                // 036
                             const wchar_t *inClipName);
    void                 (*FPClip_GetName)(const FPClipRef pClip,                 // 037
                             char *pName,
                             FPInt *pNameLen);
    void                 (*FPClip_GetNameW)(const FPClipRef pClip,                // 038
                             wchar_t *pName,
                             FPInt *pNameLen);
    void                 (*FPClip_GetCreationDate)(const FPClipRef pClip,         // 039
                             char *pDate,
                             FPInt *pDateLen);
    void                 (*FPClip_SetRetentionPeriod)(const FPClipRef pClip,      // 040
                             const FPLong pRetentionSecs);
    FPLong               (*FPClip_GetRetentionPeriod)(const FPClipRef pClip);     // 041
    FPBool               (*FPClip_IsModified)(const FPClipRef pClip);             // 042
    FPTagRef             (*FPClip_FetchNext)(const FPClipRef pClip);              // 043
    void                 (*FPClip_Write)(const FPClipRef pClip,                   // 044
                             FPClipID pClipID);
    void                 (*FPClip_RawRead)(const FPClipRef pClip,                 // 045
                             const FPStreamRef pStream);
    FPClipRef            (*FPClip_RawOpen)(const FPPoolRef pPool,                 // 046
                             const FPClipID pClipID,
                             const FPStreamRef pStream,
                             const FPLong pOptions);
    void                 (*FPClip_SetDescriptionAttribute)(const FPClipRef inClip, // 047
                             const char *inAttrName,
                             const char *inAttrValue);
    void                 (*FPClip_SetDescriptionAttributeW)(const FPClipRef inClip, // 048
                             const wchar_t *inAttrName,
                             const wchar_t *inAttrValue);
    void                 (*FPClip_RemoveDescriptionAttribute)(const FPClipRef inClip, // 049
                             const char *inAttrName);
    void                 (*FPClip_RemoveDescriptionAttributeW)(const FPClipRef inClip, // 050
                             const wchar_t *inAttrName);
    void                 (*FPClip_GetDescriptionAttribute)(const FPClipRef inClip, // 051
                             const char* inAttrName,
                             char* outAttrValue,
                             FPInt* ioAttrValueLen);
    void                 (*FPClip_GetDescriptionAttributeW)(const FPClipRef inClip, // 052
                             const wchar_t* inAttrName,
                             wchar_t* outAttrValue,
                             FPInt* ioAttrValueLen);
    void                 (*FPClip_GetDescriptionAttributeIndex)(const FPClipRef inClip, // 053
                             const FPInt inIndex,
                             char* outAttrName,
                             FPInt* ioAttrNameLen,
                             char* outAttrValue,
                             FPInt* ioAttrValueLen);
    void                 (*FPClip_GetDescriptionAttributeIndexW)(const FPClipRef inClip, // 054
                             const FPInt inIndex,
                             wchar_t* outAttrName,
                             FPInt* ioAttrNameLen,
                             wchar_t* outAttrValue,
                             FPInt* ioAttrValueLen);
    FPInt                (*FPClip_GetNumDescriptionAttributes)(const FPClipRef inClip); // 055 
    FPTagRef             (*FPTag_Create)(const FPTagRef pParent,                        // 056
                             const char *pName);
    FPTagRef             (*FPTag_CreateW)(const FPTagRef pParent,                       // 057
                             const wchar_t *pName);
    void                 (*FPTag_Close)(const FPTagRef pTag);                           // 058
    FPTagRef             (*FPTag_Copy)(const FPTagRef pTag,                             // 059
                             const FPTagRef pNewParent,
                             const FPInt pOptions);
    FPClipRef            (*FPTag_GetClipRef)(const FPTagRef pTag);                      // 060
    FPTagRef             (*FPTag_GetSibling)(const FPTagRef pTag);                      // 061
    FPTagRef             (*FPTag_GetPrevSibling)(const FPTagRef pTag);                  // 062
    FPTagRef             (*FPTag_GetFirstChild)(const FPTagRef pTag);                   // 063
    FPTagRef             (*FPTag_GetParent)(const FPTagRef pTag);                       // 064
    void                 (*FPTag_Delete)(const FPTagRef pTag);                          // 065
    void                 (*FPTag_GetTagName)(const FPTagRef pTag,                       // 066
                             char *pName, FPInt *pNameLen);
    void                 (*FPTag_GetTagNameW)(const FPTagRef pTag,                      // 067
                             wchar_t *pName,
                             FPInt *pNameLen);
    void                 (*FPTag_SetStringAttribute)(const FPTagRef pTag,               // 068
                             const char *pAttrName,
                             const char *pAttrValue);
    void                 (*FPTag_SetStringAttributeW)(const FPTagRef pTag,              // 069
                             const wchar_t *pAttrName,
                             const wchar_t *pAttrValue);
    void                 (*FPTag_SetLongAttribute)(const FPTagRef pTag,                 // 070
                             const char *pAttrName,
                             const FPLong pAttrValue);
    void                 (*FPTag_SetLongAttributeW)(const FPTagRef pTag,                // 071
                             const wchar_t *pAttrName,
                             const FPLong pAttrValue);
    void                 (*FPTag_SetBoolAttribute)(const FPTagRef pTag,                 // 072
                             const char *pAttrName,
                             const FPBool pAttrValue);
    void                 (*FPTag_SetBoolAttributeW)(const FPTagRef pTag,                // 073
                             const wchar_t *pAttrName,
                             const FPBool pAttrValue);
    void                 (*FPTag_GetStringAttribute)(const FPTagRef pTag,               // 074
                             const char *pAttrName,
                             char *pAttrValue,
                             FPInt *pAttrValueLen);
    void                 (*FPTag_GetStringAttributeW)(const FPTagRef pTag,              // 075
                             const wchar_t *pAttrName,
                             wchar_t *pAttrValue,
                             FPInt *pAttrValueLen);
    FPLong               (*FPTag_GetLongAttribute)(const FPTagRef pTag,                 // 076
                             const char *pAttrName);
    FPLong               (*FPTag_GetLongAttributeW)(const FPTagRef pTag,                // 077
                             const wchar_t *pAttrName);
    FPBool               (*FPTag_GetBoolAttribute)(const FPTagRef pTag,                 // 078
                             const char *pAttrName);
    FPBool               (*FPTag_GetBoolAttributeW)(const FPTagRef pTag,                // 079
                             const wchar_t *pAttrName);
    void                 (*FPTag_RemoveAttribute)(const FPTagRef pTag,                  // 080
                             const char *pAttrName);
    void                 (*FPTag_RemoveAttributeW)(const FPTagRef pTag,                 // 081
                             const wchar_t *pAttrName);                                 
    FPInt                (*FPTag_GetNumAttributes)(const FPTagRef pTag);                // 082
    void                 (*FPTag_GetIndexAttribute)(const FPTagRef pTag,                // 083
                             const FPInt pIndex,
                             char *pAttrName,
                             FPInt *pAttrNameLen,
                             char *pAttrValue,
                             FPInt *pAttrValueLen);
    void                 (*FPTag_GetIndexAttributeW)(const FPTagRef pTag,               // 084
                             const FPInt pIndex,
                             wchar_t *pAttrName,
                             FPInt *pAttrNameLen,
                             wchar_t *pAttrValue,
                             FPInt *pAttrValueLen);
    FPLong               (*FPTag_GetBlobSize)(const FPTagRef pTag);                     // 085
    void                 (*FPTag_BlobWrite)(const FPTagRef pTag,                        // 086
                             const FPStreamRef pStream,
                             const FPLong pOptions);
    void                 (*FPTag_BlobRead)(const FPTagRef pTag,                         // 087
                             const FPStreamRef pStream,
                             const FPLong pOptions);
    void                 (*FPTag_BlobReadPartial)(const FPTagRef pTag,                  // 088
                             const FPStreamRef pStream,
                             const FPLong pOffset,
                             const FPLong pReadLength,
                             const FPLong pOptions);
    void                 (*FPTag_BlobPurge)(const FPTagRef pTag);                       // 089
    FPInt                (*FPTag_BlobExists)(const FPTagRef pTag);                      // 090
    FPQueryExpressionRef (*FPQueryExpression_Create)(void);                             // 091
    void                 (*FPQueryExpression_Close)(const FPQueryExpressionRef inRef);        // 092
    void                 (*FPQueryExpression_SetStartTime)(const FPQueryExpressionRef inRef,  // 093
                             const FPLong inTime);
    void                 (*FPQueryExpression_SetEndTime)(const FPQueryExpressionRef inRef,    // 094
                             const FPLong inTime);
    void                 (*FPQueryExpression_SetType)(const FPQueryExpressionRef inRef,       // 095
                             const FPInt inType);
    FPLong               (*FPQueryExpression_GetStartTime)(const FPQueryExpressionRef inRef);  // 096
    FPLong               (*FPQueryExpression_GetEndTime)(const FPQueryExpressionRef inRef);    // 097
    FPInt                (*FPQueryExpression_GetType)(const FPQueryExpressionRef inRef);       // 098

    void                 (*FPQueryExpression_SelectField)(const FPQueryExpressionRef inRef,    // 099
                                                         const char * inFieldName);

    void                 (*FPQueryExpression_SelectFieldW)(const FPQueryExpressionRef inRef,   // 100
                                                         const wchar_t* inFieldName);

    void                 (*FPQueryExpression_DeselectField)(const FPQueryExpressionRef inRef,  // 101
                                                          const char* inFieldName);

    void                 (*FPQueryExpression_DeselectFieldW)(const FPQueryExpressionRef inRef,  // 102
                                                           const wchar_t* inFieldName);

    FPBool               (*FPQueryExpression_IsFieldSelected)(const FPQueryExpressionRef inRef, // 103
                                                              const char * inFieldName); 

    FPBool               (*FPQueryExpression_IsFieldSelectedW)(const FPQueryExpressionRef inRef, // 104
                                                          const char * inFieldName);
  

    FPPoolQueryRef       (*FPPoolQuery_Open)(const FPPoolRef inPoolRef,                          //  105   
                             FPQueryExpressionRef inQueryExpressionRef);
    void                 (*FPPoolQuery_Close)(const FPPoolQueryRef inPoolQueryRef);              //  106
    FPPoolRef            (*FPPoolQuery_GetPoolRef)(const FPPoolQueryRef inPoolQueryRef);         //  107
    FPQueryResultRef     (*FPPoolQuery_FetchResult)(const FPPoolQueryRef inPoolQueryRef,         //  108
                             const FPInt inTimeout);


    void                 (*FPQueryResult_Close)(const FPQueryResultRef inQueryResultRef);        //  109
    void                 (*FPQueryResult_GetClipID)(const FPQueryResultRef inQueryResultRef,     //  110
                             FPClipID outClipID);
    FPLong               (*FPQueryResult_GetTimestamp)(const FPQueryResultRef inQueryResultRef); //  111

    
    void                 (*FPQueryResult_GetField)(const FPQueryResultRef inQueryResult,         //  112 
                                                   const char *inAttrName,
                                                   char * outAttrName,
                                                   FPInt *ioAttrValueLen);
                    
    void                 (*FPQueryResult_GetFieldW)(const FPQueryResultRef inQueryResult,        //  113
                                                   const wchar_t *inAttrName,
                                                   wchar_t * outAttrName,
                                                   FPInt *ioAttrValueLen);


    FPInt                (*FPQueryResult_GetResultCode)(const FPQueryResultRef inQueryResultRef);  // 114
    FPInt                (*FPQueryResult_GetType)(const FPQueryResultRef inQueryResultRef);        // 115

    FPQueryRef           (*FPQuery_Open)(const FPPoolRef pPool,                                    // 116
                             const FPLong pStartTime,
                             const FPLong pStopTime,
                             const char *pReserved);
    FPQueryRef           (*FPQuery_OpenW)(const FPPoolRef pPool,                                   // 117
                             const FPLong pStartTime,
                             const FPLong pStopTime,
                             const wchar_t *pReserved);
    FPInt                (*FPQuery_FetchResult)(const FPQueryRef pQuery,                           // 118
                             FPClipID pResultClip,
                             FPLong *pTimestamp,
                             const FPInt pTimeout);
    void                 (*FPQuery_Close)(const FPQueryRef pQuery);                                // 119 
    FPPoolRef            (*FPQuery_GetPoolRef)(const FPQueryRef pQuery);                           // 120
    FPMonitorRef         (*FPMonitor_Open)(const char *inClusterAddress);                          // 121
    FPMonitorRef         (*FPMonitor_OpenW)(const wchar_t *inClusterAddress);                      // 122
    void                 (*FPMonitor_Close)(const FPMonitorRef inMonitor);                         // 123
    void                 (*FPMonitor_GetDiscovery)(const FPMonitorRef inMonitor,                   // 124
                             char *outData,
                             FPInt *ioDataLen);
    void                 (*FPMonitor_GetDiscoveryStream)(const FPMonitorRef inMonitor,             // 125
                             const FPStreamRef inStream);
    void                 (*FPMonitor_GetAllStatistics)(const FPMonitorRef inMonitor,               // 126
                             char *outData,
                             FPInt *ioDataLen);
    void                 (*FPMonitor_GetAllStatisticsStream)(const FPMonitorRef inMonitor,         // 127
                             const FPStreamRef inStream);
    FPEventCallbackRef   (*FPEventCallback_RegisterForAllEvents)(const FPMonitorRef inMonitor,     // 128
                             const FPStreamRef inStream);
    void                 (*FPEventCallback_Close)(const FPEventCallbackRef inRegisterRef);         // 129

    void  (* FPPool_SetClipID) (const FPPoolRef inPool,                                            // 130
                                   const FPClipID inContentAddress);

    void  (*  FPPool_GetClipID) (const FPPoolRef inPool,                                           // 131
                                  FPClipID outContentAddress);
   
 

    FPRetentionClassContextRef (*FPPool_GetRetentionClassContext)                                  // 132
                               (const FPPoolRef inPoolRef); 

    void (*FPRetentionClassContext_Close)                                                          // 133
     (const FPRetentionClassContextRef inContextRef);          

    FPInt (*FPRetentionClassContext_GetNumClasses)                                                 // 134
           (const FPRetentionClassContextRef inContextRef);

    FPRetentionClassRef (*FPRetentionClassContext_GetFirstClass)                                   // 135
           (const FPRetentionClassContextRef inContextRef);
       
    FPRetentionClassRef (*FPRetentionClassContext_GetLastClass)                                    // 136
           (const FPRetentionClassContextRef inContextRef);

    FPRetentionClassRef (*FPRetentionClassContext_GetNextClass)                                    // 137
          (const FPRetentionClassContextRef inContextRef);

    FPRetentionClassRef  ( *FPRetentionClassContext_GetPreviousClass)                              // 138
    (const FPRetentionClassContextRef inContextRef);

    FPRetentionClassRef (*FPRetentionClassContext_GetNamedClass)                                   // 139
          (const FPRetentionClassContextRef inContextRef);
                                                                                                   
    FPRetentionClassRef (*FPRetentionClassContext_GetNamedClassW)                                  // 140
         (const FPRetentionClassContextRef inContextRef);

    void (*FPRetentionClass_GetName)                                                        // 141
        (const FPRetentionClassRef inClassRef,
         char *outName,
         FPInt * ioNameLen);

    void (*FPRetentionClass_GetNameW)                                                       // 142 
       (const FPRetentionClassRef inClassRef,
        wchar_t * outName,
        FPInt * ioNameLen);
                                                                                                   // 143
    FPLong (*FPRetentionClass_GetPeriod)
            (const FPRetentionClassRef inClassRef);
                                                                                                   
    void   (*FPRetentionClass_Close)                                                               // 144
            (const FPRetentionClassRef inClassRef);

    void (* FPClip_SetRetentionClass)                                                              // 145
     (const FPClipRef inClipRef, const FPRetentionClassRef inClassRef);

     void (* FPClip_RemoveRetentionClass)(const FPClipRef inClipRef);                              // 146

     void (* FPClip_GetRetentionClassName)(const FPClipRef inClipRef,                              // 147
                                            char * outClassName,
                                            FPInt * ioNameLen);
                                                                                                   // 148
     void (* FPClip_GetRetentionClassNameW)(const FPClipRef inClipRef,
                                            wchar_t * outClassName,
                                            FPInt * ioNameLen);

     void ( *FPClip_ValidateRetentionClass)(const FPRetentionClassContextRef inContextRef,         // 149
                                            const FPClipRef inClipRef); 

     void ( *FPClip_GetCanonicalFormat)(const FPClipID inClipID,                                   // 150
                                       FPCanonicalClipID outClipID);

     void ( *FPClip_GetStringFormat)(const FPCanonicalClipID inClipID,                             // 151
                                    FPClipID outClipID);
       
                                   

    /* start of i/o functions */


    FPStreamRef          (*FPStream_CreateGenericStream)(                                           // 152
                             const FPStreamProc pPrepareBufferProc,
                             const FPStreamProc pCompleteProc,
                             const FPStreamProc pSetMarkerProc,
                             const FPStreamProc pResetMarkerProc,
                             const FPStreamProc pCloseProc,
                             const void        *pUserData);
    void                 (*FPStream_Close)(const FPStreamRef pStream);                               // 153
    FPStreamInfo*        (*FPStream_GetInfo)(const FPStreamRef pStream);                             // 154
    FPStreamInfo*        (*FPStream_PrepareBuffer)(const FPStreamRef pStream);                       // 155
    FPStreamInfo*        (*FPStream_Complete)(const FPStreamRef pStream);                            // 156
    void                 (*FPStream_SetMark)(const FPStreamRef pStream);                             // 157
    void                 (*FPStream_ResetMark)(const FPStreamRef pStream);                           // 158
    FPStreamRef          (*FPStream_CreateFileForInput)(const char *pFilePath,                       // 159
                             const char *pPerm, const long pBuffSize) ;                              
    FPStreamRef          (*FPStream_CreateFileForOutput)(const char *pFilePath,                      // 160 
                             const char *pPerm) ;
    FPStreamRef          (*FPStream_CreateBufferForInput)(char *pBuffer,                             // 161
                             const unsigned long pBuffLen) ;
    FPStreamRef          (*FPStream_CreateBufferForOutput)(char *pBuffer,                            // 162
                             const unsigned long pBuffLen) ;
    FPStreamRef          (*FPStream_CreateToStdio)(void) ;                                           // 163
    FPStreamRef          (*FPStream_CreateToNull)(void) ;                                            // 164
    FPStreamRef          (*FPStream_CreateTemporaryFile)(const long pMemBuffSize) ;                  // 165
    FPStreamRef          (*FPStream_CreateWithFile)(char *pFilePath,                                 // 166
                             char *pPerm) ;
    FPStreamRef          (*FPStream_CreateWithBuffer)(char *pBuffer,                                 // 167
                             unsigned long pBuffLen) ;
    long                 (*FPStream_Read)(FPStreamRef pStream,                                       // 168
                             void *pBuffer,
                             long pBuffSize) ;
    long                 (*FPStream_Write)(FPStreamRef pStream,                                      // 169
                             void *pBuffer,
                             long pBuffSize) ;
    void                 (*FPStream_SetMarker)(FPStreamRef pStream,                                  // 170 
                             FPLong pOffset) ;
    FPLong               (*FPStream_GetMarker)(FPStreamRef pStream) ;                                // 171
#if  __SASC__==650
    int           (*FP_LL_CMP)(FPLong A, FPLong B);                                                  // 172 
    unsigned int  (*FP_LL_HI)(FPLong A);                                                             // 173
    unsigned int  (*FP_LL_LO)(FPLong A);                                                             // 174
    char *        (*FP_LL_PRINT)(FPLong A);                                                          // 175
    void          (*FP_LL_SET_HI)(FPLong *A, FPInt B);                                               // 176
    void          (*FP_LL_SET_LO)(FPLong *A, FPInt B);                                               // 177
#endif /* SASC650  only functions */

};

typedef struct FPftab * FP_PFNTAB;

#ifdef  FPPool_GetPoolInfo
#undef  FPPool_GetPoolInfo
#endif

#ifdef  FPTag_GetPoolRef
#undef  FPTag_GetPoolRef
#endif


#define FPTAG_GETPOOLREF(pFn,pTag) (*pFn->FPClip_GetPoolRef)((*pFn->FPTag_GetClipRef)(pTag))

#define FPPOOL_GETPOOLINFO(pFn,pPool,pInfoPtr) {          \
    if (pInfoPtr)                                         \
    {                                                     \
        (pInfoPtr)->poolInfoVersion=FPPOOL_INFO_VERSION ; \
    }                                                     \
    (*pFn->_FPPool_GetPoolInfo)(pPool,pInfoPtr); }

/**
 * This SAS/C section must be the last code in FPAPI.h.  Do not add any code
 * below this point.
 */ 

#endif /* not SDK_SASC_STATIC */
#endif /* __SASC__ */
#endif /* __FPAPI__ */

