
/*****************************************************************************
 *
 * Copyright (c) 2001-2005 EMC Corporation
 * Unpublished - All Rights Reserved
 *
 * FPStream.h
 *
 * FPLibrary Header File Build Version 3.3.718
 *
 * This headerfile contains the intellectual property of EMC Corporation
 * or is licensed to EMC Corporation from third parties. Use of this headerfile 
 * and the intellectual property contained therein is expressly limited to the 
 * terms and conditions of the License Agreement.
 *
 * EMC2  , EMC, Symmetrix, Celerra, CLARiiON, CLARalert, DG, E-Infostructure, 
 * HighRoad, Navisphere, PowerPath, ResourcePak, SnapView/IP, SRDF, VisualSAN, 
 * where information lives, and The EMC Effect are registered trademarks and EMC 
 * Automated Networked Storage, EMC ControlCenter, EMC Developers Program, EMC 
 * Enterprise Storage, EMC Enterprise Storage Network, EMC OnCourse, EMC Proven, 
 * EMC Snap, Access Logix, AutoAdvice, Automated Resource Manager, AutoSwap, 
 * AVALONidm, C-Clip, CacheStorm, Celerra Replicator, Centera, CentraStar, 
 * CLARevent, Connectrix, CopyCross, CopyPoint, CrosStor, Direct Matrix, Direct 
 * Matrix Architecture, EDM, E-Lab, Enginuity, FarPoint, FLARE, GeoSpan, InfoMover, 
 * MirrorView, NetWin, OnAlert, OpenScale, Powerlink, PowerVolume, RepliCare, 
 * SafeLine, SAN Architect, SAN Copy, SAN Manager, SDMS, SnapSure, SnapView, 
 * StorageScope, SupportMate, SymmAPI, SymmEnabler, Symmetrix DMX, TimeFinder, 
 * Universal Data Tone, and VisualSRM are trademarks of EMC Corporation. All other 
 * trademarks used herein are the property of their respective owners.
 *
 * ---------------------------------------------------------------------------
 * Copyright ) 1991-2, RSA Data Security, Inc. Created 1991. 
 * All rights reserved. 
 * License to copy and use this software is granted provided 
 * that it is identified as the "RSA Data Security, Inc. MD5 
 * Message-Digest Algorithm" in all material mentioning or 
 * referencing this software or this function. 
 * RSA Data Security, Inc. makes no representations concerning 
 * either the merchantability of this software or the 
 * suitability of this software for any particular purpose. It 
 * is provided "as is" without express or implied warranty of any kind. 
 *
 * These notices must be retained in any 
 * copies of any part of this documentation and/or software.
 *
 * ---------------------------------------------------------------------------
 * Copyright and Licensing Information for ACE(TM)
 * http://www.cs.wustl.edu/~schmidt/ACE-copying.html
 *
 *****************************************************************************/

#ifndef __FPSTREAM__
#define __FPSTREAM__

#include "FPGenericStream.h"

/**
  @file FPStream.h
   FPLibrary Streams header file.
   This file contains methods to create generalized data streams. They are used to input and
   output data to the Centera server.
*/
#include <FPTypes.h>
#if !defined(__SASC__)
#include <wchar.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

  /**
     @addtogroup Stream Streaming functions
     @{

     Streams are generalized input/output channels similar to the
     HANDLE mechanism used in the Win32 API for files, the C++
     iostream functionality, the C standard I/O FILE routines, or the
     Java InputStream/OutputStream facility.

     All bulk data movement in the API is achieved by first
     associating a stream with a data sink or source (for example, a
     file, an in-memory buffer, the standard output channel) and then
     performing operations on that stream.  There are several
     functions that allow you to create a stream.
     
     The API stream functions implement streams generically. When creating 
     a stream, use method pointers to indicate how subsequent stream 
     functions should handle the stream.
  */

/** @name Stream Creation Functions
    @{ */
    
/**
    The function creates a stream to read from a file and returns a
    reference to the created stream. The stream behaves like a file and
    depending on the given permission (pPerm), you can use the stream
    with most of the stream handling functions (see the 
    API Reference Guide for more information).    
        
    @param pFilePath    
            pFilePath is the buffer that contains the path name of the file for
            which the stream must be created.
            
    @param pPerm
            pPerm is the buffer that contains the open permission for the
            file.You can use the following permission:
            - "rb" open the given file for reading. If the file does not exist or the
            system cannot find the file, the function will return an error.
                        
    @param pBuffSize
            pBuffSize defines the size of the buffer (in bytes) that is used when
            reading the file. This represents the amount of data to retrieved/cached 
            from the file into memory each time the file is touched. The value has 
            to be greater than 0.
            
    @return A reference to the created stream, or zero if an error
     occurs.
    
    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateFileForInput (const char *pFilePath, 
                                                     const char *pPerm, 
                                                     const long pBuffSize) ;


/**
    The function creates a stream to write to a file and returns a reference
    to the created stream. The stream behaves like a file and depending
    on the given permission (pPerm), you can use the stream with all
    stream handling functions (see the API Reference Guide for more information).

    @param pFilePath
            pFilePath is the buffer that contains the path name of the file for
            which the stream must be created.

    @param pPerm
            pPerm is the buffer that contains the open permission for the file,
            for writing this is usually wb. You can use one of the following
            permissions:
            - "wb" open the given file for writing. The function overwrites
            existing content of the file.
            - "ab" open the file for writing at the end of the file. If the file does
            not exist, the function will create the file.
            - "rb+" open the given file for both reading and writing. If the file
            does not exist or the system cannot find the file, the function will
            return an error.
            - "wb+" open the given file for both reading and writing. If the given
            file exists, the function overwrites its content.
            - "ab+" open the given file for reading and writing at the end of the
            file. If the file does not exist, the function will create the file. 
 
    @return A reference to the created stream, or zero if an error
     occurs.
              
    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateFileForOutput (const char *pFilePath, const char *pPerm) ;

/**
    The function creates a stream to read from a memory buffer and
    returns a reference to the created stream.

    @param pBuffer  pBuffer is the memory buffer containing the data for the stream.
    @param pBuffLen pBuffLen is the buffer length (in bytes) of pBuffer.
    @return A reference to the created stream, or zero if an error
     occurs.

    @since 1.1
*/

/**
    The function creates a stream to read from a file and returns a
    reference to the created stream. The stream behaves like a file and
    depending on the given permission (pPerm), you can use the stream
    with most of the stream handling functions (see the 
    API Reference Guide for more information).    
        
    @param pFilePath    
            pFilePath is the buffer that contains the path name of the file for
            which the stream must be created.
            
    @param pPerm
            pPerm is the buffer that contains the open permission for the
            file.You can use the following permission:
            - "rb" open the given file for reading. If the file does not exist or the
            system cannot find the file, the function will return an error.

    @param pBuffSize
            pBuffSize defines the size of the buffer (in bytes) that is used when
            reading the file. This represents the amount of data to retrieved/cached 
            from the file into memory each time the file is touched. The value has to 
            be greater than 0.
                        
    @param pOffset
            pOffset is the offset into the file (in bytes) to start the read from.
 
    @param pLength
            pLength is the amount of data (in bytes) from the offset to transfer in this
            stream. Use "FP_STREAM_EOF" (-1) to request all remaining data in the file from the
            given offset.
  
    @return A reference to the created stream, or zero if an error
     occurs.
    
    @since 3.2
*/

EXPORT FPStreamRef DECL FPStream_CreatePartialFileForInput (const char *pFilePath, 
                                                            const char *pPerm,
                                                            const FPLong pBuffSize,
                                                            const FPLong pOffset, 
                                                            const FPLong pLength) ;
/**
 Uses UTF-8 encoding
 @see FPStream_CreatePartialFileForInput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForInput8 (const char *pFilePath, 
                                                           const char *pPerm,
                                                           const FPLong pBuffSize,
                                                           const FPLong pOffset, 
                                                           const FPLong pLength) ;
/**
 Uses UTF-16 encoding
 @see FPStream_CreatePartialFileForInput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForInput16 (const FPChar16 *pFilePath, 
                                                            const FPChar16 *pPerm,
                                                            const FPLong pBuffSize,
                                                            const FPLong pOffset, 
                                                            const FPLong pLength) ;
/**
 Uses UTF-32 encoding
 @see FPStream_CreatePartialFileForInput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForInput32 (const FPChar32 *pFilePath, 
                                                            const FPChar32 *pPerm,
                                                            const FPLong pBuffSize,
                                                            const FPLong pOffset, 
                                                            const FPLong pLength) ;
/**
 Uses wide characters
 @see FPStream_CreatePartialFileForInput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForInputW (const wchar_t *pFilePath, 
                                                           const wchar_t *pPerm,
                                                           const FPLong pBuffSize,
                                                           const FPLong pOffset, 
                                                           const FPLong pLength) ;

/**
    The function creates a stream to write to a file and returns a
    reference to the created stream. The stream behaves like a file and
    depending on the given permission (pPerm), you can use the stream
    with most of the stream handling functions (see the 
    API Reference Guide for more information).    
        
    NOTE: This call is not thread safe when writing to the same file from 
          multiple threads. 
    
          If multiple streams are created which open the same file for writing, an 
          FP_FILESYS_ERR will be returned on stream creation for all but the first 
          stream (until the initial stream has been closed). Only 1 stream may 
          write to a given file at a time.

    @param pFilePath    
            pFilePath is the buffer that contains the path name of the file for
            which the stream must be created. Errors in the filesystem will be 
            reported (as FP_FILESYS_ERR) and a NULL FPStreamRef will be returned.
            
    @param pPerm
            pPerm is the buffer that contains the open permission for the file.
            For partial writes, this is usually "ab+". You can use one of the 
            following permissions:
            - "wb" open the given file for writing. The function overwrites
            existing content of the file.
            - "ab" open the file for writing at the end of the file. If the file does
            not exist, the function will create the file.
            - "rb+" open the given file for both reading and writing. If the file
            does not exist or the system cannot find the file, the function will
            return an error. This option should not be used unless an output file 
            already exists.
            - "wb+" open the given file for both reading and writing. If the given
            file exists, the function overwrites its content.
            - "ab+" open the given file for reading and writing and seeks to the end 
            of the file. If the file does not exist, the function will create the file. 

    @param pBuffSize
            pBuffSize defines the size of the buffer (in bytes) that is used when
            reading the file. This represents the amount of data to retrieved/cached 
            from the data source into memory. This value has to be greater than 0.
                        
    @param pOffset
            pOffset is the offset into the file (in bytes) in which to begin the write.
 
    @param pLength
            pLength describes the maximum amount of data this stream will accept.
            A value of "-1" indicates that this stream will accept data up to the value
            specified in the pMaxFileLength. If the pMaxFileLength is out of bounds 
            (ie. !=-1 AND <-1 or >=(pFileLength-pOffset)) and error (FP_PARAM_ERR) will be 
            generated and a NULL FPStreamRef will be returned.

    @param pMaxFileLength
            pMaxFileLength describes the maximum overall amount of data that can be written to 
            the underlying file, and thus that the stream will access. This defines the 
            maximum size a file may be allowed to grow. If the file size on disk exceeds 
            this size, the file will be truncated
            A value of "-1" indicates that there is no overall max data length.
  
    @return A reference to the created stream, or zero if an error
     occurs.
    
    @since 3.2
*/

EXPORT FPStreamRef DECL FPStream_CreatePartialFileForOutput (const char *pFilePath, 
                                                             const char *pPerm,
                                                             const FPLong pBuffSize,
                                                             const FPLong pOffset, 
                                                             const FPLong pLength,
                                                             const FPLong pMaxFileLength) ;
/**
 Uses UTF-8 encoding
 @see FPStream_CreatePartialFileForOutput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForOutput8 (const char *pFilePath, 
                                                              const char *pPerm,
                                                              const FPLong pBuffSize,
                                                              const FPLong pOffset, 
                                                              const FPLong pLength,
                                                              const FPLong pFileLength) ;
/**
 Uses UTF-16 encoding
 @see FPStream_CreatePartialFileForOutput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForOutput16 (const FPChar16 *pFilePath, 
                                                               const FPChar16 *pPerm,
                                                               const FPLong pBuffSize,
                                                               const FPLong pOffset, 
                                                               const FPLong pLength,
                                                               const FPLong pFileLength) ;
/**
 Uses UTF-32 encoding
 @see FPStream_CreatePartialFileForOutput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForOutput32 (const FPChar32 *pFilePath, 
                                                               const FPChar32 *pPerm,
                                                               const FPLong pBuffSize,
                                                               const FPLong pOffset, 
                                                               const FPLong pLength,
                                                               const FPLong pFileLength) ;
/**
 Uses wide characters
 @see FPStream_CreatePartialFileForOutput() 
 @since 3.2
*/
EXPORT FPStreamRef DECL FPStream_CreatePartialFileForOutputW (const wchar_t *pFilePath, 
                                                              const wchar_t *pPerm,
                                                              const FPLong pBuffSize,
                                                              const FPLong pOffset, 
                                                              const FPLong pLength,
                                                              const FPLong pFileLength) ;


/**
    The function creates a stream to write to a memory buffer and returns
    a reference to the created stream. When the end of the buffer has been
    reached mAtEOF of pStreamInfo is Set to true. For more information
    on pStreamInfo refer to FPStream_CreateGenericStream in the
    API Reference Guide.

    @param pBuffer  pBuffer is the memory buffer containing the data for the stream.
    @param pBuffLen pBuffLen is the buffer length (in bytes) of pBuffer.
    @return A reference to the created stream, or zero if an error
     occurs.

    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateBufferForInput (char *pBuffer, const unsigned long pBuffLen) ;

/**
    The function creates a stream to write to a memory buffer and returns
    a reference to the created stream. When the end of the buffer has been
    reached mAtEOF of pStreamInfo is Set to true. For more information
    on pStreamInfo refer to FPStream_CreateGenericStream in the
    API Reference Guide.

    @param pBuffer  pBuffer is the memory buffer containing the data for the stream.
    @param pBuffLen pBuffLen is the buffer length (in bytes) of pBuffer.
    @return A reference to the created stream, or zero if an error
     occurs.

    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateBufferForOutput (char *pBuffer, const unsigned long pBuffLen) ;

/**
    The function creates a stream for output to the console. The stream
    can be used only for writing. The function returns a reference to the
    created stream.

    @return A reference to the created stream, or zero if an error
     occurs.
    
    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateToStdio (void) ;

/**
    The function creates a stream for output but does not write the bytes.
    The function returns a reference to the created stream.

    @return A reference to the created stream, or zero if an error
     occurs.
    
    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateToNull (void) ;

/**
    The function creates a stream for temporary storage and returns a
    reference to the created stream. If the length of the stream exceeds
    pMemBuffSize, the overflow is flushed to a temporary file in the
    platform-specific temporary directory. This temporary file will be
    automatically deleted when the stream closes.

    @param pMemBuffSize   pMemBuffSize is the size of the memory buffer.
    @return A reference to the created stream, or zero if an error
     occurs.
    
    @since 1.1
*/

EXPORT FPStreamRef DECL FPStream_CreateTemporaryFile (const long pMemBuffSize) ;

/** @} */  /* Stream Creation Functions */

/*-----------------------------------------------------------------------*/
/* Obsolete 1.0 stream functions */

#ifndef _DONT_USE_DEPRECATED_

  /**
     @defgroup Obsolete Deprecated streaming functions
     @{
  */

  /**
     @deprecated We recommend not using this function

     @param pFilePath The fully qualified file name for the file to be
     associated with the stream.

     @param pPerm The permissions, like in fopen().  You can use the
     following permissions:
     - r: open the given file for reading. If the file does not exist
     or the system cannot find the file, the function will return an
     error.
     - w: open the given file for writing. The function overwrites
     existing content of the file.
     - r+: open the given file for both reading and writing. If the
     file does not exist or the system cannot find the file, the
     function will return an error.
     - w+: open the given file for both reading and writing. If the
     given file exists, the function overwrites its content.
     
     @return A reference to the created stream, or zero if an error
     occurs.
     
     @since 1.0
  */
EXPORT FPStreamRef DECL FPStream_CreateWithFile (char *pFilePath, char *pPerm) ;

  /**
     @deprecated Use FPStream_CreateBufferForInput() and
     FPStream_CreateBufferForOutput() instead of this function.

     @param pBuffer  pBuffer is the memory buffer containing the data for the stream.
     @param pBuffLen pBuffLen is the buffer length (in bytes) of pBuffer.
     @return A reference to the created stream, or zero if an error
     occurs.
     
     @since 1.0
  */
EXPORT FPStreamRef DECL FPStream_CreateWithBuffer (char *pBuffer, unsigned long pBuffLen) ;


  /**
     @deprecated The FPLibrary stream functions should not be used for
     purposes other than communicating with a Centera cluster.

     Reads <i>pBuffSize</i> bytes from a stream into the specified buffer.
     Note: You cannot use the function for streams that
     FPStream_CreateToStdio() or FPStream_CreateToNull() has created.

     @return the actual number of bytes read.

     @since 1.0
  */
EXPORT long        DECL FPStream_Read (FPStreamRef pStream, void *pBuffer, long pBuffSize) ;


  /**
     @deprecated The FPLibrary stream functions should not be used for
                 purposes other than communicating with a Centera cluster.
                 Creating a file stream with mode "w+" such as:
                    vStream = FPStream_CreateFileForOutput(tempName, "w+");
                 can expose your application to a data integrity problem, 
                 when the stream is used with the following deprecated apis:
                    FPStream_Write
                    FPStream_Read
                    FPStream_SetMarker
                 EMC recommends not using deprecated apis in applications.  

     Writes <i>pBuffSize</i> bytes from a buffer to a stream.
     Note: You cannot use this function for streams that
     FPStream_CreateWithBuffer() has created.

     @param pStream The stream to write to.

     @param pBuffer The buffer which holds the data to be written.

     @param pBuffSize The size of the buffer.

     @return the actual number of bytes written.
     @since 1.0
  */
EXPORT long        DECL FPStream_Write (FPStreamRef pStream, void *pBuffer, long pBuffSize) ;


  /**
     @deprecated Use the generic streams facilities instead of this
     function.

     Sets a marker in the stream to specify where the next read or
     write should start.

     @param pStream The stream on which to Set the marker.

     @param pOffset The place where the marker should be Set.

     @since 1.0
  */
EXPORT void        DECL FPStream_SetMarker (FPStreamRef pStream, FPLong pOffset) ;


  /**
     @deprecated Use the generic streams facilities instead of this
     function.

     Returns the current position of the marker for the specified stream.

     @param pStream The stream to query.

     @since 1.0
  */
EXPORT FPLong      DECL FPStream_GetMarker (FPStreamRef pStream) ;

  /** @} */

#endif /* _DONT_USE_DEPRECATED_ */

  /** @} */
#ifdef __cplusplus
}
#endif

#endif /* __FPSTREAM__ */
